/**
 * Every user-visible string the scheduling surface can draw, in one
 * overridable contract.
 *
 * The package ships English defaults so a host can render a working Gantt with
 * zero configuration, and replaces any subset from its own i18n layer. Nothing
 * inside a component hardcodes a string — that is what makes this package
 * translatable without forking it.
 */
import type { DependencyType, ScheduleConstraintType, ScheduleQuickFilter, ScheduleResourceKind, ScheduleTaskStatus, ScheduleTaskType, ZoomLevel } from './types.js';
export interface SchedulingLabels {
    status: Record<ScheduleTaskStatus, string>;
    taskType: Record<ScheduleTaskType, string>;
    dependencyType: Record<DependencyType, string>;
    dependencyTypeLong: Record<DependencyType, string>;
    constraintType: Record<ScheduleConstraintType, string>;
    resourceKind: Record<ScheduleResourceKind, string>;
    quickFilter: Record<ScheduleQuickFilter, string>;
    zoom: Record<ZoomLevel, string>;
    view: {
        gantt: string;
        list: string;
        board: string;
    };
    toolbar: {
        addTask: string;
        addMilestone: string;
        criticalPath: string;
        baseline: string;
        filters: string;
        clearFilters: string;
        today: string;
        fitToWindow: string;
        zoomIn: string;
        zoomOut: string;
        manageSchedule: string;
        levelResources: string;
        search: string;
        collapseAll: string;
        expandAll: string;
        indent: string;
        outdent: string;
    };
    columns: {
        name: string;
        start: string;
        finish: string;
        duration: string;
        progress: string;
        status: string;
        assignee: string;
        float: string;
        predecessors: string;
        phase: string;
        calendar: string;
        constraint: string;
        deadline: string;
        actualStart: string;
        actualFinish: string;
        resources: string;
        week: string;
    };
    editor: {
        title: string;
        description: string;
        dates: string;
        logic: string;
        resources: string;
        constraintDate: string;
        deadlineDate: string;
        lag: string;
        addPredecessor: string;
        removePredecessor: string;
        units: string;
        role: string;
        save: string;
        cancel: string;
        delete: string;
        deleteConfirm: string;
        parentTask: string;
        topLevel: string;
        children: string;
        successors: string;
        noPredecessors: string;
        noSuccessors: string;
        noResources: string;
        resourcesHint: string;
        defaultCalendar: string;
        summaryAuto: string;
        rollupLocked: string;
        endBeforeStart: string;
        choosePredecessor: string;
        cycleRejected: string;
        removeDependencyFailed: string;
    };
    insights: {
        heading: string;
        critical: string;
        overdue: string;
        behindBaseline: string;
        missingDates: string;
        unassigned: string;
        isolated: string;
        openEnded: string;
        deadlineMissed: string;
        constraintViolation: string;
        actualDateGap: string;
        resourceConflict: string;
        dependencyViolation: string;
        cycleDetected: string;
        noIssues: string;
    };
    leveling: {
        heading: string;
        description: string;
        withinFloatOnly: string;
        freezeStartedTasks: string;
        preview: string;
        apply: string;
        noMoves: string;
        movesSummary: string;
        unresolvedSummary: string;
        projectDelay: string;
        reasonExceedsFloat: string;
        reasonExceedsWindow: string;
        reasonCapacityBelowDemand: string;
        load: string;
        capacity: string;
        overloadedDays: string;
    };
    list: {
        wbs: string;
        flags: string;
        variance: string;
        onBaseline: string;
        openEnd: string;
        actuals: string;
        visible: string;
        critical: string;
        overdue: string;
        slip: string;
        issues: string;
        selected: string;
        markInProgress: string;
        markComplete: string;
        clearSelection: string;
        selectAll: string;
        start: string;
        done: string;
        reopen: string;
        hold: string;
        noMatches: string;
        reorderRequiresWbsSort: string;
        resource: string;
    };
    board: {
        heading: string;
        unscheduled: string;
        dropHint: string;
        emptyColumn: string;
    };
    menu: {
        viewTitle: string;
        timelineTitle: string;
        moveTimeline: string;
        earlier: string;
        later: string;
        zoom: string;
        healthTitle: string;
        baselineTitle: string;
        activeBaseline: string;
        noBaselines: string;
        saveBaseline: string;
        showBaseline: string;
        hideBaseline: string;
        clearBaseline: string;
        exportPdf: string;
        primary: string;
        snapshot: string;
        more: string;
        actionsTitle: string;
        importSchedule: string;
        showFilters: string;
        hideFilters: string;
        deadlineMisses: string;
        resourceConflicts: string;
        constraintViolations: string;
        calendarsResources: string;
        tbd: string;
    };
    /** Compact toolbar chips for each quick filter. */
    quickFilterShort: Record<ScheduleQuickFilter, string>;
    /** Short chips drawn on a task row. */
    badges: {
        summary: string;
        overdue: string;
        logic: string;
        deadline: string;
        constraint: string;
        resource: string;
        critical: string;
        milestone: string;
        untitled: string;
        schedule: string;
        reorderHint: string;
        expand: string;
        collapse: string;
        resizeSplit: string;
    };
    /**
     * Count-dependent strings. These are FUNCTIONS so plural rules stay in the
     * host's i18n layer — English "1 task / 2 tasks" is not a rule that
     * generalizes, and baking it in would mistranslate most locales.
     */
    format: {
        taskCount: (count: number) => string;
        phaseCount: (count: number) => string;
        childCount: (count: number) => string;
        days: (count: number) => string;
        floatDays: (count: number) => string;
        slipDays: (count: number) => string;
        aheadDays: (count: number) => string;
    };
    empty: {
        title: string;
        description: string;
        action: string;
    };
    common: {
        days: string;
        none: string;
        unassigned: string;
        noPhase: string;
        of: string;
    };
}
export declare const defaultSchedulingLabels: SchedulingLabels;
/** Deep-merge a host's partial overrides over the English defaults. */
export declare function mergeSchedulingLabels(overrides?: DeepPartial<SchedulingLabels>): SchedulingLabels;
export type DeepPartial<T> = {
    [K in keyof T]?: Partial<T[K]>;
};
/** Narrow a raw string to a known status/type key, or fall back. */
export declare function labelFor<T extends string>(map: Record<T, string>, key: string | null | undefined, fallback: string): string;
//# sourceMappingURL=labels.d.ts.map