'use client';
import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
/**
 * The task editor: everything about one activity, with a health sidebar that
 * explains why the schedule is unhappy with it.
 *
 * Two rules run through the whole form:
 *  - A task with children is a SUMMARY. Its type, status, dates and progress
 *    are derived, so those inputs lock rather than silently losing the value
 *    the next rollup overwrites.
 *  - A MILESTONE has one date. The finish input writes the start, duration
 *    saves as 0, and progress saves as 0.
 */
import { useEffect, useMemo, useState } from 'react';
import { Plus, Trash2, X } from 'lucide-react';
import { Button, Input, Label, Select, Tabs, Textarea, cn } from '@appkit/ui';
import { diffDays, parseDate } from '../dates.js';
import { buildTaskHierarchyInfo, getTaskDescendantIds, sortTasksByOrder } from '../hierarchy.js';
import { getTaskVariance, normalizeScheduleProgress } from '../insights.js';
import { wouldCreateDependencyCycle } from '../network.js';
import { useSchedulingLabels } from './context.js';
const NONE = '__none__';
const MAX_OUTLINE_LEVEL = 12;
export function TaskEditor({ task, phases, allTasks, dependencies, insights, calendars, resources, taskAssignments, onSave, onDelete, onCreateDependency, onDeleteDependency, onClose, }) {
    const labels = useSchedulingLabels();
    const [activeTab, setActiveTab] = useState('task');
    const [name, setName] = useState(task.name);
    const [description, setDescription] = useState(task.description);
    const [taskType, setTaskType] = useState(task.taskType);
    const [status, setStatus] = useState(task.status);
    const [startDate, setStartDate] = useState(task.startDate?.slice(0, 10) ?? '');
    const [endDate, setEndDate] = useState(task.endDate?.slice(0, 10) ?? '');
    const [progress, setProgress] = useState(normalizeScheduleProgress(task.progress));
    const [assignee, setAssignee] = useState(task.assignee);
    const [phaseId, setPhaseId] = useState(task.phaseId ?? '');
    const [calendarId, setCalendarId] = useState(task.calendarId ?? '');
    const [parentTaskId, setParentTaskId] = useState(task.parentTaskId ?? '');
    const [constraintType, setConstraintType] = useState(task.constraintType);
    const [constraintDate, setConstraintDate] = useState(task.constraintDate?.slice(0, 10) ?? '');
    const [deadlineDate, setDeadlineDate] = useState(task.deadlineDate?.slice(0, 10) ?? '');
    const [actualStart, setActualStart] = useState(task.actualStart?.slice(0, 10) ?? '');
    const [actualEnd, setActualEnd] = useState(task.actualEnd?.slice(0, 10) ?? '');
    const [resourceAssignments, setResourceAssignments] = useState(taskAssignments.map((a) => ({ resourceId: a.resourceId, units: String(a.units), role: a.role ?? '' })));
    const [selectedPredecessorId, setSelectedPredecessorId] = useState('');
    const [dependencyType, setDependencyType] = useState('FS');
    const [dependencyLagDays, setDependencyLagDays] = useState('0');
    const [formError, setFormError] = useState(null);
    const [dependencyError, setDependencyError] = useState(null);
    // Re-seed every field when the editor is pointed at a different task.
    useEffect(() => {
        setActiveTab('task');
        setName(task.name);
        setDescription(task.description);
        setTaskType(task.taskType);
        setStatus(task.status);
        setStartDate(task.startDate?.slice(0, 10) ?? '');
        setEndDate(task.endDate?.slice(0, 10) ?? '');
        setProgress(normalizeScheduleProgress(task.progress));
        setAssignee(task.assignee);
        setPhaseId(task.phaseId ?? '');
        setCalendarId(task.calendarId ?? '');
        setParentTaskId(task.parentTaskId ?? '');
        setConstraintType(task.constraintType);
        setConstraintDate(task.constraintDate?.slice(0, 10) ?? '');
        setDeadlineDate(task.deadlineDate?.slice(0, 10) ?? '');
        setActualStart(task.actualStart?.slice(0, 10) ?? '');
        setActualEnd(task.actualEnd?.slice(0, 10) ?? '');
        setResourceAssignments(taskAssignments.map((a) => ({ resourceId: a.resourceId, units: String(a.units), role: a.role ?? '' })));
        setSelectedPredecessorId('');
        setDependencyType('FS');
        setDependencyLagDays('0');
        setFormError(null);
        setDependencyError(null);
    }, [task, taskAssignments]);
    const taskNameById = useMemo(() => new Map(allTasks.map((item) => [item.id, item.name || labels.badges.untitled])), [allTasks, labels.badges.untitled]);
    const predecessorDependencies = useMemo(() => dependencies.filter((d) => d.successorId === task.id), [dependencies, task.id]);
    const successorDependencies = useMemo(() => dependencies.filter((d) => d.predecessorId === task.id), [dependencies, task.id]);
    const variance = useMemo(() => getTaskVariance(task), [task]);
    const totalFloat = insights.totalFloatByTask.get(task.id);
    const currentPhaseTasks = useMemo(() => sortTasksByOrder(allTasks.filter((item) => (item.phaseId ?? '') === phaseId)), [allTasks, phaseId]);
    const currentPhaseHierarchy = useMemo(() => buildTaskHierarchyInfo(currentPhaseTasks), [currentPhaseTasks]);
    const hasChildren = (currentPhaseHierarchy.get(task.id)?.hasChildren ?? false) ||
        allTasks.some((item) => item.parentTaskId === task.id);
    const effectiveTaskType = hasChildren ? 'summary' : taskType;
    const isMilestoneTask = effectiveTaskType === 'milestone';
    const isRollupLocked = hasChildren;
    const descendantIds = useMemo(() => new Set(getTaskDescendantIds(allTasks, task.id)), [allTasks, task.id]);
    const availableParentTasks = useMemo(() => currentPhaseTasks.filter((item) => item.id !== task.id && !descendantIds.has(item.id)), [currentPhaseTasks, descendantIds, task.id]);
    // Only offer links that cannot close a loop — the cycle check runs here, not
    // after the user has already committed to a bad dependency.
    const availablePredecessors = useMemo(() => {
        const existingIds = new Set(predecessorDependencies.map((d) => d.predecessorId));
        return allTasks
            .filter((item) => item.id !== task.id &&
            !existingIds.has(item.id) &&
            !wouldCreateDependencyCycle(dependencies, item.id, task.id))
            .sort((a, b) => a.name.localeCompare(b.name));
    }, [allTasks, dependencies, predecessorDependencies, task.id]);
    const parentTask = parentTaskId ? (allTasks.find((item) => item.id === parentTaskId) ?? null) : null;
    const outlineLevel = parentTask ? Math.min(MAX_OUTLINE_LEVEL, (parentTask.outlineLevel ?? 0) + 1) : 0;
    const wbsPath = useMemo(() => {
        const segments = [];
        let current = parentTask;
        let safety = 0;
        while (current && safety < MAX_OUTLINE_LEVEL) {
            segments.unshift(current.name || labels.badges.untitled);
            const nextId = current.parentTaskId;
            current = nextId ? (allTasks.find((item) => item.id === nextId) ?? null) : null;
            safety += 1;
        }
        return segments;
    }, [allTasks, labels.badges.untitled, parentTask]);
    // Switching phase can strand the chosen parent in another phase.
    useEffect(() => {
        if (!parentTaskId)
            return;
        if (!availableParentTasks.some((item) => item.id === parentTaskId))
            setParentTaskId('');
    }, [availableParentTasks, parentTaskId]);
    const handleSave = async () => {
        const normalizedStartDate = startDate || null;
        const normalizedEndDate = isMilestoneTask ? startDate || null : endDate || null;
        const parsedStartDate = parseDate(normalizedStartDate);
        const parsedEndDate = parseDate(normalizedEndDate);
        if (!isMilestoneTask &&
            parsedStartDate &&
            parsedEndDate &&
            parsedEndDate.getTime() < parsedStartDate.getTime()) {
            setFormError(labels.editor.endBeforeStart);
            setActiveTab('dates');
            return;
        }
        const duration = isMilestoneTask
            ? 0
            : parsedStartDate && parsedEndDate
                ? Math.max(0, diffDays(parsedEndDate, parsedStartDate))
                : task.duration;
        setFormError(null);
        const didSave = await onSave(task.id, {
            name,
            description,
            taskType: effectiveTaskType,
            status,
            startDate: normalizedStartDate,
            endDate: normalizedEndDate,
            duration,
            progress: isMilestoneTask ? 0 : progress,
            assignee,
            phaseId: phaseId || null,
            calendarId: calendarId || null,
            parentTaskId: parentTaskId || null,
            outlineLevel,
            constraintType,
            constraintDate: constraintDate || null,
            deadlineDate: deadlineDate || null,
            actualStart: actualStart || null,
            actualEnd: actualEnd || null,
            resourceAssignments: resourceAssignments
                .filter((a) => a.resourceId)
                .map((a) => ({
                resourceId: a.resourceId,
                units: Number.parseFloat(a.units || '1') || 1,
                role: a.role || '',
            })),
        });
        if (didSave)
            onClose();
    };
    const handleAddDependency = async () => {
        if (!selectedPredecessorId) {
            setDependencyError(labels.editor.choosePredecessor);
            return;
        }
        if (wouldCreateDependencyCycle(dependencies, selectedPredecessorId, task.id)) {
            setDependencyError(labels.editor.cycleRejected);
            return;
        }
        const didCreate = await onCreateDependency({
            predecessorId: selectedPredecessorId,
            successorId: task.id,
            type: dependencyType,
            lagDays: Number.parseInt(dependencyLagDays || '0', 10) || 0,
        });
        if (didCreate) {
            setSelectedPredecessorId('');
            setDependencyType('FS');
            setDependencyLagDays('0');
            setDependencyError(null);
        }
    };
    const handleRemoveDependency = async (dependencyId) => {
        const didDelete = await onDeleteDependency(dependencyId);
        if (!didDelete)
            setDependencyError(labels.editor.removeDependencyFailed);
    };
    const setAssignmentAt = (index, patch) => setResourceAssignments((current) => current.map((entry, entryIndex) => (entryIndex === index ? { ...entry, ...patch } : entry)));
    return (_jsxs("div", { className: "fixed inset-0 z-50 flex items-center justify-center", "data-testid": "task-editor", children: [_jsx("div", { className: "absolute inset-0 bg-overlay/30 backdrop-blur-[1px]", onClick: onClose }), _jsxs("div", { "data-testid": "task-editor-panel", role: "dialog", "aria-modal": "true", "aria-label": labels.editor.title, className: "relative flex w-full max-w-5xl flex-col overflow-hidden rounded-2xl border border-border bg-surface shadow-2xl", style: { height: 'min(92vh, 780px)' }, children: [_jsx("div", { className: "border-b border-border px-5 py-4", children: _jsxs("div", { className: "flex items-start justify-between gap-4", children: [_jsxs("div", { className: "min-w-0", children: [_jsx("p", { className: "text-[10px] font-semibold tracking-[0.18em] text-fg-subtle uppercase", children: labels.editor.title }), _jsx("h3", { className: "mt-1 truncate text-base font-semibold text-fg", children: task.name || labels.badges.untitled }), _jsxs("div", { className: "mt-2 flex flex-wrap items-center gap-1.5 text-[11px] text-fg-muted", children: [_jsx(Chip, { children: labels.status[status] }), _jsx(Chip, { children: labels.taskType[effectiveTaskType] }), _jsxs(Chip, { children: [labels.list.wbs, " L", outlineLevel] }), phaseId ? (_jsx(Chip, { children: phases.find((phase) => phase.id === phaseId)?.name ?? labels.columns.phase })) : null] })] }), _jsx("button", { type: "button", onClick: onClose, "aria-label": labels.editor.cancel, className: "text-fg-subtle transition-colors hover:text-fg", children: _jsx(X, { className: "h-4 w-4" }) })] }) }), _jsxs("div", { className: "grid min-h-0 flex-1 gap-0 lg:grid-cols-[minmax(0,1fr)_320px]", children: [_jsxs("div", { className: "flex min-h-0 flex-col px-5 py-4", children: [_jsx(Tabs, { className: "mb-4", value: activeTab, onValueChange: setActiveTab, tabs: [
                                            { value: 'task', label: labels.editor.title },
                                            { value: 'dates', label: labels.editor.dates },
                                            { value: 'resources', label: labels.editor.resources },
                                            { value: 'logic', label: labels.editor.logic },
                                        ] }), _jsxs("div", { className: "sched-scroll min-h-0 flex-1 overflow-y-auto pr-1", children: [activeTab === 'task' ? (_jsxs("div", { className: "space-y-4", children: [_jsx(Field, { label: labels.columns.name, children: _jsx(Input, { value: name, onChange: (event) => setName(event.target.value) }) }), _jsxs("div", { className: "grid gap-3 md:grid-cols-2", children: [_jsxs(Field, { label: labels.taskType.task, children: [_jsxs(Select, { value: effectiveTaskType, onChange: (event) => setTaskType(event.target.value), disabled: hasChildren, "aria-label": labels.taskType.task, children: [_jsx("option", { value: "task", children: labels.taskType.task }), _jsx("option", { value: "milestone", children: labels.taskType.milestone }), _jsx("option", { value: "summary", children: labels.taskType.summary })] }), hasChildren ? _jsx(Hint, { children: labels.editor.summaryAuto }) : null] }), _jsx(Field, { label: labels.columns.status, children: _jsx(Select, { value: status, onChange: (event) => setStatus(event.target.value), disabled: isRollupLocked, "aria-label": labels.columns.status, children: Object.keys(labels.status).map((key) => (_jsx("option", { value: key, children: labels.status[key] }, key))) }) })] }), _jsxs("div", { className: "grid gap-3 md:grid-cols-2", children: [_jsx(Field, { label: labels.columns.assignee, children: _jsx(Input, { value: assignee, onChange: (event) => setAssignee(event.target.value) }) }), _jsx(Field, { label: labels.columns.calendar, children: _jsxs(Select, { value: calendarId || NONE, onChange: (event) => setCalendarId(event.target.value === NONE ? '' : event.target.value), "aria-label": labels.columns.calendar, children: [_jsx("option", { value: NONE, children: labels.editor.defaultCalendar }), calendars.map((calendar) => (_jsx("option", { value: calendar.id, children: calendar.name }, calendar.id)))] }) })] }), _jsxs("div", { className: "grid gap-3 md:grid-cols-2", children: [_jsx(Field, { label: labels.columns.phase, children: _jsxs(Select, { value: phaseId || NONE, onChange: (event) => setPhaseId(event.target.value === NONE ? '' : event.target.value), "aria-label": labels.columns.phase, children: [_jsx("option", { value: NONE, children: labels.common.noPhase }), phases.map((phase) => (_jsxs("option", { value: phase.id, children: [phase.number ? `${phase.number}. ` : '', phase.name] }, phase.id)))] }) }), _jsx(Field, { label: labels.editor.parentTask, children: _jsxs(Select, { value: parentTaskId || NONE, onChange: (event) => setParentTaskId(event.target.value === NONE ? '' : event.target.value), "aria-label": labels.editor.parentTask, children: [_jsx("option", { value: NONE, children: labels.editor.topLevel }), availableParentTasks.map((item) => {
                                                                            const depth = currentPhaseHierarchy.get(item.id)?.depth ?? item.outlineLevel ?? 0;
                                                                            return (_jsxs("option", { value: item.id, children: ['  '.repeat(depth), item.name || labels.badges.untitled] }, item.id));
                                                                        })] }) })] }), _jsx(Field, { label: labels.editor.description, children: _jsx(Textarea, { value: description, onChange: (event) => setDescription(event.target.value), rows: 6 }) })] })) : null, activeTab === 'dates' ? (_jsxs("div", { className: "space-y-4", children: [_jsxs("div", { className: "grid gap-3 md:grid-cols-2", children: [_jsx(Field, { label: labels.columns.start, children: _jsx(Input, { type: "date", value: startDate, onChange: (event) => setStartDate(event.target.value), disabled: isRollupLocked }) }), _jsx(Field, { label: isMilestoneTask ? labels.taskType.milestone : labels.columns.finish, children: _jsx(Input, { type: "date", value: isMilestoneTask ? startDate : endDate, onChange: (event) => isMilestoneTask ? setStartDate(event.target.value) : setEndDate(event.target.value), disabled: isRollupLocked }) })] }), _jsxs("div", { className: "grid gap-3 md:grid-cols-2", children: [_jsx(Field, { label: labels.columns.constraint, children: _jsx(Select, { value: constraintType, onChange: (event) => setConstraintType(event.target.value), "aria-label": labels.columns.constraint, children: Object.keys(labels.constraintType).map((key) => (_jsx("option", { value: key, children: labels.constraintType[key] }, key))) }) }), _jsx(Field, { label: labels.editor.constraintDate, children: _jsx(Input, { "data-testid": "task-constraint-date", type: "date", value: constraintDate, onChange: (event) => setConstraintDate(event.target.value) }) })] }), _jsxs("div", { className: "grid gap-3 md:grid-cols-2", children: [_jsx(Field, { label: labels.columns.deadline, children: _jsx(Input, { "data-testid": "task-deadline-date", type: "date", value: deadlineDate, onChange: (event) => setDeadlineDate(event.target.value) }) }), _jsx(Field, { label: `${labels.columns.progress} (${Math.round((isMilestoneTask ? 0 : progress) * 100)}%)`, children: _jsx("input", { type: "range", min: 0, max: 1, step: 0.05, value: isMilestoneTask ? 0 : progress, onChange: (event) => setProgress(Number.parseFloat(event.target.value)), disabled: isMilestoneTask || isRollupLocked, "aria-label": labels.columns.progress, className: "h-1.5 w-full cursor-pointer appearance-none rounded-full bg-border accent-[var(--color-primary)] disabled:cursor-not-allowed disabled:opacity-50" }) })] }), _jsxs("div", { className: "grid gap-3 md:grid-cols-2", children: [_jsx(Field, { label: labels.columns.actualStart, children: _jsx(Input, { type: "date", value: actualStart, onChange: (event) => setActualStart(event.target.value), disabled: isRollupLocked }) }), _jsx(Field, { label: labels.columns.actualFinish, children: _jsx(Input, { type: "date", value: actualEnd, onChange: (event) => setActualEnd(event.target.value), disabled: isRollupLocked }) })] }), isRollupLocked ? _jsx(Note, { children: labels.editor.rollupLocked }) : null] })) : null, activeTab === 'resources' ? (_jsxs("div", { className: "space-y-3 rounded-xl border border-border bg-bg-subtle p-4", children: [_jsxs("div", { className: "flex items-start justify-between gap-3", children: [_jsxs("div", { children: [_jsx("h4", { className: "text-sm font-semibold text-fg", children: labels.editor.resources }), _jsx("p", { className: "mt-1 text-xs text-fg-muted", children: labels.editor.resourcesHint })] }), _jsx(Button, { variant: "secondary", size: "sm", "data-testid": "task-add-resource", onClick: () => setResourceAssignments((current) => [
                                                                    ...current,
                                                                    { resourceId: '', units: '1', role: '' },
                                                                ]), children: _jsx(Plus, { className: "h-3.5 w-3.5" }) })] }), resourceAssignments.length === 0 ? (_jsx("p", { className: "text-xs text-fg-subtle", children: labels.editor.noResources })) : (_jsx("div", { className: "space-y-2", children: resourceAssignments.map((assignment, index) => (_jsxs("div", { className: "grid gap-2 rounded-lg border border-border bg-surface px-3 py-3 md:grid-cols-[minmax(0,1fr)_92px_minmax(0,1fr)_36px]", children: [_jsxs(Select, { "data-testid": `task-resource-${index}`, value: assignment.resourceId || NONE, onChange: (event) => setAssignmentAt(index, {
                                                                        resourceId: event.target.value === NONE ? '' : event.target.value,
                                                                    }), "aria-label": labels.editor.resources, children: [_jsx("option", { value: NONE, children: labels.common.none }), resources.map((resource) => (_jsx("option", { value: resource.id, children: resource.name }, resource.id)))] }), _jsx(Input, { "data-testid": `task-resource-units-${index}`, type: "number", step: "0.25", value: assignment.units, "aria-label": labels.editor.units, onChange: (event) => setAssignmentAt(index, { units: event.target.value }) }), _jsx(Input, { "data-testid": `task-resource-role-${index}`, value: assignment.role, placeholder: labels.editor.role, "aria-label": labels.editor.role, onChange: (event) => setAssignmentAt(index, { role: event.target.value }) }), _jsx("button", { type: "button", "aria-label": labels.editor.delete, onClick: () => setResourceAssignments((current) => current.filter((_, entryIndex) => entryIndex !== index)), className: "text-fg-subtle transition-colors hover:text-danger", children: _jsx(Trash2, { className: "h-3.5 w-3.5" }) })] }, `${assignment.resourceId}-${index}`))) }))] })) : null, activeTab === 'logic' ? (_jsxs("div", { className: "space-y-4", children: [_jsx(DependencyList, { heading: labels.columns.predecessors, empty: labels.editor.noPredecessors, dependencies: predecessorDependencies, nameOf: (dep) => taskNameById.get(dep.predecessorId) ?? labels.badges.untitled, onRemove: (id) => void handleRemoveDependency(id), removeLabel: labels.editor.removePredecessor, typeLabel: (type) => labels.dependencyTypeLong[type], lagLabel: (days) => `${labels.editor.lag}: ${days}` }), _jsxs("div", { className: "space-y-2 rounded-xl border border-dashed border-border p-4", children: [_jsx(Label, { children: labels.editor.addPredecessor }), _jsxs(Select, { value: selectedPredecessorId || NONE, onChange: (event) => setSelectedPredecessorId(event.target.value === NONE ? '' : event.target.value), "aria-label": labels.editor.addPredecessor, children: [_jsx("option", { value: NONE, children: labels.common.none }), availablePredecessors.map((item) => (_jsx("option", { value: item.id, children: item.name || labels.badges.untitled }, item.id)))] }), _jsxs("div", { className: "grid gap-2 md:grid-cols-[minmax(0,1fr)_88px]", children: [_jsx(Select, { value: dependencyType, onChange: (event) => setDependencyType(event.target.value), "aria-label": labels.columns.predecessors, children: Object.keys(labels.dependencyTypeLong).map((key) => (_jsx("option", { value: key, children: labels.dependencyTypeLong[key] }, key))) }), _jsx(Input, { type: "number", value: dependencyLagDays, "aria-label": labels.editor.lag, onChange: (event) => setDependencyLagDays(event.target.value) })] }), dependencyError && _jsx("p", { className: "text-[11px] text-danger", children: dependencyError }), _jsxs(Button, { variant: "secondary", size: "sm", onClick: () => void handleAddDependency(), disabled: availablePredecessors.length === 0, children: [_jsx(Plus, { className: "h-3.5 w-3.5" }), labels.editor.addPredecessor] })] }), _jsx(DependencyList, { heading: labels.editor.successors, empty: labels.editor.noSuccessors, dependencies: successorDependencies, nameOf: (dep) => taskNameById.get(dep.successorId) ?? labels.badges.untitled, onRemove: (id) => void handleRemoveDependency(id), removeLabel: labels.editor.removePredecessor, typeLabel: (type) => labels.dependencyTypeLong[type], lagLabel: (days) => `${labels.editor.lag}: ${days}` })] })) : null, formError && _jsx("p", { className: "mt-4 text-xs text-danger", children: formError })] }), _jsxs("div", { className: "mt-4 flex items-center gap-2 border-t border-border pt-4", children: [_jsxs(Button, { variant: "destructive", size: "sm", onClick: async () => {
                                                    if (await onDelete(task.id))
                                                        onClose();
                                                }, children: [_jsx(Trash2, { className: "h-3.5 w-3.5" }), labels.editor.delete] }), _jsx("div", { className: "flex-1" }), _jsx(Button, { variant: "ghost", size: "sm", onClick: onClose, children: labels.editor.cancel }), _jsx(Button, { size: "sm", onClick: () => void handleSave(), "data-testid": "task-save", children: labels.editor.save })] })] }), _jsx("aside", { className: "sched-scroll min-h-0 overflow-y-auto border-l border-border bg-bg-subtle px-5 py-4", children: _jsxs("div", { className: "space-y-4", children: [_jsxs(Card, { title: labels.insights.heading, children: [_jsxs("div", { className: "grid grid-cols-2 gap-2 text-xs text-fg-muted", children: [_jsx(Metric, { label: labels.columns.float, children: typeof totalFloat === 'number' && Number.isFinite(totalFloat)
                                                                ? labels.format.days(Math.round(totalFloat))
                                                                : '—' }), _jsx(Metric, { label: labels.list.variance, children: variance.finishDays === null
                                                                ? '—'
                                                                : `${variance.finishDays > 0 ? '+' : ''}${variance.finishDays}d` })] }), _jsxs("div", { className: "flex flex-wrap gap-1", children: [insights.criticalTaskIds.has(task.id) && (_jsx(Chip, { tone: "primary", children: labels.insights.critical })), insights.overdueTaskIds.has(task.id) && (_jsx(Chip, { tone: "danger", children: labels.insights.overdue })), variance.isBehind && _jsx(Chip, { tone: "warning", children: labels.insights.behindBaseline }), insights.violatingTaskIds.has(task.id) && (_jsx(Chip, { tone: "warning", children: labels.insights.dependencyViolation })), insights.deadlineMissTaskIds.has(task.id) && (_jsx(Chip, { tone: "danger", children: labels.insights.deadlineMissed })), insights.constraintViolationTaskIds.has(task.id) && (_jsx(Chip, { tone: "warning", children: labels.insights.constraintViolation })), insights.actualDateGapTaskIds.has(task.id) && (_jsx(Chip, { tone: "warning", children: labels.insights.actualDateGap })), insights.resourceConflictTaskIds.has(task.id) && (_jsx(Chip, { tone: "warning", children: labels.insights.resourceConflict }))] })] }), _jsxs(Card, { title: labels.list.wbs, children: [_jsx(Row, { label: labels.list.wbs, children: outlineLevel }), _jsx(Row, { label: labels.editor.parentTask, children: parentTask?.name ?? labels.editor.topLevel }), _jsx(Row, { label: labels.editor.children, children: currentPhaseHierarchy.get(task.id)?.childCount ?? 0 }), _jsx("div", { className: "rounded-lg bg-bg-subtle px-3 py-2 text-[11px] text-fg-muted", children: wbsPath.length > 0 ? wbsPath.join(' / ') : labels.editor.topLevel })] }), _jsxs(Card, { title: labels.editor.dates, children: [_jsx(Row, { label: labels.columns.start, children: startDate || labels.menu.tbd }), _jsx(Row, { label: labels.columns.finish, children: (isMilestoneTask ? startDate : endDate) || labels.menu.tbd }), _jsx(Row, { label: labels.columns.resources, children: resourceAssignments.filter((a) => a.resourceId).length })] })] }) })] })] })] }));
}
function DependencyList({ heading, empty, dependencies, nameOf, onRemove, removeLabel, typeLabel, lagLabel, }) {
    return (_jsxs("div", { className: "space-y-2", children: [_jsx(Label, { children: heading }), dependencies.length === 0 ? (_jsx("p", { className: "text-xs text-fg-subtle", children: empty })) : (_jsx("div", { className: "space-y-2", children: dependencies.map((dependency) => (_jsxs("div", { className: "flex items-center gap-2 rounded-lg border border-border bg-surface px-3 py-2", children: [_jsxs("div", { className: "min-w-0 flex-1", children: [_jsx("p", { className: "truncate text-xs text-fg", children: nameOf(dependency) }), _jsxs("p", { className: "text-[11px] text-fg-subtle", children: [typeLabel(dependency.type), dependency.lagDays ? ` · ${lagLabel(dependency.lagDays)}` : ''] })] }), _jsx("button", { type: "button", onClick: () => onRemove(dependency.id), "aria-label": removeLabel, title: removeLabel, className: "text-fg-subtle transition-colors hover:text-danger", children: _jsx(Trash2, { className: "h-3.5 w-3.5" }) })] }, dependency.id))) }))] }));
}
function Field({ label, children }) {
    return (_jsxs("div", { className: "space-y-1.5", children: [_jsx(Label, { children: label }), children] }));
}
function Hint({ children }) {
    return _jsx("p", { className: "text-[11px] text-fg-subtle", children: children });
}
function Note({ children }) {
    return (_jsx("div", { className: "rounded-xl border border-border bg-bg-subtle px-4 py-3 text-xs text-fg-muted", children: children }));
}
function Card({ title, children }) {
    return (_jsxs("div", { className: "space-y-2 rounded-xl border border-border bg-surface px-4 py-4", children: [_jsx("h4", { className: "text-xs font-semibold tracking-[0.16em] text-fg-subtle uppercase", children: title }), children] }));
}
function Metric({ label, children }) {
    return (_jsxs("div", { className: "rounded-lg border border-border bg-bg-subtle px-3 py-2", children: [_jsx("p", { className: "text-[10px] tracking-wide text-fg-subtle uppercase", children: label }), _jsx("p", { className: "mt-1 font-medium text-fg", children: children })] }));
}
function Row({ label, children }) {
    return (_jsxs("div", { className: "flex items-center justify-between gap-3 text-xs", children: [_jsx("span", { className: "text-fg-subtle", children: label }), _jsx("span", { className: "truncate text-right font-medium text-fg", children: children })] }));
}
function Chip({ children, tone = 'neutral', }) {
    return (_jsx("span", { className: cn('rounded-full px-2 py-1 text-[11px]', tone === 'neutral' && 'bg-bg-subtle text-fg-muted', tone === 'danger' && 'bg-danger-subtle text-danger', tone === 'warning' && 'bg-warning-subtle text-warning', tone === 'primary' && 'bg-primary-subtle text-primary'), children: children }));
}
//# sourceMappingURL=task-editor.js.map