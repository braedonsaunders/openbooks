import { type ScheduleLevelingMove } from '../leveling.js';
import type { ScheduleCalendar, ScheduleDependency, ScheduleResource, ScheduleTask, ScheduleTaskAssignment } from '../types.js';
export interface LevelingPanelProps {
    open: boolean;
    onClose: () => void;
    tasks: ScheduleTask[];
    dependencies: ScheduleDependency[];
    calendars: ScheduleCalendar[];
    resources: ScheduleResource[];
    assignments: ScheduleTaskAssignment[];
    /** Persist the accepted moves. Return false to keep the panel open. */
    onApply: (moves: ScheduleLevelingMove[]) => Promise<boolean> | boolean;
}
export declare function LevelingPanel({ open, onClose, tasks, dependencies, calendars, resources, assignments, onApply, }: LevelingPanelProps): import("react").JSX.Element | null;
//# sourceMappingURL=leveling-panel.d.ts.map