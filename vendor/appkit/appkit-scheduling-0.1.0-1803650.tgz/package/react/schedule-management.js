'use client';
import { jsx as _jsx, jsxs as _jsxs, Fragment as _Fragment } from "react/jsx-runtime";
/**
 * Schedule administration: baselines, working calendars, and the resource
 * pool. These are the three things a plan is measured, sized, and staffed
 * against, and they are edited far less often than tasks — hence a dialog
 * rather than permanent chrome.
 */
import { useState } from 'react';
import { Plus, Star, Trash2, X } from 'lucide-react';
import { Badge, Button, Input, Label, Select, Tabs, cn } from '@appkit/ui';
import { useSchedulingLabels } from './context.js';
/** Mon–Fri, the starting point every new calendar gets. */
const DEFAULT_WORKING_DAYS = {
    '0': false,
    '1': true,
    '2': true,
    '3': true,
    '4': true,
    '5': true,
    '6': false,
};
const DAY_KEYS = ['0', '1', '2', '3', '4', '5', '6'];
export function ScheduleManagementDialog({ open, onClose, baselines, calendars, resources, taskCount, onCreateBaseline, onDeleteBaseline, onCreateCalendar, onUpdateCalendar, onDeleteCalendar, onCreateResource, onUpdateResource, onDeleteResource, }) {
    const labels = useSchedulingLabels();
    const [tab, setTab] = useState('baselines');
    const [baselineName, setBaselineName] = useState('');
    const [baselineIsPrimary, setBaselineIsPrimary] = useState(baselines.length === 0);
    const [calendarName, setCalendarName] = useState('');
    const [calendarDays, setCalendarDays] = useState({
        ...DEFAULT_WORKING_DAYS,
    });
    const [resourceName, setResourceName] = useState('');
    const [resourceKind, setResourceKind] = useState('crew');
    const [resourceCapacity, setResourceCapacity] = useState('1');
    const [resourceCalendarId, setResourceCalendarId] = useState('');
    if (!open)
        return null;
    const weekdayLabel = (key) => new Intl.DateTimeFormat(undefined, { weekday: 'short' }).format(
    // 2024-01-07 was a Sunday, so index 0..6 maps cleanly onto the week.
    new Date(2024, 0, 7 + Number(key), 12));
    return (_jsxs("div", { className: "fixed inset-0 z-50 flex items-center justify-center", "data-testid": "schedule-management", children: [_jsx("div", { className: "absolute inset-0 bg-overlay/30 backdrop-blur-[1px]", onClick: onClose }), _jsxs("div", { role: "dialog", "aria-modal": "true", "aria-label": labels.toolbar.manageSchedule, className: "relative flex w-full max-w-3xl flex-col overflow-hidden rounded-2xl border border-border bg-surface shadow-2xl", style: { height: 'min(88vh, 700px)' }, children: [_jsxs("div", { className: "flex items-start justify-between gap-4 border-b border-border px-5 py-4", children: [_jsxs("div", { children: [_jsx("p", { className: "text-[10px] font-semibold tracking-[0.18em] text-fg-subtle uppercase", children: labels.badges.schedule }), _jsx("h3", { className: "mt-1 text-base font-semibold text-fg", children: labels.toolbar.manageSchedule }), _jsxs("p", { className: "mt-1 text-xs text-fg-muted", children: [labels.format.taskCount(taskCount), " \u00B7 ", calendars.length, "C / ", resources.length, "R"] })] }), _jsx("button", { type: "button", onClick: onClose, "aria-label": labels.editor.cancel, className: "text-fg-subtle transition-colors hover:text-fg", children: _jsx(X, { className: "h-4 w-4" }) })] }), _jsxs("div", { className: "flex min-h-0 flex-1 flex-col px-5 py-4", children: [_jsx(Tabs, { className: "mb-4", value: tab, onValueChange: setTab, tabs: [
                                    { value: 'baselines', label: labels.toolbar.baseline },
                                    { value: 'calendars', label: labels.columns.calendar },
                                    { value: 'resources', label: labels.columns.resources },
                                ] }), _jsxs("div", { className: "sched-scroll min-h-0 flex-1 space-y-4 overflow-y-auto pr-1", children: [tab === 'baselines' ? (_jsxs(_Fragment, { children: [_jsx(List, { empty: labels.menu.noBaselines, items: baselines.map((baseline) => ({
                                                    id: baseline.id,
                                                    title: baseline.name,
                                                    subtitle: baseline.isPrimary ? labels.menu.primary : labels.menu.snapshot,
                                                    badge: baseline.isPrimary ? labels.menu.primary : undefined,
                                                    onDelete: () => void onDeleteBaseline(baseline.id),
                                                    deleteLabel: labels.editor.delete,
                                                })) }), _jsxs(Creator, { title: labels.menu.saveBaseline, disabled: !baselineName.trim(), onCreate: async () => {
                                                    const created = await onCreateBaseline({
                                                        name: baselineName.trim(),
                                                        kind: baselineIsPrimary ? 'primary' : 'snapshot',
                                                        isPrimary: baselineIsPrimary,
                                                    });
                                                    if (created)
                                                        setBaselineName('');
                                                }, createLabel: labels.menu.saveBaseline, children: [_jsx(Input, { value: baselineName, onChange: (event) => setBaselineName(event.target.value), placeholder: labels.toolbar.baseline, "aria-label": labels.toolbar.baseline }), _jsxs("label", { className: "flex items-center gap-2 text-xs text-fg-muted", children: [_jsx("input", { type: "checkbox", checked: baselineIsPrimary, onChange: (event) => setBaselineIsPrimary(event.target.checked), className: "rounded border-border" }), labels.menu.primary] })] })] })) : null, tab === 'calendars' ? (_jsxs(_Fragment, { children: [_jsx("div", { className: "space-y-2", children: calendars.length === 0 ? (_jsx(Empty, { children: labels.common.none })) : (calendars.map((calendar) => (_jsxs("div", { className: "rounded-lg border border-border bg-surface px-3 py-3", children: [_jsxs("div", { className: "flex items-center gap-2", children: [_jsx("span", { className: "min-w-0 flex-1 truncate text-xs font-medium text-fg", children: calendar.name }), calendar.isDefault ? (_jsx(Badge, { variant: "secondary", children: labels.menu.primary })) : (_jsx("button", { type: "button", onClick: () => void onUpdateCalendar(calendar.id, { isDefault: true }), "aria-label": labels.menu.primary, title: labels.menu.primary, className: "text-fg-subtle transition-colors hover:text-primary", children: _jsx(Star, { className: "h-3.5 w-3.5" }) })), _jsx("button", { type: "button", onClick: () => void onDeleteCalendar(calendar.id), "aria-label": labels.editor.delete, className: "text-fg-subtle transition-colors hover:text-danger", children: _jsx(Trash2, { className: "h-3.5 w-3.5" }) })] }), _jsx("div", { className: "mt-2 flex flex-wrap gap-1", children: DAY_KEYS.map((day) => {
                                                                const working = calendar.workingDays?.[day] !== false;
                                                                return (_jsx("button", { type: "button", "aria-pressed": working, onClick: () => void onUpdateCalendar(calendar.id, {
                                                                        workingDays: {
                                                                            ...DEFAULT_WORKING_DAYS,
                                                                            ...calendar.workingDays,
                                                                            [day]: !working,
                                                                        },
                                                                    }), className: cn('rounded-md px-2 py-1 text-[10px] font-medium transition-colors', working
                                                                        ? 'bg-primary-subtle text-primary'
                                                                        : 'bg-bg-subtle text-fg-subtle'), children: weekdayLabel(day) }, day));
                                                            }) })] }, calendar.id)))) }), _jsxs(Creator, { title: labels.columns.calendar, disabled: !calendarName.trim(), onCreate: async () => {
                                                    const created = await onCreateCalendar({
                                                        name: calendarName.trim(),
                                                        workingDays: calendarDays,
                                                        isDefault: calendars.length === 0,
                                                    });
                                                    if (created) {
                                                        setCalendarName('');
                                                        setCalendarDays({ ...DEFAULT_WORKING_DAYS });
                                                    }
                                                }, createLabel: labels.columns.calendar, children: [_jsx(Input, { value: calendarName, onChange: (event) => setCalendarName(event.target.value), placeholder: labels.columns.calendar, "aria-label": labels.columns.calendar }), _jsx("div", { className: "flex flex-wrap gap-1", children: DAY_KEYS.map((day) => {
                                                            const working = calendarDays[day] !== false;
                                                            return (_jsx("button", { type: "button", "aria-pressed": working, onClick: () => setCalendarDays((c) => ({ ...c, [day]: !working })), className: cn('rounded-md px-2 py-1 text-[10px] font-medium transition-colors', working ? 'bg-primary-subtle text-primary' : 'bg-bg-subtle text-fg-subtle'), children: weekdayLabel(day) }, day));
                                                        }) })] })] })) : null, tab === 'resources' ? (_jsxs(_Fragment, { children: [_jsx("div", { className: "space-y-2", children: resources.length === 0 ? (_jsx(Empty, { children: labels.common.none })) : (resources.map((resource) => (_jsxs("div", { className: "grid gap-2 rounded-lg border border-border bg-surface px-3 py-3 md:grid-cols-[minmax(0,1fr)_120px_92px_36px]", children: [_jsxs("div", { className: "min-w-0", children: [_jsx("p", { className: "truncate text-xs font-medium text-fg", children: resource.name }), _jsxs("p", { className: "text-[11px] text-fg-subtle", children: [labels.resourceKind[resource.kind], resource.role ? ` · ${resource.role}` : ''] })] }), _jsxs(Select, { value: resource.calendarId ?? '', onChange: (event) => void onUpdateResource(resource.id, {
                                                                calendarId: event.target.value || null,
                                                            }), "aria-label": labels.columns.calendar, children: [_jsx("option", { value: "", children: labels.editor.defaultCalendar }), calendars.map((calendar) => (_jsx("option", { value: calendar.id, children: calendar.name }, calendar.id)))] }), _jsx(Input, { type: "number", step: "0.25", value: String(resource.capacityPerDay), "aria-label": labels.leveling.capacity, onChange: (event) => void onUpdateResource(resource.id, {
                                                                capacityPerDay: Number.parseFloat(event.target.value || '1') || 1,
                                                            }) }), _jsx("button", { type: "button", onClick: () => void onDeleteResource(resource.id), "aria-label": labels.editor.delete, className: "text-fg-subtle transition-colors hover:text-danger", children: _jsx(Trash2, { className: "h-3.5 w-3.5" }) })] }, resource.id)))) }), _jsxs(Creator, { title: labels.columns.resources, disabled: !resourceName.trim(), onCreate: async () => {
                                                    const capacity = Number.parseFloat(resourceCapacity || '1') || 1;
                                                    const created = await onCreateResource({
                                                        name: resourceName.trim(),
                                                        kind: resourceKind,
                                                        calendarId: resourceCalendarId || null,
                                                        defaultUnits: 1,
                                                        capacityPerDay: capacity,
                                                    });
                                                    if (created) {
                                                        setResourceName('');
                                                        setResourceCapacity('1');
                                                    }
                                                }, createLabel: labels.columns.resources, children: [_jsx(Input, { value: resourceName, onChange: (event) => setResourceName(event.target.value), placeholder: labels.columns.resources, "aria-label": labels.columns.resources }), _jsxs("div", { className: "grid gap-2 md:grid-cols-3", children: [_jsx(Select, { value: resourceKind, onChange: (event) => setResourceKind(event.target.value), "aria-label": labels.columns.resources, children: Object.keys(labels.resourceKind).map((kind) => (_jsx("option", { value: kind, children: labels.resourceKind[kind] }, kind))) }), _jsxs(Select, { value: resourceCalendarId, onChange: (event) => setResourceCalendarId(event.target.value), "aria-label": labels.columns.calendar, children: [_jsx("option", { value: "", children: labels.editor.defaultCalendar }), calendars.map((calendar) => (_jsx("option", { value: calendar.id, children: calendar.name }, calendar.id)))] }), _jsx(Input, { type: "number", step: "0.25", value: resourceCapacity, "aria-label": labels.leveling.capacity, onChange: (event) => setResourceCapacity(event.target.value) })] })] })] })) : null] })] })] })] }));
}
function List({ items, empty, }) {
    if (items.length === 0)
        return _jsx(Empty, { children: empty });
    return (_jsx("div", { className: "space-y-2", children: items.map((item) => (_jsxs("div", { className: "flex items-center gap-2 rounded-lg border border-border bg-surface px-3 py-2", children: [_jsxs("div", { className: "min-w-0 flex-1", children: [_jsx("p", { className: "truncate text-xs font-medium text-fg", children: item.title }), item.subtitle ? _jsx("p", { className: "text-[11px] text-fg-subtle", children: item.subtitle }) : null] }), item.badge ? _jsx(Badge, { variant: "secondary", children: item.badge }) : null, _jsx("button", { type: "button", onClick: item.onDelete, "aria-label": item.deleteLabel, className: "text-fg-subtle transition-colors hover:text-danger", children: _jsx(Trash2, { className: "h-3.5 w-3.5" }) })] }, item.id))) }));
}
function Creator({ title, children, onCreate, createLabel, disabled, }) {
    return (_jsxs("div", { className: "space-y-2 rounded-xl border border-dashed border-border p-4", children: [_jsx(Label, { children: title }), children, _jsxs(Button, { variant: "secondary", size: "sm", disabled: disabled, onClick: () => void onCreate(), children: [_jsx(Plus, { className: "h-3.5 w-3.5" }), createLabel] })] }));
}
function Empty({ children }) {
    return _jsx("p", { className: "text-xs text-fg-subtle", children: children });
}
//# sourceMappingURL=schedule-management.js.map