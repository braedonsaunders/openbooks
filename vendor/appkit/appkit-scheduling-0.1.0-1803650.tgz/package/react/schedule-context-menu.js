'use client';
import { jsx as _jsx, Fragment as _Fragment, jsxs as _jsxs } from "react/jsx-runtime";
/**
 * Right-click menu for a task row: edit, outline moves, type conversion,
 * status, duplicate, delete.
 *
 * Type conversion carries the field changes the new type implies — converting
 * to a milestone zeroes the duration and pins the finish to the start, because
 * a "milestone" that still spans five days is a bar wearing a diamond.
 */
import { useCallback, useEffect, useRef, useState } from 'react';
import { ArrowDown, ArrowUp, CheckCircle2, ChevronRight, Circle, Clock, Copy, Diamond, Pause, Pencil, Plus, Trash2, } from 'lucide-react';
import { cn } from '@appkit/ui';
import { useSchedulingLabels } from './context.js';
const STATUS_ICONS = {
    not_started: Circle,
    in_progress: Clock,
    on_hold: Pause,
    complete: CheckCircle2,
};
const STATUS_ORDER = ['not_started', 'in_progress', 'on_hold', 'complete'];
/** Menu box estimate, used only to keep it inside the viewport. */
const MENU_WIDTH = 220;
const MENU_HEIGHT = 430;
const VIEWPORT_MARGIN = 8;
export function ScheduleContextMenu({ menu, onClose, onEdit, onDelete, onUpdate, onDuplicate, onCreateSibling, onCreateChild, onIndent, onOutdent, onMove, }) {
    const labels = useSchedulingLabels();
    const ref = useRef(null);
    const [statusOpen, setStatusOpen] = useState(false);
    useEffect(() => {
        if (!menu)
            return;
        const handlePointer = (event) => {
            if (ref.current && !ref.current.contains(event.target))
                onClose();
        };
        const handleKey = (event) => {
            if (event.key === 'Escape')
                onClose();
        };
        document.addEventListener('mousedown', handlePointer);
        document.addEventListener('keydown', handleKey);
        return () => {
            document.removeEventListener('mousedown', handlePointer);
            document.removeEventListener('keydown', handleKey);
        };
    }, [menu, onClose]);
    useEffect(() => setStatusOpen(false), [menu]);
    if (!menu)
        return null;
    const { x, y, task } = menu;
    const clampedX = Math.min(x, window.innerWidth - MENU_WIDTH - VIEWPORT_MARGIN);
    const clampedY = Math.min(y, window.innerHeight - MENU_HEIGHT - VIEWPORT_MARGIN);
    const act = (fn) => () => {
        fn();
        onClose();
    };
    return (_jsxs("div", { ref: ref, role: "menu", "data-testid": "schedule-context-menu", className: "fixed z-[100] min-w-[220px] rounded-lg border border-border bg-elevated py-1 text-xs shadow-xl", style: { left: clampedX, top: clampedY }, children: [_jsx(MenuItem, { icon: Pencil, label: labels.editor.title, onClick: act(() => onEdit(task)) }), onCreateSibling && (_jsx(MenuItem, { icon: Plus, label: labels.toolbar.addTask, onClick: act(() => onCreateSibling(task)) })), onCreateChild && (_jsx(MenuItem, { icon: Plus, label: `${labels.toolbar.addTask} — ${labels.badges.summary}`, onClick: act(() => onCreateChild(task)) })), _jsx(Separator, {}), onIndent && (_jsx(MenuItem, { icon: ChevronRight, label: labels.toolbar.indent, onClick: act(() => onIndent(task.id)) })), onOutdent && (_jsx(MenuItem, { icon: ChevronRight, iconClassName: "rotate-180", label: labels.toolbar.outdent, onClick: act(() => onOutdent(task.id)) })), onMove && (_jsxs(_Fragment, { children: [_jsx(MenuItem, { icon: ArrowUp, label: labels.menu.earlier, onClick: act(() => onMove(task.id, 'up')) }), _jsx(MenuItem, { icon: ArrowDown, label: labels.menu.later, onClick: act(() => onMove(task.id, 'down')) })] })), _jsx(Separator, {}), task.taskType !== 'task' ? (_jsx(MenuItem, { icon: Diamond, label: labels.taskType.task, onClick: act(() => onUpdate(task.id, { taskType: 'task', duration: Math.max(task.duration, 1) })) })) : null, task.taskType !== 'milestone' ? (_jsx(MenuItem, { icon: Diamond, label: labels.taskType.milestone, onClick: act(() => onUpdate(task.id, {
                    taskType: 'milestone',
                    duration: 0,
                    progress: 0,
                    endDate: task.startDate,
                })) })) : null, task.taskType !== 'summary' ? (_jsx(MenuItem, { icon: Diamond, label: labels.taskType.summary, onClick: act(() => onUpdate(task.id, { taskType: 'summary', duration: Math.max(task.duration, 1) })) })) : null, _jsx(Separator, {}), _jsxs("div", { className: "relative", onMouseEnter: () => setStatusOpen(true), onMouseLeave: () => setStatusOpen(false), children: [_jsxs("div", { className: "flex cursor-pointer items-center gap-2 px-3 py-1.5 text-fg-muted transition-colors hover:bg-surface-hover", children: [_jsx(Clock, { className: "h-3.5 w-3.5 text-fg-subtle" }), _jsx("span", { className: "flex-1", children: labels.columns.status }), _jsx(ChevronRight, { className: "h-3.5 w-3.5 text-fg-subtle" })] }), statusOpen && (_jsx("div", { className: "absolute top-0 left-full ml-1 min-w-[170px] rounded-lg border border-border bg-elevated py-1 shadow-xl", children: STATUS_ORDER.map((status) => {
                            const Icon = STATUS_ICONS[status];
                            const isActive = task.status === status;
                            return (_jsxs("div", { className: cn('flex cursor-pointer items-center gap-2 px-3 py-1.5 transition-colors', isActive
                                    ? 'bg-primary-subtle text-primary'
                                    : 'text-fg-muted hover:bg-surface-hover'), onClick: act(() => onUpdate(task.id, {
                                    status,
                                    ...(status === 'complete' ? { progress: 1 } : {}),
                                })), children: [_jsx(Icon, { className: "h-3.5 w-3.5" }), _jsx("span", { children: labels.status[status] }), isActive ? _jsx(CheckCircle2, { className: "ml-auto h-3 w-3" }) : null] }, status));
                        }) }))] }), onDuplicate && (_jsx(MenuItem, { icon: Copy, label: labels.menu.snapshot, onClick: act(() => onDuplicate(task)) })), _jsx(Separator, {}), _jsx(MenuItem, { icon: Trash2, label: labels.editor.delete, danger: true, onClick: act(() => onDelete(task.id)) })] }));
}
function MenuItem({ icon: Icon, label, onClick, danger, iconClassName, }) {
    return (_jsxs("div", { role: "menuitem", className: cn('flex cursor-pointer items-center gap-2 px-3 py-1.5 transition-colors', danger ? 'text-danger hover:bg-danger-subtle' : 'text-fg-muted hover:bg-surface-hover'), onClick: onClick, children: [_jsx(Icon, { className: cn('h-3.5 w-3.5', iconClassName) }), _jsx("span", { children: label })] }));
}
function Separator() {
    return _jsx("div", { className: "my-1 border-t border-border" });
}
/** Track right-click position and target task for the menu above. */
export function useScheduleContextMenu() {
    const [menu, setMenu] = useState(null);
    const handleContextMenu = useCallback((event, task) => {
        event.preventDefault();
        event.stopPropagation();
        setMenu({ x: event.clientX, y: event.clientY, task });
    }, []);
    const closeMenu = useCallback(() => setMenu(null), []);
    return { menu, handleContextMenu, closeMenu };
}
//# sourceMappingURL=schedule-context-menu.js.map