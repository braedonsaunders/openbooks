'use client';
import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
/**
 * Resource leveling, as a review step rather than a button that rewrites the
 * plan.
 *
 * The panel previews every proposed move, names what could NOT be solved and
 * why, states how far the finish date would move, and shows the load histogram
 * that motivated it. Applying is a separate, explicit action — a scheduler
 * whose dates changed without warning stops trusting the tool.
 */
import { useMemo, useState } from 'react';
import { ArrowRight, Scale, X } from 'lucide-react';
import { Badge, Button, cn } from '@appkit/ui';
import { buildResourceLoadSeries, levelResources, } from '../leveling.js';
import { scheduleColors } from '../palette.js';
import { useSchedulingLabels } from './context.js';
/** Histogram bars rendered per resource before the series is truncated. */
const MAX_HISTOGRAM_DAYS = 60;
export function LevelingPanel({ open, onClose, tasks, dependencies, calendars, resources, assignments, onApply, }) {
    const labels = useSchedulingLabels();
    const [withinFloatOnly, setWithinFloatOnly] = useState(true);
    const [freezeStartedTasks, setFreezeStartedTasks] = useState(true);
    const [applying, setApplying] = useState(false);
    const result = useMemo(() => levelResources(tasks, dependencies, {
        calendars,
        resources,
        assignments,
        withinFloatOnly,
        freezeStartedTasks,
    }), [assignments, calendars, dependencies, freezeStartedTasks, resources, tasks, withinFloatOnly]);
    const loadSeries = useMemo(() => buildResourceLoadSeries(tasks, { calendars, resources, assignments }), [assignments, calendars, resources, tasks]);
    if (!open)
        return null;
    const reasonLabel = (reason) => reason === 'exceeds_float'
        ? labels.leveling.reasonExceedsFloat
        : reason === 'capacity_below_demand'
            ? labels.leveling.reasonCapacityBelowDemand
            : labels.leveling.reasonExceedsWindow;
    const resourceName = (id) => resources.find((r) => r.id === id)?.name ?? id;
    return (_jsxs("div", { className: "fixed inset-0 z-50 flex items-center justify-center", "data-testid": "schedule-leveling", children: [_jsx("div", { className: "absolute inset-0 bg-overlay/30 backdrop-blur-[1px]", onClick: onClose }), _jsxs("div", { role: "dialog", "aria-modal": "true", "aria-label": labels.leveling.heading, className: "relative flex w-full max-w-3xl flex-col overflow-hidden rounded-2xl border border-border bg-surface shadow-2xl", style: { height: 'min(88vh, 720px)' }, children: [_jsxs("div", { className: "flex items-start justify-between gap-4 border-b border-border px-5 py-4", children: [_jsxs("div", { className: "min-w-0", children: [_jsxs("p", { className: "flex items-center gap-1.5 text-[10px] font-semibold tracking-[0.18em] text-fg-subtle uppercase", children: [_jsx(Scale, { className: "h-3 w-3" }), labels.badges.schedule] }), _jsx("h3", { className: "mt-1 text-base font-semibold text-fg", children: labels.leveling.heading }), _jsx("p", { className: "mt-1 text-xs text-fg-muted", children: labels.leveling.description })] }), _jsx("button", { type: "button", onClick: onClose, "aria-label": labels.editor.cancel, className: "text-fg-subtle transition-colors hover:text-fg", children: _jsx(X, { className: "h-4 w-4" }) })] }), _jsxs("div", { className: "flex flex-wrap items-center gap-4 border-b border-border bg-bg-subtle px-5 py-3 text-xs text-fg-muted", children: [_jsxs("label", { className: "flex items-center gap-2", children: [_jsx("input", { type: "checkbox", checked: withinFloatOnly, onChange: (event) => setWithinFloatOnly(event.target.checked), className: "rounded border-border" }), labels.leveling.withinFloatOnly] }), _jsxs("label", { className: "flex items-center gap-2", children: [_jsx("input", { type: "checkbox", checked: freezeStartedTasks, onChange: (event) => setFreezeStartedTasks(event.target.checked), className: "rounded border-border" }), labels.leveling.freezeStartedTasks] }), _jsxs("div", { className: "ml-auto flex items-center gap-2", children: [_jsxs(Badge, { variant: result.moves.length > 0 ? 'info' : 'secondary', children: [result.moves.length, " ", labels.leveling.movesSummary] }), _jsxs(Badge, { variant: result.unresolved.length > 0 ? 'warning' : 'secondary', children: [result.unresolved.length, " ", labels.leveling.unresolvedSummary] }), result.projectDelayDays > 0 ? (_jsxs(Badge, { variant: "destructive", children: [labels.leveling.projectDelay, " ", labels.format.days(result.projectDelayDays)] })) : null] })] }), _jsxs("div", { className: "sched-scroll min-h-0 flex-1 space-y-5 overflow-y-auto px-5 py-4", children: [result.hasCycle ? (_jsx("p", { className: "rounded-lg bg-danger-subtle px-3 py-2 text-xs text-danger", children: labels.insights.cycleDetected })) : null, _jsxs("section", { className: "space-y-2", children: [_jsx("h4", { className: "text-xs font-semibold tracking-[0.16em] text-fg-subtle uppercase", children: labels.leveling.preview }), result.moves.length === 0 ? (_jsx("p", { className: "text-xs text-fg-subtle", children: labels.leveling.noMoves })) : (_jsx("div", { className: "space-y-1.5", children: result.moves.map((move) => (_jsxs("div", { className: "flex items-center gap-3 rounded-lg border border-border bg-surface px-3 py-2 text-xs", children: [_jsx("span", { className: "min-w-0 flex-1 truncate text-fg", children: move.taskName }), _jsx("span", { className: "shrink-0 text-fg-subtle", children: move.fromStart ?? '—' }), _jsx(ArrowRight, { className: "h-3 w-3 shrink-0 text-fg-subtle" }), _jsx("span", { className: "shrink-0 font-medium text-fg", children: move.toStart }), _jsxs(Badge, { variant: "secondary", children: ["+", labels.format.days(move.delayDays)] }), move.blockedByResourceIds.length > 0 ? (_jsx("span", { className: "hidden shrink-0 text-[11px] text-fg-subtle sm:inline", children: move.blockedByResourceIds.map(resourceName).join(', ') })) : null] }, move.taskId))) }))] }), result.unresolved.length > 0 ? (_jsxs("section", { className: "space-y-2", children: [_jsx("h4", { className: "text-xs font-semibold tracking-[0.16em] text-fg-subtle uppercase", children: labels.leveling.unresolvedSummary }), _jsx("div", { className: "space-y-1.5", children: result.unresolved.map((conflict) => (_jsxs("div", { className: "rounded-lg border border-warning/30 bg-warning-subtle px-3 py-2 text-xs", children: [_jsx("p", { className: "truncate font-medium text-fg", children: conflict.taskName }), _jsxs("p", { className: "mt-0.5 text-[11px] text-fg-muted", children: [reasonLabel(conflict.reason), conflict.resourceIds.length > 0
                                                            ? ` · ${conflict.resourceIds.map(resourceName).join(', ')}`
                                                            : '', ` · ${labels.format.days(conflict.requiredDelayDays)}`] })] }, conflict.taskId))) })] })) : null, _jsxs("section", { className: "space-y-3", children: [_jsx("h4", { className: "text-xs font-semibold tracking-[0.16em] text-fg-subtle uppercase", children: labels.leveling.load }), loadSeries.length === 0 ? (_jsx("p", { className: "text-xs text-fg-subtle", children: labels.common.none })) : (loadSeries.map((series) => {
                                        const days = series.days.slice(0, MAX_HISTOGRAM_DAYS);
                                        const peak = Math.max(series.peakLoad, series.capacityPerDay, 1);
                                        return (_jsxs("div", { className: "space-y-1", children: [_jsxs("div", { className: "flex items-center justify-between text-[11px]", children: [_jsx("span", { className: "truncate font-medium text-fg", children: series.resourceName }), _jsxs("span", { className: "text-fg-subtle", children: [labels.leveling.capacity, " ", series.capacityPerDay, " \u00B7", ' ', series.overloadedDays, " ", labels.leveling.overloadedDays] })] }), _jsx("div", { className: "flex h-10 items-end gap-px", children: days.map((day) => (_jsx("div", { title: `${day.date}: ${day.load} / ${day.capacity}`, className: cn('w-full min-w-[2px] rounded-t-sm'), style: {
                                                            height: `${Math.max(4, (day.load / peak) * 100)}%`,
                                                            backgroundColor: day.overload > 0 ? scheduleColors.overload() : 'var(--color-primary)',
                                                        } }, day.date))) })] }, series.resourceId));
                                    }))] })] }), _jsxs("div", { className: "flex items-center gap-2 border-t border-border px-5 py-4", children: [_jsx("div", { className: "flex-1" }), _jsx(Button, { variant: "ghost", size: "sm", onClick: onClose, children: labels.editor.cancel }), _jsx(Button, { size: "sm", disabled: result.moves.length === 0 || applying, "data-testid": "schedule-leveling-apply", onClick: async () => {
                                    setApplying(true);
                                    try {
                                        if (await onApply(result.moves))
                                            onClose();
                                    }
                                    finally {
                                        setApplying(false);
                                    }
                                }, children: labels.leveling.apply })] })] })] }));
}
//# sourceMappingURL=leveling-panel.js.map