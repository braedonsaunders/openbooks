import type { ScheduleBaseline, ScheduleBaselineKind, ScheduleCalendar, ScheduleResource, ScheduleResourceKind } from '../types.js';
export interface ScheduleCalendarInput {
    name: string;
    description?: string;
    workingDays: Record<string, boolean>;
    isDefault?: boolean;
}
export interface ScheduleResourceInput {
    name: string;
    role?: string;
    kind: ScheduleResourceKind;
    calendarId?: string | null;
    defaultUnits: number;
    capacityPerDay: number;
    costRate?: number;
}
export interface ScheduleBaselineInput {
    name: string;
    description?: string;
    kind: ScheduleBaselineKind;
    isPrimary: boolean;
}
export interface ScheduleManagementDialogProps {
    open: boolean;
    onClose: () => void;
    baselines: ScheduleBaseline[];
    calendars: ScheduleCalendar[];
    resources: ScheduleResource[];
    taskCount: number;
    onCreateBaseline: (input: ScheduleBaselineInput) => Promise<boolean>;
    onDeleteBaseline: (baselineId: string) => Promise<boolean>;
    onCreateCalendar: (input: ScheduleCalendarInput) => Promise<boolean>;
    onUpdateCalendar: (calendarId: string, patch: Partial<ScheduleCalendarInput>) => Promise<boolean>;
    onDeleteCalendar: (calendarId: string) => Promise<boolean>;
    onCreateResource: (input: ScheduleResourceInput) => Promise<boolean>;
    onUpdateResource: (resourceId: string, patch: Partial<ScheduleResourceInput>) => Promise<boolean>;
    onDeleteResource: (resourceId: string) => Promise<boolean>;
}
export declare function ScheduleManagementDialog({ open, onClose, baselines, calendars, resources, taskCount, onCreateBaseline, onDeleteBaseline, onCreateCalendar, onUpdateCalendar, onDeleteCalendar, onCreateResource, onUpdateResource, onDeleteResource, }: ScheduleManagementDialogProps): import("react").JSX.Element | null;
//# sourceMappingURL=schedule-management.d.ts.map