/**
 * Calendar-day arithmetic for schedules.
 *
 * Every date this module produces is normalized to local noon. A schedule bar
 * is a calendar-day range, and noon is the one instant per day that survives
 * both DST transitions and `toLocaleDateString` without sliding into the
 * neighbouring day — the difference between a plan that reads "Mar 10" and one
 * that silently renders "Mar 9" for half the world.
 */
import type { ScheduleCalendar } from './types.js';
export declare const MS_PER_DAY = 86400000;
export declare function normalizeCalendarDate(date: Date): Date;
export declare function startOfNextMonth(date: Date): Date;
export declare function monthKey(date: Date): string;
export declare function yearKey(date: Date): string;
export declare function isNonWorkingDay(date: Date, calendar?: ScheduleCalendar | null): boolean;
export declare function isWorkingDay(date: Date, calendar?: ScheduleCalendar | null): boolean;
export declare function todayDate(): Date;
export declare function addDays(date: Date, days: number): Date;
/** Whole calendar days between two dates (a − b), DST-safe. */
export declare function diffDays(a: Date, b: Date): number;
/**
 * Advance by `days` WORKING days on `calendar`. Non-working days are skipped
 * rather than counted, which is what "3 days of work" means to a scheduler.
 */
export declare function addWorkingDays(date: Date, days: number, calendar?: ScheduleCalendar | null): Date;
/** The next working day at or after `date`. */
export declare function nextWorkingDay(date: Date, calendar?: ScheduleCalendar | null): Date;
/** Working days in `[start, end)`, or 1 for a same-day/zero-length span. */
export declare function countWorkingDays(start: Date, end: Date, calendar?: ScheduleCalendar | null): number;
export declare function formatISODate(date: Date): string;
export declare function startOfWeek(date: Date): Date;
export declare function startOfMonth(date: Date): Date;
/** Parse `YYYY-MM-DD` (or anything `Date` accepts) into a noon-normalized date. */
export declare function parseDate(value: string | null | undefined): Date | null;
export declare function snapToDay(ms: number): Date;
/**
 * Timeline header/label formatting. Hosts pass their own locale (and may pass
 * their own formatters entirely) — nothing here hardcodes English.
 */
export interface ScheduleDateFormatters {
    shortDate: (date: Date) => string;
    monthYear: (date: Date) => string;
    monthShort: (date: Date) => string;
    weekdayShort: (date: Date) => string;
}
export declare function createDateFormatters(locale?: string): ScheduleDateFormatters;
/** Formatters bound to the runtime's default locale. */
export declare const defaultDateFormatters: ScheduleDateFormatters;
export declare function formatShortDate(date: Date): string;
export declare function formatMonthYear(date: Date): string;
export declare function formatMonthShort(date: Date): string;
export declare function formatWeekdayShort(date: Date): string;
//# sourceMappingURL=dates.d.ts.map