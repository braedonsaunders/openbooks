/**
 * Timeline geometry: the columns a Gantt draws, the bands above them, and
 * where a bar sits inside the visible span.
 *
 * Column counts are capped per zoom level. A five-year plan at day zoom is
 * ~1,800 DOM columns per row — the cap keeps a mis-typed date from freezing
 * the browser.
 */
import { type ScheduleDateFormatters } from './dates.js';
import type { ScheduleCalendar, SchedulePhase, ScheduleTask, TaskGroup, TimelineColumn, TimelineHeaderBand, ZoomLevel } from './types.js';
/** Fraction-of-span placement for one bar, clipped to the visible window. */
export declare function getBarPosition(startDate: Date, endDate: Date, timelineStartMs: number, timelineEndMs: number): {
    left: number;
    width: number;
};
/** Phase bands derived from their tasks, falling back to the stored dates. */
export declare function computePhaseDatesFromTasks(tasks: ScheduleTask[], phases: SchedulePhase[]): Map<string, {
    startDate: Date;
    endDate: Date;
}>;
export declare function groupTasksByPhase(tasks: ScheduleTask[], phases: SchedulePhase[], phaseDates: Map<string, {
    startDate: Date;
    endDate: Date;
}>): TaskGroup[];
export declare function generateColumns(start: Date, end: Date, zoomLevel: ZoomLevel, calendar?: ScheduleCalendar | null, formatters?: ScheduleDateFormatters): TimelineColumn[];
/** Collapse columns into their parent bands (months over days, years over months). */
export declare function buildTimelineHeaderBands(columns: TimelineColumn[]): TimelineHeaderBand[];
export declare function getTimelineBounds(columns: TimelineColumn[], zoomLevel: ZoomLevel): {
    startMs: number;
    endMs: number;
};
/** CSS-percentage position of the today marker, or null when off-screen. */
export declare function getTodayPosition(timelineStartMs: number, timelineEndMs: number): string | null;
/** Drag a bar or one of its edges by a pixel-derived millisecond delta. */
export declare function applyDragDelta(startDate: Date, endDate: Date, deltaMs: number, edge: 'start' | 'end' | 'move'): {
    startDate: Date;
    endDate: Date;
};
//# sourceMappingURL=timeline.d.ts.map