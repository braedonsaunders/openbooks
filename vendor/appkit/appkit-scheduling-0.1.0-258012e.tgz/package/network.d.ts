/**
 * The dependency network: critical-path analysis, logic violations, and cycle
 * detection.
 *
 * Forward pass → early start/finish. Backward pass → late start/finish. Total
 * float is the difference; zero float is the critical path. Summary rows are
 * excluded throughout — they are derived from their children, so scheduling
 * them would double-count the same work in the longest path.
 */
import type { DependencyEdge, ScheduleDependency, ScheduleDependencyViolation, ScheduleNetworkSummary, ScheduleTask } from './types.js';
/** Actual dates win over planned ones — the network follows reality. */
export declare function getTaskDuration(task: ScheduleTask): number;
export declare function buildDependencyEdges(dependencies: ScheduleDependency[]): DependencyEdge[];
/** The two dates a dependency arrow is drawn between. */
export declare function resolveDependencyAnchorDates(dependency: ScheduleDependency, predecessor: ScheduleTask, successor: ScheduleTask): {
    from: Date;
    to: Date;
} | null;
/**
 * Slack between the two anchored dates, net of lag. Negative means the planned
 * dates contradict the logic (the successor starts before its predecessor
 * allows).
 */
export declare function getDependencyGapDays(dependency: ScheduleDependency, predecessor: ScheduleTask, successor: ScheduleTask): number | null;
export declare function computeDependencyViolations(tasks: ScheduleTask[], dependencies: ScheduleDependency[]): ScheduleDependencyViolation[];
/**
 * Would linking these two tasks close a loop? Call this BEFORE persisting a
 * dependency: a cycle makes the critical path undefined for the whole plan.
 */
export declare function wouldCreateDependencyCycle(dependencies: ScheduleDependency[], predecessorId: string, successorId: string): boolean;
/**
 * Full CPM pass. Returns total float per task and the critical set, or
 * `hasCycle` when the logic contains a loop (in which case float is undefined
 * and reported as empty rather than guessed at).
 */
export declare function analyzeScheduleNetwork(tasks: ScheduleTask[], dependencies: ScheduleDependency[]): ScheduleNetworkSummary;
export declare function computeCriticalPath(tasks: ScheduleTask[], dependencies: ScheduleDependency[]): Set<string>;
//# sourceMappingURL=network.d.ts.map