# @appkit/scheduling

Project scheduling: CPM critical path, calendars, resource leveling, baselines, and the Gantt/list/board authoring surface.

## Install

```bash
pnpm add @appkit/scheduling
```

See the [AppKit documentation](https://github.com/braedonsaunders/appkit#readme) for package composition, optional adapters, and production guidance.
