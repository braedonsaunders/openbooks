'use client';
import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
/** Structured filter bar: phase, status, assignee and a date window. */
import { X } from 'lucide-react';
import { Button, Input, Select, cn } from '@appkit/ui';
import { emptyFilters } from '../types.js';
import { useSchedulingLabels } from './context.js';
const ALL = '__all__';
export function ScheduleFiltersBar({ filters, onChange, phases, assignees, className, }) {
    const labels = useSchedulingLabels();
    const hasFilters = filters.phaseIds.length > 0 ||
        filters.statuses.length > 0 ||
        filters.assignees.length > 0 ||
        !!filters.dateFrom ||
        !!filters.dateTo;
    return (_jsxs("div", { className: cn('flex flex-wrap items-center gap-3 rounded-lg border border-border bg-bg-subtle px-3 py-2', className), "data-testid": "schedule-filters", children: [_jsx(Field, { label: labels.columns.phase, children: _jsxs(Select, { value: filters.phaseIds[0] ?? ALL, onChange: (event) => onChange({
                        ...filters,
                        phaseIds: event.target.value === ALL ? [] : [event.target.value],
                    }), triggerClassName: "h-7 w-36 text-xs", "aria-label": labels.columns.phase, children: [_jsx("option", { value: ALL, children: labels.quickFilter.all }), phases.map((phase) => (_jsxs("option", { value: phase.id, children: [phase.number ? `${phase.number}. ` : '', phase.name] }, phase.id)))] }) }), _jsx(Field, { label: labels.columns.status, children: _jsxs(Select, { value: filters.statuses[0] ?? ALL, onChange: (event) => onChange({
                        ...filters,
                        statuses: event.target.value === ALL ? [] : [event.target.value],
                    }), triggerClassName: "h-7 w-36 text-xs", "aria-label": labels.columns.status, children: [_jsx("option", { value: ALL, children: labels.quickFilter.all }), Object.keys(labels.status).map((status) => (_jsx("option", { value: status, children: labels.status[status] }, status)))] }) }), assignees.length > 0 && (_jsx(Field, { label: labels.columns.assignee, children: _jsxs(Select, { value: filters.assignees[0] ?? ALL, onChange: (event) => onChange({
                        ...filters,
                        assignees: event.target.value === ALL ? [] : [event.target.value],
                    }), triggerClassName: "h-7 w-36 text-xs", "aria-label": labels.columns.assignee, children: [_jsx("option", { value: ALL, children: labels.quickFilter.all }), assignees.map((assignee) => (_jsx("option", { value: assignee, children: assignee }, assignee)))] }) })), _jsx(Field, { label: labels.columns.start, children: _jsx(Input, { type: "date", value: filters.dateFrom ?? '', onChange: (e) => onChange({ ...filters, dateFrom: e.target.value || null }), className: "h-7 w-36 text-xs", "aria-label": labels.columns.start }) }), _jsx(Field, { label: labels.columns.finish, children: _jsx(Input, { type: "date", value: filters.dateTo ?? '', onChange: (e) => onChange({ ...filters, dateTo: e.target.value || null }), className: "h-7 w-36 text-xs", "aria-label": labels.columns.finish }) }), hasFilters && (_jsxs(Button, { variant: "ghost", size: "sm", onClick: () => onChange(emptyFilters), className: "h-7", children: [_jsx(X, { className: "h-3 w-3" }), labels.toolbar.clearFilters] }))] }));
}
function Field({ label, children }) {
    return (_jsxs("div", { className: "flex items-center gap-1.5", children: [_jsx("span", { className: "text-xs text-fg-muted", children: label }), children] }));
}
//# sourceMappingURL=schedule-filters.js.map