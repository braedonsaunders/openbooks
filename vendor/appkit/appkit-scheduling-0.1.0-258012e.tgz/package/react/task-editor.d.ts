import type { SchedulePhase, ScheduleCalendar, ScheduleDependency, ScheduleDependencyInput, ScheduleInsights, ScheduleResource, ScheduleTask, ScheduleTaskAssignment, ScheduleTaskPatchInput } from '../types.js';
export interface TaskEditorProps {
    task: ScheduleTask;
    phases: SchedulePhase[];
    allTasks: ScheduleTask[];
    dependencies: ScheduleDependency[];
    insights: ScheduleInsights;
    calendars: ScheduleCalendar[];
    resources: ScheduleResource[];
    taskAssignments: ScheduleTaskAssignment[];
    onSave: (taskId: string, patch: ScheduleTaskPatchInput) => Promise<boolean>;
    onDelete: (taskId: string) => Promise<boolean>;
    onCreateDependency: (input: ScheduleDependencyInput) => Promise<boolean>;
    onDeleteDependency: (depId: string) => Promise<boolean>;
    onClose: () => void;
}
export declare function TaskEditor({ task, phases, allTasks, dependencies, insights, calendars, resources, taskAssignments, onSave, onDelete, onCreateDependency, onDeleteDependency, onClose, }: TaskEditorProps): import("react").JSX.Element;
//# sourceMappingURL=task-editor.d.ts.map