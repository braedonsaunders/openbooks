/** The rotated diamond every schedule uses for a zero-duration event. */
export declare function MilestoneMarker({ color, size, className, }: {
    /** CSS colour; defaults to the third phase hue (amber in the base palette). */
    color?: string;
    size?: number;
    className?: string;
}): import("react").JSX.Element;
//# sourceMappingURL=milestone-marker.d.ts.map