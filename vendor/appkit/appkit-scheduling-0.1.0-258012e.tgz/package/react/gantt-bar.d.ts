export interface GanttBarProps {
    taskId: string;
    startDate: Date;
    endDate: Date;
    progress: number;
    /** Resolved CSS colour for the bar fill (see `phaseColor`). */
    color: string;
    isCritical: boolean;
    taskName: string;
    timelineStartMs: number;
    timelineEndMs: number;
    variant?: 'task' | 'summary';
    isDraggable?: boolean;
    /** Return `false` to reject the drag and restore the original dates. */
    onDragEnd: (newStart: Date, newEnd: Date) => void | boolean | Promise<boolean | void>;
    onClick: () => void;
}
export declare function GanttBar({ taskId, startDate, endDate, progress, color, isCritical, taskName, timelineStartMs, timelineEndMs, variant, isDraggable, onDragEnd, onClick, }: GanttBarProps): import("react").JSX.Element;
//# sourceMappingURL=gantt-bar.d.ts.map