import type { ScheduleData, ScheduleDependencyInput, ScheduleTaskPatchInput } from '../types.js';
import { type ScheduleBaselineInput, type ScheduleCalendarInput, type ScheduleResourceInput } from './schedule-management.js';
/**
 * Everything the workspace can ask the host to persist. Every method resolves
 * `true` on success; returning `false` rolls back the optimistic UI instead of
 * leaving the screen disagreeing with the database.
 */
export interface ScheduleAdapter {
    createTask: (input: ScheduleTaskPatchInput & {
        name: string;
    }) => Promise<boolean>;
    updateTask: (taskId: string, patch: ScheduleTaskPatchInput) => Promise<boolean>;
    batchUpdateTasks: (updates: Array<{
        id: string;
    } & ScheduleTaskPatchInput>) => Promise<boolean>;
    deleteTask: (taskId: string) => Promise<boolean>;
    createDependency: (input: ScheduleDependencyInput) => Promise<boolean>;
    deleteDependency: (dependencyId: string) => Promise<boolean>;
    createCalendar?: (input: ScheduleCalendarInput) => Promise<boolean>;
    updateCalendar?: (calendarId: string, patch: Partial<ScheduleCalendarInput>) => Promise<boolean>;
    deleteCalendar?: (calendarId: string) => Promise<boolean>;
    createResource?: (input: ScheduleResourceInput) => Promise<boolean>;
    updateResource?: (resourceId: string, patch: Partial<ScheduleResourceInput>) => Promise<boolean>;
    deleteResource?: (resourceId: string) => Promise<boolean>;
    createBaseline?: (input: ScheduleBaselineInput) => Promise<boolean>;
    deleteBaseline?: (baselineId: string) => Promise<boolean>;
}
export interface ScheduleWorkspaceProps {
    data: ScheduleData;
    adapter: ScheduleAdapter;
    /** Plan window the timeline centres on; falls back to the task dates. */
    dateWorkStart?: string | null;
    dateWorkEnd?: string | null;
    className?: string;
    onOpenImport?: () => void;
    onExportPdf?: () => void;
}
export declare function ScheduleWorkspace({ data, adapter, dateWorkStart, dateWorkEnd, className, onOpenImport, onExportPdf, }: ScheduleWorkspaceProps): import("react").JSX.Element;
//# sourceMappingURL=schedule-workspace.d.ts.map