'use client';
import { jsx as _jsx, jsxs as _jsxs, Fragment as _Fragment } from "react/jsx-runtime";
/**
 * Status board: four columns, cards grouped by phase, drag to change status.
 *
 * Dropping a card writes progress alongside the status, because a task marked
 * complete at 40% is a reporting lie that nobody notices until the rollup is
 * wrong. Rolled-up parents are not draggable — their status is derived.
 */
import { useMemo, useState } from 'react';
import { Badge, Button, Progress, cn } from '@appkit/ui';
import { parseDate } from '../dates.js';
import { getTaskVariance, normalizeScheduleProgress } from '../insights.js';
import { resolvePhaseColor } from '../palette.js';
import { useScheduleFormatters, useSchedulingLabels } from './context.js';
const COLUMNS = ['not_started', 'in_progress', 'on_hold', 'complete'];
const MAX_INLINE_RESOURCES = 3;
/** Progress a status change implies when the user hasn't stated one. */
function progressForStatus(nextStatus, currentProgress) {
    if (nextStatus === 'complete')
        return 1;
    if (nextStatus === 'not_started')
        return 0;
    // Re-opening a finished task: 100% would contradict "in progress".
    if (nextStatus === 'in_progress')
        return currentProgress >= 1 ? 0.85 : Math.max(currentProgress, 0.1);
    return currentProgress;
}
export function BoardView({ tasks, insights, phases, resources, taskAssignmentsByTaskId, onUpdateTask, onClickTask, onContextMenu, }) {
    const labels = useSchedulingLabels();
    const formatters = useScheduleFormatters();
    const phaseMap = useMemo(() => new Map(phases.map((phase) => [phase.id, phase])), [phases]);
    const phaseIndexById = useMemo(() => new Map(phases.map((phase, index) => [phase.id, index])), [phases]);
    const resourceById = useMemo(() => new Map(resources.map((r) => [r.id, r])), [resources]);
    const childCountByTaskId = useMemo(() => {
        const counts = new Map();
        for (const task of tasks) {
            if (!task.parentTaskId)
                continue;
            counts.set(task.parentTaskId, (counts.get(task.parentTaskId) ?? 0) + 1);
        }
        return counts;
    }, [tasks]);
    const [draggingId, setDraggingId] = useState(null);
    const tasksByStatus = useMemo(() => {
        const result = {
            not_started: [],
            in_progress: [],
            on_hold: [],
            complete: [],
        };
        for (const task of tasks)
            result[task.status]?.push(task);
        for (const status of COLUMNS) {
            result[status].sort((a, b) => {
                const aPhase = a.phaseId
                    ? (phaseIndexById.get(a.phaseId) ?? Number.MAX_SAFE_INTEGER)
                    : Number.MAX_SAFE_INTEGER;
                const bPhase = b.phaseId
                    ? (phaseIndexById.get(b.phaseId) ?? Number.MAX_SAFE_INTEGER)
                    : Number.MAX_SAFE_INTEGER;
                if (aPhase !== bPhase)
                    return aPhase - bPhase;
                return (a.startDate ?? '').localeCompare(b.startDate ?? '');
            });
        }
        return result;
    }, [phaseIndexById, tasks]);
    const groupedTasksByStatus = useMemo(() => {
        const result = new Map();
        for (const status of COLUMNS) {
            const groups = new Map();
            for (const task of tasksByStatus[status]) {
                const phase = task.phaseId ? (phaseMap.get(task.phaseId) ?? null) : null;
                const key = phase?.id ?? 'unassigned';
                if (!groups.has(key))
                    groups.set(key, { key, phase, tasks: [] });
                groups.get(key).tasks.push(task);
            }
            result.set(status, Array.from(groups.values()).sort((a, b) => {
                const aIndex = a.phase
                    ? (phaseIndexById.get(a.phase.id) ?? Number.MAX_SAFE_INTEGER)
                    : Number.MAX_SAFE_INTEGER;
                const bIndex = b.phase
                    ? (phaseIndexById.get(b.phase.id) ?? Number.MAX_SAFE_INTEGER)
                    : Number.MAX_SAFE_INTEGER;
                return aIndex - bIndex;
            }));
        }
        return result;
    }, [phaseIndexById, phaseMap, tasksByStatus]);
    const handleDrop = (event, nextStatus) => {
        event.preventDefault();
        const taskId = event.dataTransfer.getData('text/plain');
        if (!taskId) {
            setDraggingId(null);
            return;
        }
        const task = tasks.find((item) => item.id === taskId);
        if (task && task.status !== nextStatus) {
            void onUpdateTask(taskId, {
                status: nextStatus,
                progress: progressForStatus(nextStatus, normalizeScheduleProgress(task.progress)),
            });
        }
        setDraggingId(null);
    };
    const handleQuickStatus = (event, task, nextStatus) => {
        event.stopPropagation();
        void onUpdateTask(task.id, {
            status: nextStatus,
            progress: progressForStatus(nextStatus, normalizeScheduleProgress(task.progress)),
        });
    };
    const columnAccent = {
        not_started: 'border-t-border-strong',
        in_progress: 'border-t-info',
        on_hold: 'border-t-warning',
        complete: 'border-t-success',
    };
    return (_jsx("div", { className: "flex min-h-0 flex-1 overflow-hidden rounded-t-none rounded-b-lg border border-t-0 border-border bg-surface p-3", "data-testid": "schedule-board", children: _jsx("div", { className: "sched-scroll grid min-h-0 flex-1 grid-cols-[repeat(4,minmax(240px,1fr))] gap-3 overflow-x-auto", children: COLUMNS.map((status) => (_jsxs("div", { "data-testid": `schedule-board-column-${status}`, className: cn('flex min-h-0 flex-col rounded-lg border border-t-4 border-border bg-bg-subtle/60', columnAccent[status]), onDragOver: (event) => {
                    event.preventDefault();
                    event.dataTransfer.dropEffect = 'move';
                }, onDrop: (event) => handleDrop(event, status), children: [_jsxs("div", { className: "shrink-0 border-b border-border/50 px-3 py-2.5", children: [_jsxs("div", { className: "flex items-center justify-between", children: [_jsx("span", { className: "text-xs font-semibold text-fg", children: labels.status[status] }), _jsx("span", { className: "rounded-full bg-surface px-1.5 py-0.5 text-[11px] text-fg-subtle", children: tasksByStatus[status].length })] }), _jsxs("div", { className: "mt-2 flex flex-wrap gap-1 text-[10px] text-fg-subtle", children: [_jsxs(Badge, { variant: "secondary", className: "px-2 py-0 text-[10px] font-medium", children: [tasksByStatus[status].filter((t) => insights.criticalTaskIds.has(t.id)).length, ' ', labels.list.critical] }), _jsxs(Badge, { variant: "secondary", className: "px-2 py-0 text-[10px] font-medium", children: [tasksByStatus[status].filter((t) => insights.overdueTaskIds.has(t.id)).length, ' ', labels.list.overdue] }), _jsxs(Badge, { variant: "secondary", className: "px-2 py-0 text-[10px] font-medium", children: [tasksByStatus[status].filter((t) => insights.attentionTaskIds.has(t.id)).length, ' ', labels.list.issues] })] })] }), _jsxs("div", { className: "sched-scroll min-h-0 flex-1 space-y-2 overflow-y-auto p-2", children: [(groupedTasksByStatus.get(status) ?? []).map((group) => (_jsxs("div", { className: "space-y-2", children: [_jsxs("div", { className: "flex items-center justify-between px-1", children: [_jsx("div", { className: "flex items-center gap-1.5", children: group.phase ? (_jsxs(_Fragment, { children: [_jsx("div", { className: "h-2 w-2 rounded-full", style: {
                                                                backgroundColor: resolvePhaseColor(group.phase.color, phaseIndexById.get(group.phase.id) ?? 0),
                                                            } }), _jsx("span", { className: "text-[10px] font-medium text-fg-muted", children: group.phase.name })] })) : (_jsx("span", { className: "text-[10px] font-medium text-fg-subtle", children: labels.common.noPhase })) }), _jsx("span", { className: "text-[10px] text-fg-subtle", children: group.tasks.length })] }), group.tasks.map((task) => {
                                        const phase = task.phaseId ? phaseMap.get(task.phaseId) : null;
                                        const phaseIndex = phase ? (phaseIndexById.get(phase.id) ?? -1) : -1;
                                        const color = phaseIndex >= 0 ? resolvePhaseColor(phase?.color, phaseIndex) : null;
                                        const childCount = childCountByTaskId.get(task.id) ?? 0;
                                        const isSummaryTask = task.taskType === 'summary' || childCount > 0;
                                        const isRollupSummary = childCount > 0;
                                        const startDate = parseDate(task.startDate);
                                        const endDate = parseDate(task.endDate);
                                        const deadlineDate = parseDate(task.deadlineDate);
                                        const variance = getTaskVariance(task);
                                        const floatDays = insights.totalFloatByTask.get(task.id);
                                        const assignments = taskAssignmentsByTaskId.get(task.id) ?? [];
                                        const progress = normalizeScheduleProgress(task.progress);
                                        return (_jsxs("div", { "data-testid": `schedule-board-card-${task.id}`, draggable: !isRollupSummary, onDragStart: (event) => {
                                                if (isRollupSummary)
                                                    return;
                                                event.dataTransfer.setData('text/plain', task.id);
                                                setDraggingId(task.id);
                                            }, onDragEnd: () => setDraggingId(null), onClick: () => onClickTask(task), onContextMenu: onContextMenu ? (event) => onContextMenu(event, task) : undefined, className: cn('cursor-pointer rounded-lg border border-border bg-surface p-3 transition-all hover:border-primary/30 hover:shadow-sm', draggingId === task.id && 'opacity-50'), children: [_jsxs("div", { className: "flex items-start justify-between gap-2", children: [phase && color ? (_jsxs("div", { className: "mb-2 flex items-center gap-1.5", children: [_jsx("div", { className: "h-2 w-2 rounded-full", style: { backgroundColor: color } }), _jsx("span", { className: "truncate text-[10px] text-fg-muted", children: phase.name })] })) : (_jsx("span", {})), _jsxs("div", { className: "flex flex-wrap justify-end gap-1", children: [isSummaryTask && _jsx(Badge, { variant: "secondary", children: labels.badges.summary }), childCount > 0 && (_jsx(Badge, { variant: "secondary", children: labels.format.childCount(childCount) })), insights.criticalTaskIds.has(task.id) && (_jsx(Badge, { variant: "info", children: labels.badges.critical })), assignments.length > 0 && (_jsxs(Badge, { variant: "secondary", children: [assignments.length, " ", labels.columns.resources] }))] })] }), _jsx("p", { className: "mb-2 line-clamp-2 text-xs font-medium text-fg", children: task.name || labels.badges.untitled }), (startDate || endDate) && (_jsxs("p", { className: "mb-2 text-[10px] text-fg-subtle", children: [startDate ? formatters.shortDate(startDate) : '—', " \u2013", ' ', endDate ? formatters.shortDate(endDate) : '—'] })), _jsxs("div", { className: "mb-2 flex flex-wrap gap-1 text-[10px] text-fg-subtle", children: [deadlineDate ? (_jsxs(Badge, { variant: "secondary", className: "px-2 py-0 text-[10px] font-medium", children: [labels.columns.deadline, " ", formatters.shortDate(deadlineDate)] })) : null, typeof floatDays === 'number' && Number.isFinite(floatDays) ? (_jsx(Badge, { variant: "secondary", className: "px-2 py-0 text-[10px] font-medium", children: labels.format.floatDays(Math.round(floatDays)) })) : null, variance.isBehind ? (_jsx(Badge, { variant: "warning", className: "px-2 py-0 text-[10px] font-medium", children: labels.format.slipDays(Math.max(variance.finishDays ?? 0, variance.startDays ?? 0)) })) : null] }), assignments.length > 0 ? (_jsxs("div", { className: "mb-2 flex flex-wrap gap-1", children: [assignments.slice(0, MAX_INLINE_RESOURCES).map((assignment) => (_jsx(Badge, { variant: "secondary", className: "px-2 py-0 text-[10px] font-medium", children: resourceById.get(assignment.resourceId)?.name ??
                                                                assignment.role ??
                                                                labels.list.resource }, assignment.id))), assignments.length > MAX_INLINE_RESOURCES ? (_jsxs(Badge, { variant: "secondary", className: "px-2 py-0 text-[10px] font-medium", children: ["+", assignments.length - MAX_INLINE_RESOURCES] })) : null] })) : null, progress > 0 && (_jsx(Progress, { value: progress * 100, "aria-label": labels.columns.progress, className: "mb-2 h-1" })), _jsxs("div", { className: "flex flex-wrap gap-1", children: [insights.overdueTaskIds.has(task.id) && (_jsx(Badge, { variant: "destructive", children: labels.badges.overdue })), insights.violatingTaskIds.has(task.id) && (_jsx(Badge, { variant: "warning", children: labels.badges.logic })), insights.openEndedTaskIds.has(task.id) && (_jsx(Badge, { variant: "warning", children: labels.list.openEnd })), insights.deadlineMissTaskIds.has(task.id) && (_jsx(Badge, { variant: "destructive", children: labels.badges.deadline })), insights.constraintViolationTaskIds.has(task.id) && (_jsx(Badge, { variant: "warning", children: labels.badges.constraint })), insights.resourceConflictTaskIds.has(task.id) && (_jsx(Badge, { variant: "warning", children: labels.badges.resource })), insights.actualDateGapTaskIds.has(task.id) && (_jsx(Badge, { variant: "warning", children: labels.list.actuals }))] }), task.assignee && (_jsxs("div", { className: "mt-3 flex items-center gap-1.5", children: [_jsx("div", { className: "flex h-4 w-4 items-center justify-center rounded-full bg-bg-subtle", children: _jsx("span", { className: "text-[9px] font-medium text-fg-muted", children: task.assignee.charAt(0).toUpperCase() }) }), _jsx("span", { className: "truncate text-[10px] text-fg-muted", children: task.assignee })] })), !isRollupSummary ? (_jsxs("div", { className: "mt-3 flex items-center gap-1 border-t border-border/50 pt-2", children: [task.status !== 'in_progress' ? (_jsx(Button, { variant: "ghost", size: "sm", className: "h-6 px-2 text-[10px]", onClick: (event) => handleQuickStatus(event, task, 'in_progress'), children: task.status === 'complete' ? labels.list.reopen : labels.list.start })) : null, task.status !== 'complete' ? (_jsx(Button, { variant: "ghost", size: "sm", className: "h-6 px-2 text-[10px]", onClick: (event) => handleQuickStatus(event, task, 'complete'), children: labels.list.done })) : null, task.status !== 'on_hold' ? (_jsx(Button, { variant: "ghost", size: "sm", className: "ml-auto h-6 px-2 text-[10px]", onClick: (event) => handleQuickStatus(event, task, 'on_hold'), children: labels.list.hold })) : null] })) : null] }, task.id));
                                    })] }, `${status}-${group.key}`))), tasksByStatus[status].length === 0 && (_jsx("div", { className: "py-8 text-center text-xs text-fg-subtle", children: labels.board.dropHint }))] })] }, status))) }) }));
}
//# sourceMappingURL=board-view.js.map