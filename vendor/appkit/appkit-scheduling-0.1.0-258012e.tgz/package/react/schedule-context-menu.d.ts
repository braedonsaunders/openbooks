import type { ScheduleTask, ScheduleTaskPatchInput } from '../types.js';
export interface ContextMenuState {
    x: number;
    y: number;
    task: ScheduleTask;
}
export interface ScheduleContextMenuProps {
    menu: ContextMenuState | null;
    onClose: () => void;
    onEdit: (task: ScheduleTask) => void;
    onDelete: (taskId: string) => void;
    onUpdate: (taskId: string, patch: ScheduleTaskPatchInput) => void;
    onDuplicate?: (task: ScheduleTask) => void;
    onCreateSibling?: (task: ScheduleTask) => void;
    onCreateChild?: (task: ScheduleTask) => void;
    onIndent?: (taskId: string) => void;
    onOutdent?: (taskId: string) => void;
    onMove?: (taskId: string, direction: 'up' | 'down') => void;
}
export declare function ScheduleContextMenu({ menu, onClose, onEdit, onDelete, onUpdate, onDuplicate, onCreateSibling, onCreateChild, onIndent, onOutdent, onMove, }: ScheduleContextMenuProps): import("react").JSX.Element | null;
/** Track right-click position and target task for the menu above. */
export declare function useScheduleContextMenu(): {
    menu: ContextMenuState | null;
    handleContextMenu: (event: React.MouseEvent, task: ScheduleTask) => void;
    closeMenu: () => void;
};
//# sourceMappingURL=schedule-context-menu.d.ts.map