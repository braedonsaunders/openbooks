import type { SchedulePhase, ScheduleInsights, ScheduleResource, ScheduleTask, ScheduleTaskAssignment, ScheduleTaskPatchInput } from '../types.js';
export interface BoardViewProps {
    tasks: ScheduleTask[];
    insights: ScheduleInsights;
    phases: SchedulePhase[];
    resources: ScheduleResource[];
    taskAssignmentsByTaskId: Map<string, ScheduleTaskAssignment[]>;
    onUpdateTask: (taskId: string, patch: ScheduleTaskPatchInput) => void | boolean | Promise<boolean | void>;
    onClickTask: (task: ScheduleTask) => void;
    onContextMenu?: (e: React.MouseEvent, task: ScheduleTask) => void;
}
export declare function BoardView({ tasks, insights, phases, resources, taskAssignmentsByTaskId, onUpdateTask, onClickTask, onContextMenu, }: BoardViewProps): import("react").JSX.Element;
//# sourceMappingURL=board-view.d.ts.map