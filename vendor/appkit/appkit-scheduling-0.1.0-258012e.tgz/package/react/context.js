'use client';
import { jsx as _jsx } from "react/jsx-runtime";
/**
 * The one place the scheduling surface gets its strings and date formatting.
 *
 * Without a provider every component falls back to English defaults and the
 * runtime locale, so a host can drop a Gantt in and see it work. With one, the
 * host's own i18n layer supplies labels and formatters and nothing inside the
 * package needs to know which library it uses.
 */
import { createContext, useContext, useMemo } from 'react';
import { createDateFormatters, defaultDateFormatters, } from '../dates.js';
import { defaultSchedulingLabels, mergeSchedulingLabels, } from '../labels.js';
const SchedulingContext = createContext({
    labels: defaultSchedulingLabels,
    formatters: defaultDateFormatters,
});
export function SchedulingProvider({ children, labels, formatters, locale, }) {
    const value = useMemo(() => ({
        labels: mergeSchedulingLabels(labels),
        formatters: formatters ?? (locale ? createDateFormatters(locale) : defaultDateFormatters),
        locale,
    }), [labels, formatters, locale]);
    return _jsx(SchedulingContext.Provider, { value: value, children: children });
}
export function useScheduling() {
    return useContext(SchedulingContext);
}
export function useSchedulingLabels() {
    return useScheduling().labels;
}
export function useScheduleFormatters() {
    return useScheduling().formatters;
}
//# sourceMappingURL=context.js.map