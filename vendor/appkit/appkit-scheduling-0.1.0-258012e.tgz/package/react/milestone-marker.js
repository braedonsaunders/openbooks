'use client';
import { jsx as _jsx } from "react/jsx-runtime";
import { cn } from '@appkit/ui';
import { phaseColor } from '../palette.js';
/** The rotated diamond every schedule uses for a zero-duration event. */
export function MilestoneMarker({ color, size = 12, className, }) {
    return (_jsx("div", { className: cn('rotate-45 rounded-sm', className), style: { width: size, height: size, backgroundColor: color ?? phaseColor(2) } }));
}
//# sourceMappingURL=milestone-marker.js.map