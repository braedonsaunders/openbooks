/**
 * Resource leveling.
 *
 * Critical-path analysis answers "how fast could this go if people were
 * infinite". Leveling answers the real question: given that a crew can only be
 * in one place at a time, when does the work actually happen?
 *
 * The algorithm is serial list scheduling — the standard resource-constrained
 * project-scheduling heuristic, and the one every planning tool ships:
 *
 *   1. Order tasks topologically so no task is placed before its predecessors.
 *   2. Among the tasks whose predecessors are already placed, take the one
 *      with the LEAST total float (ties broken by outline order) — delaying a
 *      critical task costs the whole project, delaying a floaty one costs
 *      nothing.
 *   3. Push it to the first day where its dependencies are satisfied AND every
 *      resource it books has spare capacity for the whole span.
 *   4. Book that capacity and continue.
 *
 * `withinFloatOnly` is the difference between "keep the finish date and tell
 * me what's still overbooked" and "fix every conflict, whatever it costs".
 * Neither answer is guessed at: whatever cannot be resolved is returned in
 * `unresolved` rather than silently left overallocated.
 *
 * Nothing here mutates the input. Leveling produces a set of proposed MOVES;
 * the host decides whether to apply them, which is what makes it safe to show
 * a preview before touching a plan someone is working to.
 */
import type { ScheduleCalendar, ScheduleDependency, ScheduleResource, ScheduleTask, ScheduleTaskAssignment } from './types.js';
export interface ResourceLevelingOptions {
    calendars?: ScheduleCalendar[];
    resources?: ScheduleResource[];
    assignments?: ScheduleTaskAssignment[];
    /**
     * Never delay a task beyond its total float — i.e. never push the project
     * finish out. Conflicts that can't be solved inside float are reported as
     * unresolved instead of being buried. Default true.
     */
    withinFloatOnly?: boolean;
    /** Leave completed/in-flight work where it is. Default true. */
    freezeStartedTasks?: boolean;
    /** Upper bound on the forward search per task. Default 365 days. */
    maxDelayDays?: number;
    /** Earliest date leveling may schedule into. Defaults to the plan's start. */
    anchorDate?: Date;
}
export interface ScheduleLevelingMove {
    taskId: string;
    taskName: string;
    fromStart: string | null;
    fromEnd: string | null;
    toStart: string;
    toEnd: string;
    delayDays: number;
    /** Which resources were the binding constraint on the chosen day. */
    blockedByResourceIds: string[];
    /** Total float the task had before leveling; how much slack it consumed. */
    floatDays: number;
}
export interface ScheduleLevelingConflict {
    taskId: string;
    taskName: string;
    resourceIds: string[];
    /** Days of delay leveling would have needed but was not allowed to take. */
    requiredDelayDays: number;
    reason: 'exceeds_float' | 'exceeds_search_window' | 'capacity_below_demand';
}
export interface ScheduleLevelingResult {
    moves: ScheduleLevelingMove[];
    unresolved: ScheduleLevelingConflict[];
    /** Days the plan's last finish moved out. 0 when levelled inside float. */
    projectDelayDays: number;
    /** True when the logic contains a cycle — nothing was levelled. */
    hasCycle: boolean;
}
export interface ResourceLoadDay {
    date: string;
    load: number;
    capacity: number;
    /** Load beyond capacity; 0 when within capacity. */
    overload: number;
}
export interface ResourceLoadSeries {
    resourceId: string;
    resourceName: string;
    capacityPerDay: number;
    days: ResourceLoadDay[];
    peakLoad: number;
    overloadedDays: number;
}
/**
 * Level a schedule against finite resource capacity.
 *
 * Only leaf tasks participate — summary rows are derived, and moving a parent
 * independently of its children would desynchronize the outline.
 */
export declare function levelResources(tasks: ScheduleTask[], dependencies: ScheduleDependency[], options?: ResourceLevelingOptions): ScheduleLevelingResult;
/** Apply leveling moves to a task list. Pure — returns a new array. */
export declare function applyLevelingMoves(tasks: ScheduleTask[], moves: ScheduleLevelingMove[]): ScheduleTask[];
/** Moves expressed as task patches, ready to persist. */
export declare function levelingMovesToPatches(moves: ScheduleLevelingMove[]): {
    id: string;
    patch: {
        startDate: string;
        endDate: string;
    };
}[];
/**
 * Day-by-day load vs capacity per resource — the histogram under a Gantt that
 * shows WHERE the overbooking is, not just that it exists.
 */
export declare function buildResourceLoadSeries(tasks: ScheduleTask[], options?: ResourceLevelingOptions): ResourceLoadSeries[];
//# sourceMappingURL=leveling.d.ts.map