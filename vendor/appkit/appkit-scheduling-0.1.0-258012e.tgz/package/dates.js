/**
 * Calendar-day arithmetic for schedules.
 *
 * Every date this module produces is normalized to local noon. A schedule bar
 * is a calendar-day range, and noon is the one instant per day that survives
 * both DST transitions and `toLocaleDateString` without sliding into the
 * neighbouring day — the difference between a plan that reads "Mar 10" and one
 * that silently renders "Mar 9" for half the world.
 */
export const MS_PER_DAY = 86_400_000;
function createCalendarDate(year, monthIndex, day) {
    return new Date(year, monthIndex, day, 12, 0, 0, 0);
}
export function normalizeCalendarDate(date) {
    return createCalendarDate(date.getFullYear(), date.getMonth(), date.getDate());
}
export function startOfNextMonth(date) {
    return createCalendarDate(date.getFullYear(), date.getMonth() + 1, 1);
}
function padDatePart(value) {
    return String(value).padStart(2, '0');
}
export function monthKey(date) {
    return `${date.getFullYear()}-${date.getMonth()}`;
}
export function yearKey(date) {
    return `${date.getFullYear()}`;
}
/** Mon–Fri. The default every planning tool starts from. */
const DEFAULT_WORKING_DAYS = {
    '0': false,
    '1': true,
    '2': true,
    '3': true,
    '4': true,
    '5': true,
    '6': false,
};
function getCalendarWorkingDays(calendar) {
    return calendar?.workingDays && Object.keys(calendar.workingDays).length > 0
        ? calendar.workingDays
        : DEFAULT_WORKING_DAYS;
}
export function isNonWorkingDay(date, calendar) {
    const normalized = normalizeCalendarDate(date);
    if (calendar?.holidays?.includes(formatISODate(normalized)))
        return true;
    const day = String(normalized.getDay());
    return getCalendarWorkingDays(calendar)[day] === false;
}
export function isWorkingDay(date, calendar) {
    return !isNonWorkingDay(date, calendar);
}
export function todayDate() {
    return normalizeCalendarDate(new Date());
}
export function addDays(date, days) {
    const next = normalizeCalendarDate(date);
    next.setDate(next.getDate() + days);
    next.setHours(12, 0, 0, 0);
    return next;
}
/** Whole calendar days between two dates (a − b), DST-safe. */
export function diffDays(a, b) {
    const aMidnight = Date.UTC(a.getFullYear(), a.getMonth(), a.getDate());
    const bMidnight = Date.UTC(b.getFullYear(), b.getMonth(), b.getDate());
    return Math.round((aMidnight - bMidnight) / MS_PER_DAY);
}
/**
 * Advance by `days` WORKING days on `calendar`. Non-working days are skipped
 * rather than counted, which is what "3 days of work" means to a scheduler.
 */
export function addWorkingDays(date, days, calendar) {
    if (days === 0)
        return normalizeCalendarDate(date);
    const step = days > 0 ? 1 : -1;
    let remaining = Math.abs(days);
    let cursor = normalizeCalendarDate(date);
    // Bounded so a calendar with every day non-working can never spin forever.
    let guard = Math.abs(days) * 7 + 366;
    while (remaining > 0 && guard > 0) {
        cursor = addDays(cursor, step);
        if (isWorkingDay(cursor, calendar))
            remaining -= 1;
        guard -= 1;
    }
    return cursor;
}
/** The next working day at or after `date`. */
export function nextWorkingDay(date, calendar) {
    let cursor = normalizeCalendarDate(date);
    let guard = 366;
    while (!isWorkingDay(cursor, calendar) && guard > 0) {
        cursor = addDays(cursor, 1);
        guard -= 1;
    }
    return cursor;
}
/** Working days in `[start, end)`, or 1 for a same-day/zero-length span. */
export function countWorkingDays(start, end, calendar) {
    if (end.getTime() <= start.getTime())
        return isWorkingDay(start, calendar) ? 1 : 0;
    let count = 0;
    for (let cursor = normalizeCalendarDate(start); cursor.getTime() < end.getTime(); cursor = addDays(cursor, 1)) {
        if (isWorkingDay(cursor, calendar))
            count += 1;
    }
    return count;
}
export function formatISODate(date) {
    const normalized = normalizeCalendarDate(date);
    return `${normalized.getFullYear()}-${padDatePart(normalized.getMonth() + 1)}-${padDatePart(normalized.getDate())}`;
}
export function startOfWeek(date) {
    const normalized = normalizeCalendarDate(date);
    return addDays(normalized, -normalized.getDay());
}
export function startOfMonth(date) {
    return createCalendarDate(date.getFullYear(), date.getMonth(), 1);
}
/** Parse `YYYY-MM-DD` (or anything `Date` accepts) into a noon-normalized date. */
export function parseDate(value) {
    if (!value)
        return null;
    const trimmed = value.trim();
    const match = /^(\d{4})-(\d{2})-(\d{2})$/.exec(trimmed);
    if (match) {
        return createCalendarDate(Number.parseInt(match[1], 10), Number.parseInt(match[2], 10) - 1, Number.parseInt(match[3], 10));
    }
    const parsed = new Date(trimmed);
    if (Number.isNaN(parsed.getTime()))
        return null;
    return normalizeCalendarDate(parsed);
}
export function snapToDay(ms) {
    return normalizeCalendarDate(new Date(ms));
}
export function createDateFormatters(locale) {
    const shortDate = new Intl.DateTimeFormat(locale, { month: 'short', day: 'numeric' });
    const monthYear = new Intl.DateTimeFormat(locale, { month: 'short', year: 'numeric' });
    const monthShort = new Intl.DateTimeFormat(locale, { month: 'short' });
    const weekdayShort = new Intl.DateTimeFormat(locale, { weekday: 'short' });
    return {
        shortDate: (date) => shortDate.format(normalizeCalendarDate(date)),
        monthYear: (date) => monthYear.format(normalizeCalendarDate(date)),
        monthShort: (date) => monthShort.format(normalizeCalendarDate(date)),
        weekdayShort: (date) => weekdayShort.format(normalizeCalendarDate(date)),
    };
}
/** Formatters bound to the runtime's default locale. */
export const defaultDateFormatters = createDateFormatters();
export function formatShortDate(date) {
    return defaultDateFormatters.shortDate(date);
}
export function formatMonthYear(date) {
    return defaultDateFormatters.monthYear(date);
}
export function formatMonthShort(date) {
    return defaultDateFormatters.monthShort(date);
}
export function formatWeekdayShort(date) {
    return defaultDateFormatters.weekdayShort(date);
}
//# sourceMappingURL=dates.js.map