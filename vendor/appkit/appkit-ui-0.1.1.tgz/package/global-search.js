'use client';
import { jsx as _jsx, Fragment as _Fragment, jsxs as _jsxs } from "react/jsx-runtime";
import * as React from 'react';
import { CornerDownLeft, Loader2, Search, X } from 'lucide-react';
import { Badge } from './badge.js';
import { NavIcon } from './sidebar-nav.js';
import { cn } from './utils.js';
const DEFAULT_LABELS = {
    placeholder: 'Search…',
    ariaLabel: 'Search the application',
    clear: 'Clear search',
    searching: 'Searching…',
    noMatches: (query) => `No matches for “${query}”`,
    navigate: 'navigate',
    open: 'open',
    close: 'close',
    resultCount: (count) => `${count} result${count === 1 ? '' : 's'}`,
};
function Highlight({ text, query }) {
    const index = text.toLowerCase().indexOf(query.toLowerCase());
    if (!query || index < 0)
        return text;
    return _jsxs(_Fragment, { children: [text.slice(0, index), _jsx("mark", { className: "bg-transparent font-semibold text-primary", children: text.slice(index, index + query.length) }), text.slice(index + query.length)] });
}
/** Production sibling search interaction with app-owned querying and navigation. */
export function GlobalSearch({ search, onNavigate, className, labels = DEFAULT_LABELS, minimumQueryLength = 2, debounceMs = 180, }) {
    const inputRef = React.useRef(null);
    const rootRef = React.useRef(null);
    const resultsId = React.useId();
    const [query, setQuery] = React.useState('');
    const [open, setOpen] = React.useState(false);
    const [loading, setLoading] = React.useState(false);
    const [result, setResult] = React.useState(null);
    const [active, setActive] = React.useState(0);
    const hits = React.useMemo(() => result?.groups.flatMap((group) => group.hits) ?? [], [result]);
    React.useEffect(() => {
        function onKey(event) {
            if ((event.metaKey || event.ctrlKey) && event.key.toLowerCase() === 'k') {
                event.preventDefault();
                inputRef.current?.focus();
                inputRef.current?.select();
                setOpen(true);
            }
        }
        window.addEventListener('keydown', onKey);
        return () => window.removeEventListener('keydown', onKey);
    }, []);
    React.useEffect(() => {
        function onPointerDown(event) {
            if (!rootRef.current?.contains(event.target))
                setOpen(false);
        }
        document.addEventListener('pointerdown', onPointerDown);
        return () => document.removeEventListener('pointerdown', onPointerDown);
    }, []);
    React.useEffect(() => {
        const term = query.trim();
        if (term.length < minimumQueryLength) {
            setResult(null);
            setLoading(false);
            return;
        }
        const controller = new AbortController();
        setLoading(true);
        const timeout = window.setTimeout(async () => {
            try {
                const next = await search(term, controller.signal);
                setResult(next);
                setActive(0);
            }
            catch (error) {
                if (error.name !== 'AbortError')
                    setResult({ groups: [], total: 0 });
            }
            finally {
                if (!controller.signal.aborted)
                    setLoading(false);
            }
        }, debounceMs);
        return () => { window.clearTimeout(timeout); controller.abort(); };
    }, [debounceMs, minimumQueryLength, query, search]);
    const go = React.useCallback((hit) => {
        if (!hit)
            return;
        setOpen(false);
        setQuery('');
        setResult(null);
        inputRef.current?.blur();
        onNavigate(hit);
    }, [onNavigate]);
    function onKeyDown(event) {
        if (event.key === 'Escape') {
            setOpen(false);
            inputRef.current?.blur();
            return;
        }
        if (!hits.length)
            return;
        if (event.key === 'ArrowDown') {
            event.preventDefault();
            setActive((value) => (value + 1) % hits.length);
        }
        else if (event.key === 'ArrowUp') {
            event.preventDefault();
            setActive((value) => (value - 1 + hits.length) % hits.length);
        }
        else if (event.key === 'Enter') {
            event.preventDefault();
            go(hits[active]);
        }
    }
    const showPanel = open && query.trim().length >= minimumQueryLength;
    let itemIndex = -1;
    return (_jsxs("div", { ref: rootRef, className: cn('relative', className), children: [_jsxs("div", { className: "relative", children: [_jsx(Search, { size: 15, className: "pointer-events-none absolute top-1/2 left-3 -translate-y-1/2 text-fg-subtle" }), _jsx("input", { ref: inputRef, value: query, onChange: (event) => { setQuery(event.target.value); setOpen(true); }, onFocus: () => setOpen(true), onKeyDown: onKeyDown, placeholder: labels.placeholder, "aria-label": labels.ariaLabel, role: "combobox", "aria-expanded": showPanel, "aria-controls": resultsId, className: "h-9 w-full rounded-lg border border-border bg-bg-subtle pr-16 pl-9 text-sm text-fg transition-colors placeholder:text-fg-subtle hover:border-border-strong focus:border-primary focus:bg-surface focus:ring-2 focus:ring-ring/20 focus:outline-none" }), _jsx("div", { className: "absolute top-1/2 right-2.5 flex -translate-y-1/2 items-center gap-1", children: loading ? _jsx(Loader2, { size: 14, className: "animate-spin text-fg-subtle" }) : query ? _jsx("button", { type: "button", onClick: () => { setQuery(''); setResult(null); inputRef.current?.focus(); }, className: "rounded p-0.5 text-fg-subtle hover:text-fg", "aria-label": labels.clear, children: _jsx(X, { size: 14 }) }) : _jsx("kbd", { className: "hidden rounded border border-border bg-surface px-1.5 py-0.5 font-sans text-[10px] font-medium text-fg-subtle sm:inline", children: "\u2318K" }) })] }), showPanel ? (_jsx("div", { id: resultsId, className: "absolute top-[calc(100%+6px)] left-0 z-50 max-h-[70vh] w-full min-w-88 overflow-y-auto rounded-xl border border-border bg-elevated p-1.5 shadow-lg", role: "listbox", children: result && result.total > 0 ? _jsxs(_Fragment, { children: [result.groups.map((group) => _jsxs("div", { className: "mb-1 last:mb-0", children: [_jsx("div", { className: "px-2 pt-1.5 pb-1 text-[11px] font-semibold tracking-wider text-fg-subtle uppercase", children: group.label }), group.hits.map((hit) => { itemIndex += 1; const index = itemIndex; const selected = index === active; return _jsxs("button", { type: "button", role: "option", "aria-selected": selected, onMouseEnter: () => setActive(index), onMouseDown: (event) => { event.preventDefault(); go(hit); }, className: cn('flex w-full items-center gap-3 rounded-lg px-2 py-1.5 text-left transition-colors', selected ? 'bg-primary-subtle' : 'hover:bg-surface-hover'), children: [_jsx("span", { className: cn('grid size-7 shrink-0 place-items-center rounded-md', selected ? 'bg-surface text-primary' : 'bg-bg-subtle text-fg-muted'), children: hit.iconKey ? _jsx(NavIcon, { iconKey: hit.iconKey, size: 15 }) : _jsx(Search, { size: 15 }) }), _jsxs("span", { className: "min-w-0 flex-1", children: [_jsxs("span", { className: "flex items-center gap-2", children: [_jsx("span", { className: "truncate text-sm text-fg", children: _jsx(Highlight, { text: hit.title, query: query.trim() }) }), hit.badge ? _jsx(Badge, { variant: "secondary", className: "text-[10px]", children: hit.badge }) : null] }), hit.subtitle ? _jsx("span", { className: "block truncate text-xs text-fg-muted", children: hit.subtitle }) : null] }), hit.meta ? _jsx("span", { className: "shrink-0 font-mono text-xs tabular-nums text-fg-muted", children: hit.meta }) : null, selected ? _jsx(CornerDownLeft, { size: 13, className: "shrink-0 text-primary" }) : null] }, `${hit.type}-${hit.id}`); })] }, group.id)), _jsxs("div", { className: "mt-1 flex items-center justify-between border-t border-border-subtle px-2 py-1.5 text-[11px] text-fg-subtle", children: [_jsxs("span", { children: [_jsx("kbd", { className: "font-sans", children: "\u2191\u2193" }), " ", labels.navigate, "\u00A0\u00A0", _jsx("kbd", { className: "font-sans", children: "\u21B5" }), " ", labels.open, "\u00A0\u00A0", _jsx("kbd", { className: "font-sans", children: "esc" }), " ", labels.close] }), _jsx("span", { children: labels.resultCount(result.total) })] })] }) : loading ? _jsxs("div", { className: "flex items-center gap-2 px-3 py-6 text-sm text-fg-subtle", children: [_jsx(Loader2, { size: 15, className: "animate-spin" }), labels.searching] }) : _jsx("div", { className: "px-3 py-6 text-center text-sm text-fg-subtle", children: labels.noMatches(query.trim()) }) })) : null] }));
}
//# sourceMappingURL=global-search.js.map