'use client';
import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import * as React from 'react';
import { createPortal } from 'react-dom';
import { AnimatePresence, motion, useReducedMotion } from 'framer-motion';
import { X } from 'lucide-react';
import { cn } from './utils.js';
const SIZE = {
    sm: 'max-w-sm',
    md: 'max-w-lg',
    lg: 'max-w-2xl',
};
/** Centered modal dialog: backdrop, spring scale-in, focus trap, Esc/click-out. */
export function Dialog({ open, onClose, title, description, children, footer, size = 'md', hideClose, closeLabel = 'Close', }) {
    const reduce = useReducedMotion();
    const [mounted, setMounted] = React.useState(false);
    const panelRef = React.useRef(null);
    React.useEffect(() => setMounted(true), []);
    React.useEffect(() => {
        if (!open)
            return;
        const prevOverflow = document.body.style.overflow;
        document.body.style.overflow = 'hidden';
        const previouslyFocused = document.activeElement;
        const focusablesSelector = 'a[href], button:not([disabled]), textarea:not([disabled]), input:not([disabled]), select:not([disabled]), [tabindex]:not([tabindex="-1"])';
        const focusTimer = window.setTimeout(() => {
            const panel = panelRef.current;
            if (!panel)
                return;
            const first = panel.querySelector(focusablesSelector);
            (first ?? panel).focus();
        }, 0);
        function onKey(e) {
            if (e.key === 'Escape') {
                if (document.querySelector('[data-ui-overlay]'))
                    return;
                onClose();
                return;
            }
            if (e.key !== 'Tab')
                return;
            const panel = panelRef.current;
            if (!panel)
                return;
            const items = Array.from(panel.querySelectorAll(focusablesSelector)).filter((el) => el.offsetParent !== null || el === document.activeElement);
            if (items.length === 0) {
                e.preventDefault();
                panel.focus();
                return;
            }
            const first = items[0];
            const last = items[items.length - 1];
            const activeEl = document.activeElement;
            if (e.shiftKey && (activeEl === first || activeEl === panel)) {
                e.preventDefault();
                last.focus();
            }
            else if (!e.shiftKey && activeEl === last) {
                e.preventDefault();
                first.focus();
            }
        }
        document.addEventListener('keydown', onKey);
        return () => {
            document.body.style.overflow = prevOverflow;
            window.clearTimeout(focusTimer);
            document.removeEventListener('keydown', onKey);
            if (previouslyFocused && document.contains(previouslyFocused))
                previouslyFocused.focus();
        };
    }, [open, onClose]);
    if (!mounted || typeof document === 'undefined')
        return null;
    return createPortal(_jsx(AnimatePresence, { children: open ? (_jsxs("div", { className: "fixed inset-0 z-[65] flex items-center justify-center p-4", children: [_jsx(motion.div, { initial: { opacity: 0 }, animate: { opacity: 1 }, exit: { opacity: 0 }, transition: { duration: 0.15 }, className: "absolute inset-0 bg-overlay/50 backdrop-blur-[2px]", onClick: onClose, "aria-hidden": "true" }), _jsxs(motion.div, { ref: panelRef, role: "dialog", "aria-modal": "true", tabIndex: -1, initial: reduce ? { opacity: 0 } : { opacity: 0, scale: 0.96, y: 8 }, animate: reduce ? { opacity: 1 } : { opacity: 1, scale: 1, y: 0 }, exit: reduce ? { opacity: 0 } : { opacity: 0, scale: 0.96, y: 8 }, transition: { type: 'spring', damping: 30, stiffness: 380, mass: 0.7 }, className: cn('relative flex w-full flex-col overflow-hidden rounded-xl border border-border bg-surface shadow-lg', SIZE[size]), children: [title || description ? (_jsxs("div", { className: "space-y-1 px-6 pt-6", children: [title ? _jsx("h2", { className: "text-lg font-semibold text-fg", children: title }) : null, description ? _jsx("p", { className: "text-sm text-fg-muted", children: description }) : null] })) : null, !hideClose ? (_jsx("button", { type: "button", onClick: onClose, "aria-label": closeLabel, className: "absolute right-4 top-4 rounded-md p-1.5 text-fg-muted transition-colors hover:bg-surface-hover hover:text-fg", children: _jsx(X, { className: "size-4" }) })) : null, children ? _jsx("div", { className: "px-6 py-5 text-sm text-fg", children: children }) : null, footer ? (_jsx("div", { className: "flex items-center justify-end gap-2 border-t border-border bg-bg-subtle px-6 py-3", children: footer })) : null] })] })) : null }), document.body);
}
//# sourceMappingURL=dialog.js.map