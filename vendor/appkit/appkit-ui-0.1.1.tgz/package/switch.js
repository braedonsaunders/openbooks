import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import * as React from 'react';
import { cn } from './utils.js';
/**
 * Switch — an accessible checkbox styled as a toggle. Pure CSS (peer), so it's
 * server-renderable and works controlled or uncontrolled. The knob stays light
 * in both themes by convention.
 */
export const Switch = React.forwardRef(({ className, disabled, ...props }, ref) => (_jsxs("label", { className: cn('relative inline-flex h-6 w-11 shrink-0 items-center', disabled ? 'cursor-not-allowed opacity-50' : 'cursor-pointer', className), children: [_jsx("input", { ref: ref, type: "checkbox", role: "switch", className: "peer sr-only", disabled: disabled, ...props }), _jsx("span", { className: "absolute inset-0 rounded-full bg-border-strong transition-colors duration-200 peer-checked:bg-primary peer-focus-visible:ring-2 peer-focus-visible:ring-ring/50 peer-focus-visible:ring-offset-2 peer-focus-visible:ring-offset-bg" }), _jsx("span", { className: "pointer-events-none absolute left-0.5 size-5 rounded-full bg-white shadow-sm transition-transform duration-200 ease-out peer-checked:translate-x-5 motion-reduce:transition-none" })] })));
Switch.displayName = 'Switch';
//# sourceMappingURL=switch.js.map