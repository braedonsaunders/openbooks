import * as React from 'react';
import { type VariantProps } from 'class-variance-authority';
/**
 * Button — the ecosystem's primary action. Every color is a semantic token, so
 * it rebrands and dark-modes for free. The press micro-interaction (scale) and
 * hover shadow reference the shared motion feel and honor reduced-motion.
 */
declare const buttonVariants: (props?: ({
    variant?: "link" | "default" | "secondary" | "outline" | "destructive" | "ghost" | "subtle" | null | undefined;
    size?: "icon" | "sm" | "md" | "lg" | null | undefined;
} & import("class-variance-authority/types").ClassProp) | undefined) => string;
export type ButtonProps = React.ButtonHTMLAttributes<HTMLButtonElement> & VariantProps<typeof buttonVariants> & {
    /** Render onto the single child element instead of a <button>. */
    asChild?: boolean;
};
export declare const Button: React.ForwardRefExoticComponent<React.ButtonHTMLAttributes<HTMLButtonElement> & VariantProps<(props?: ({
    variant?: "link" | "default" | "secondary" | "outline" | "destructive" | "ghost" | "subtle" | null | undefined;
    size?: "icon" | "sm" | "md" | "lg" | null | undefined;
} & import("class-variance-authority/types").ClassProp) | undefined) => string> & {
    /** Render onto the single child element instead of a <button>. */
    asChild?: boolean;
} & React.RefAttributes<HTMLButtonElement>>;
export { buttonVariants };
//# sourceMappingURL=button.d.ts.map