'use client';
import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import * as React from 'react';
import { createPortal } from 'react-dom';
import { AnimatePresence, motion } from 'framer-motion';
import { AlertTriangle, HelpCircle } from 'lucide-react';
import { Button } from './button.js';
let current = null;
let counter = 0;
const listeners = new Set();
function emit() {
    for (const listener of listeners)
        listener();
}
/** Promise-based, application-wide replacement for `window.confirm()`. */
export function confirmDialog(options) {
    const request = typeof options === 'string' ? { message: options } : options;
    return new Promise((resolve) => {
        if (current)
            current.resolve(false);
        current = { ...request, id: ++counter, resolve };
        emit();
    });
}
export function cancelConfirmDialog() {
    settle(false);
}
function settle(confirmed) {
    if (!current)
        return;
    current.resolve(confirmed);
    current = null;
    emit();
}
function subscribe(listener) {
    listeners.add(listener);
    return () => listeners.delete(listener);
}
/** Mount once near the root of an application that calls `confirmDialog`. */
export function ConfirmRoot({ labels = {} }) {
    const request = React.useSyncExternalStore(subscribe, () => current, () => null);
    React.useEffect(() => {
        if (!request)
            return;
        function onKey(event) {
            if (event.key === 'Escape')
                settle(false);
            if (event.key === 'Enter')
                settle(true);
        }
        document.addEventListener('keydown', onKey);
        const previousOverflow = document.body.style.overflow;
        document.body.style.overflow = 'hidden';
        return () => {
            document.removeEventListener('keydown', onKey);
            document.body.style.overflow = previousOverflow;
        };
    }, [request]);
    if (typeof document === 'undefined')
        return null;
    const danger = request?.tone === 'danger';
    const title = request?.title ?? (danger ? labels.dangerTitle ?? 'Are you sure?' : labels.defaultTitle ?? 'Confirm');
    const confirmLabel = request?.confirmLabel ?? labels.confirm ?? 'Confirm';
    const cancelLabel = request?.cancelLabel ?? labels.cancel ?? 'Cancel';
    return createPortal(_jsx(AnimatePresence, { children: request ? (_jsxs("div", { className: "fixed inset-0 z-[60] flex items-center justify-center p-4", role: "dialog", "aria-modal": "true", "aria-labelledby": "appkit-confirm-title", children: [_jsx(motion.div, { initial: { opacity: 0 }, animate: { opacity: 1 }, exit: { opacity: 0 }, transition: { duration: 0.15 }, className: "absolute inset-0 bg-overlay backdrop-blur-[2px]", onClick: () => settle(false), "aria-hidden": "true" }), _jsxs(motion.div, { initial: { opacity: 0, scale: 0.96, y: 8 }, animate: { opacity: 1, scale: 1, y: 0 }, exit: { opacity: 0, scale: 0.96, y: 8 }, transition: { type: 'spring', damping: 26, stiffness: 340, mass: 0.7 }, className: "relative w-full max-w-md overflow-hidden rounded-xl border border-border bg-surface shadow-xl", children: [_jsxs("div", { className: "flex items-start gap-4 p-6", children: [_jsx("div", { className: danger ? 'flex size-10 shrink-0 items-center justify-center rounded-full bg-danger-subtle text-danger' : 'flex size-10 shrink-0 items-center justify-center rounded-full bg-info-subtle text-info', children: danger ? _jsx(AlertTriangle, { size: 20 }) : _jsx(HelpCircle, { size: 20 }) }), _jsxs("div", { className: "min-w-0 space-y-1.5 pt-0.5", children: [_jsx("h2", { id: "appkit-confirm-title", className: "text-base font-semibold text-fg", children: title }), _jsx("div", { className: "text-sm leading-relaxed text-fg-muted", children: request.message })] })] }), _jsxs("div", { className: "flex justify-end gap-2 border-t border-border bg-bg-subtle px-6 py-4", children: [_jsx(Button, { variant: "outline", onClick: () => settle(false), children: cancelLabel }), _jsx(Button, { autoFocus: true, variant: danger ? 'destructive' : 'default', onClick: () => settle(true), children: confirmLabel })] })] })] }, request.id)) : null }), document.body);
}
//# sourceMappingURL=confirm-dialog.js.map