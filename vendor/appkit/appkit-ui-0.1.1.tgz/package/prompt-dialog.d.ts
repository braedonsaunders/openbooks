import * as React from 'react';
export type PromptDialogOptions = {
    title: string;
    /** Field label above the input. */
    label?: string;
    /** Pre-filled and selected value. */
    initialValue?: string;
    placeholder?: string;
    confirmLabel?: string;
    cancelLabel?: string;
};
/** Opens the shared text-input modal and resolves to a trimmed value or null. */
export declare function promptDialog(options: PromptDialogOptions): Promise<string | null>;
/** Cancels the active prompt, if one exists. */
export declare function cancelPromptDialog(): void;
/** Mount once beside the application's toaster. */
export declare function PromptRoot({ defaultConfirmLabel, defaultCancelLabel, }: {
    defaultConfirmLabel?: string;
    defaultCancelLabel?: string;
}): React.ReactPortal | null;
//# sourceMappingURL=prompt-dialog.d.ts.map