'use client';
import { jsx as _jsx, Fragment as _Fragment, jsxs as _jsxs } from "react/jsx-runtime";
import * as React from 'react';
import { ChevronLeft, ChevronRight } from 'lucide-react';
import { mergeHref } from './list-params.js';
import { useListNavClick } from './list-nav.js';
const DEFAULT_LABELS = {
    showing: (from, to, total) => (_jsxs(_Fragment, { children: ["Showing ", _jsx("strong", { className: "font-medium text-fg", children: from }), "\u2013", _jsx("strong", { className: "font-medium text-fg", children: to }), " of", ' ', _jsx("strong", { className: "font-medium text-fg", children: total })] })),
    noResults: 'No results',
    prev: 'Prev',
    next: 'Next',
    pageOf: (page, pages) => `Page ${page} of ${pages}`,
    outOfRange: (page) => `Page ${page} is out of range`,
    goToPage: (page) => `Go to page ${page}`,
};
/**
 * URL-driven pagination row: showing X–Y of N + prev/next. When the current
 * page is past the end (a filter shrank the list), offers a jump to the last
 * page. Localized copy is supplied through the labels prop.
 */
export function Pagination({ basePath, currentParams, total, page, perPage, pageParamKey = 'page', labels: labelOverrides, }) {
    const labels = { ...DEFAULT_LABELS, ...labelOverrides };
    const pageCount = Math.max(1, Math.ceil(total / perPage));
    const isOutOfRange = total > 0 && page > pageCount;
    const from = total === 0 ? 0 : (page - 1) * perPage + 1;
    const to = Math.min(total, page * perPage);
    const prevHref = mergeHref(basePath, currentParams, { [pageParamKey]: page > 1 ? page - 1 : 1 });
    const nextHref = mergeHref(basePath, currentParams, { [pageParamKey]: Math.min(pageCount, page + 1) });
    const lastPageHref = mergeHref(basePath, currentParams, { [pageParamKey]: pageCount });
    return (_jsxs("div", { className: "flex items-center justify-between gap-2 px-3 py-2 text-sm text-fg-muted", children: [_jsx("span", { children: isOutOfRange
                    ? labels.outOfRange(page.toLocaleString())
                    : total === 0
                        ? labels.noResults
                        : labels.showing(from.toLocaleString(), to.toLocaleString(), total.toLocaleString()) }), isOutOfRange ? (_jsxs(PageButton, { href: lastPageHref, "aria-label": labels.goToPage(pageCount.toLocaleString()), children: [_jsx(ChevronLeft, { size: 14 }), labels.goToPage(pageCount.toLocaleString())] })) : pageCount > 1 ? (_jsxs("div", { className: "flex items-center gap-1", children: [_jsxs(PageButton, { href: prevHref, disabled: page <= 1, children: [_jsx(ChevronLeft, { size: 14 }), labels.prev] }), _jsx("span", { className: "px-2 text-fg-subtle", children: labels.pageOf(page, pageCount) }), _jsxs(PageButton, { href: nextHref, disabled: page >= pageCount, children: [labels.next, _jsx(ChevronRight, { size: 14 })] })] })) : null] }));
}
function PageButton({ href, disabled, children, ...rest }) {
    const navClick = useListNavClick(href);
    if (disabled) {
        return (_jsx("span", { className: "inline-flex cursor-not-allowed items-center gap-1 rounded-md border border-border px-2 py-1 text-xs text-fg-subtle", ...rest, children: children }));
    }
    return (_jsx("a", { href: href, onClick: navClick, className: "inline-flex items-center gap-1 rounded-md border border-border px-2 py-1 text-xs text-fg hover:bg-surface-hover", ...rest, children: children }));
}
//# sourceMappingURL=list-pagination.js.map