import * as React from 'react';
export type SwitchProps = React.InputHTMLAttributes<HTMLInputElement>;
/**
 * Switch — an accessible checkbox styled as a toggle. Pure CSS (peer), so it's
 * server-renderable and works controlled or uncontrolled. The knob stays light
 * in both themes by convention.
 */
export declare const Switch: React.ForwardRefExoticComponent<SwitchProps & React.RefAttributes<HTMLInputElement>>;
//# sourceMappingURL=switch.d.ts.map