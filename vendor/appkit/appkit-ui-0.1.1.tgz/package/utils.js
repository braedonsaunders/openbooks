import { clsx } from 'clsx';
import { twMerge } from 'tailwind-merge';
/** Merge Tailwind class lists with correct conflict resolution. */
export function cn(...inputs) {
    return twMerge(clsx(inputs));
}
//# sourceMappingURL=utils.js.map