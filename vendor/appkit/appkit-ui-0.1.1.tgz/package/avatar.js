'use client';
import { jsx as _jsx } from "react/jsx-runtime";
import * as React from 'react';
import { cn } from './utils.js';
function initials(name) {
    if (!name)
        return '?';
    const parts = name.trim().split(/\s+/);
    const first = parts[0]?.[0] ?? '';
    const last = parts.length > 1 ? parts[parts.length - 1]?.[0] ?? '' : '';
    return (first + last).toUpperCase() || '?';
}
export function Avatar({ src, name, size = 40, className }) {
    const [failed, setFailed] = React.useState(false);
    const showImage = src && !failed;
    return (_jsx("span", { className: cn('inline-flex shrink-0 items-center justify-center overflow-hidden rounded-full bg-primary-subtle font-medium text-primary select-none', className), style: { width: size, height: size, fontSize: Math.round(size * 0.38) }, "aria-label": name, role: "img", children: showImage ? (_jsx("img", { src: src, alt: name ?? '', className: "size-full object-cover", onError: () => setFailed(true) })) : (initials(name)) }));
}
//# sourceMappingURL=avatar.js.map