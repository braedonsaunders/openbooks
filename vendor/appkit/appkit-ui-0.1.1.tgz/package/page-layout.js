import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import * as React from 'react';
import { cn } from './utils.js';
// The page shells that fill an AppShell's <main>. The fade-in is the CSS
// `.reveal` (visible-by-default @starting-style), never a JS animation.
/** Content-driven pages (dashboards, forms): the whole body scrolls. */
export function PageContainer({ className, children }) {
    return (_jsx("div", { className: "app-scroll flex-1 overflow-y-auto", children: _jsx("div", { className: cn('reveal mx-auto w-full max-w-(--breakpoint-2xl) p-4 sm:p-6', className), children: children }) }));
}
/** List pages: a sticky header (title/actions/search/filters); only the body scrolls. */
export function ListPageLayout({ header, children, className, }) {
    return (_jsxs("div", { className: "flex h-full min-h-0 flex-col", children: [_jsx("div", { className: "border-b border-border bg-surface px-3 pb-2.5 pt-3 sm:px-6 sm:pb-3 sm:pt-4", children: _jsx("div", { className: "reveal mx-auto max-w-(--breakpoint-2xl) space-y-2 sm:space-y-2.5", children: header }) }), _jsx("div", { className: "app-scroll min-h-0 flex-1 overflow-y-auto", children: _jsx("div", { className: cn('reveal mx-auto max-w-(--breakpoint-2xl) p-3 sm:p-6', className), children: children }) })] }));
}
/** Detail pages: fixed header + optional alerts + subtab strip; content scrolls. */
export function DetailPageLayout({ header, alerts, subtabs, children, className, }) {
    return (_jsxs("div", { className: "flex h-full min-h-0 flex-col", children: [_jsx("div", { className: "border-b border-border bg-surface", children: _jsxs("div", { className: "reveal mx-auto max-w-(--breakpoint-2xl) px-3 pt-3 sm:px-6 sm:pt-5", children: [header, alerts ? _jsx("div", { className: "mt-2.5 space-y-2 sm:mt-3", children: alerts }) : null, subtabs ? _jsx("div", { className: "mt-2.5 sm:mt-4", children: subtabs }) : null] }) }), _jsx("div", { className: "app-scroll min-h-0 flex-1 overflow-y-auto", children: _jsx("div", { className: cn('reveal mx-auto max-w-(--breakpoint-2xl) p-3 sm:p-6', className), children: children }) })] }));
}
/** Wizard/form pages: sticky header, scrolling body, optional sticky footer. */
export function WizardLayout({ header, footer, children, className, wide = false, }) {
    const maxW = wide ? 'max-w-(--breakpoint-2xl)' : 'max-w-3xl';
    return (_jsxs("div", { className: cn('flex h-full min-h-0 flex-col', className), children: [_jsx("div", { className: "border-b border-border bg-surface", children: _jsx("div", { className: cn('reveal mx-auto px-4 py-4 sm:px-6', maxW), children: header }) }), _jsx("div", { className: "app-scroll min-h-0 flex-1 overflow-y-auto", children: _jsx("div", { className: cn('reveal mx-auto space-y-5 p-4 sm:p-6', maxW), children: children }) }), footer != null ? (_jsx("div", { className: "border-t border-border bg-surface", children: _jsx("div", { className: cn('mx-auto px-4 py-3 sm:px-6', maxW), children: footer }) })) : null] }));
}
//# sourceMappingURL=page-layout.js.map