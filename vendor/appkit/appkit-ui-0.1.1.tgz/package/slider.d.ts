import * as React from 'react';
export type SliderProps = Omit<React.InputHTMLAttributes<HTMLInputElement>, 'type'>;
/**
 * Slider — a tokenized range input for bounded, imprecise values (percent
 * complete, opacity, weighting). It stays a native `<input type="range">` so
 * keyboard, touch, and assistive-technology behaviour come for free; only the
 * track and thumb are restyled, through `accent-color`.
 *
 * For an exact number, use `Input type="number"` — a slider says "roughly
 * this much", and dressing up a precise field as one loses that meaning.
 */
export declare const Slider: React.ForwardRefExoticComponent<SliderProps & React.RefAttributes<HTMLInputElement>>;
//# sourceMappingURL=slider.d.ts.map