'use client';
import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import * as React from 'react';
import { createPortal } from 'react-dom';
import { AnimatePresence, motion, useReducedMotion } from 'framer-motion';
import { cn } from './utils.js';
const SIZE_CLASS = {
    sm: 'w-full sm:max-w-md',
    md: 'w-full sm:max-w-xl',
    lg: 'w-full sm:max-w-2xl',
    xl: 'w-full sm:max-w-4xl',
    '2xl': 'w-full sm:max-w-6xl',
    full: 'w-full',
};
const DEFAULT_DRAWER_TEXT = {
    close: 'Close',
    fullscreen: 'Fullscreen',
    exitFullscreen: 'Exit fullscreen',
};
const DrawerTextContext = React.createContext(DEFAULT_DRAWER_TEXT);
export function DrawerTextProvider({ value, children, }) {
    const merged = React.useMemo(() => ({ ...DEFAULT_DRAWER_TEXT, ...value }), [value]);
    return _jsx(DrawerTextContext.Provider, { value: merged, children: children });
}
function useDrawerText() {
    return React.useContext(DrawerTextContext);
}
// Ref-counted scroll lock — nested/stacked drawers share one lock so the body
// only unlocks when the last drawer closes.
let openDrawerCount = 0;
let originalBodyOverflow = null;
const FOCUSABLE = 'a[href], button:not([disabled]), textarea:not([disabled]), input:not([disabled]), select:not([disabled]), [tabindex]:not([tabindex="-1"])';
/**
 * Slide-in flyout for sub-entity create/edit and detail views. Portals to body;
 * spring slide-in; backdrop fade+blur; Esc + click-out + ref-counted scroll
 * lock; focus trap + restore; a NetSuite-style expand/collapse to full viewport
 * width (animated via max-width). Fully tokenized and reduced-motion aware.
 */
export function Drawer({ open, onClose, title, description, size = 'md', side = 'right', children, footer, headerActions, subtabs, bodyClassName, panelClassName, stacked = false, initialFullscreen = false, disableFullscreen = false, onExitComplete, }) {
    const text = useDrawerText();
    const tr = text.translate ?? ((s) => s);
    const reduce = useReducedMotion();
    const [mounted, setMounted] = React.useState(false);
    React.useEffect(() => setMounted(true), []);
    const [fullscreen, setFullscreen] = React.useState(initialFullscreen);
    React.useEffect(() => {
        if (!open)
            setFullscreen(initialFullscreen);
    }, [initialFullscreen, open]);
    const panelRef = React.useRef(null);
    // Esc + scroll lock. Stacked-aware: a base drawer ignores Esc while a nested
    // drawer or a floating overlay is on top.
    React.useEffect(() => {
        if (!open)
            return;
        function onKey(e) {
            if (e.key !== 'Escape')
                return;
            if (document.querySelector('[data-ui-overlay]'))
                return;
            if (!stacked && document.querySelector('[data-drawer-layer="nested"]'))
                return;
            onClose();
        }
        document.addEventListener('keydown', onKey);
        if (openDrawerCount === 0)
            originalBodyOverflow = document.body.style.overflow;
        openDrawerCount += 1;
        document.body.style.overflow = 'hidden';
        return () => {
            document.removeEventListener('keydown', onKey);
            openDrawerCount = Math.max(0, openDrawerCount - 1);
            if (openDrawerCount === 0) {
                document.body.style.overflow = originalBodyOverflow ?? '';
                originalBodyOverflow = null;
            }
        };
    }, [open, onClose, stacked]);
    // Focus management: move focus in on open, trap Tab, restore on close.
    React.useEffect(() => {
        if (!open)
            return;
        const previouslyFocused = document.activeElement;
        const focusTimer = window.setTimeout(() => {
            if (!stacked && document.querySelector('[data-drawer-layer="nested"]'))
                return;
            const panel = panelRef.current;
            if (!panel)
                return;
            const first = panel.querySelector(FOCUSABLE);
            (first ?? panel).focus();
        }, 0);
        function onKeyDown(e) {
            if (e.key !== 'Tab')
                return;
            if (!stacked && document.querySelector('[data-drawer-layer="nested"]'))
                return;
            const panel = panelRef.current;
            if (!panel)
                return;
            const focusables = Array.from(panel.querySelectorAll(FOCUSABLE)).filter((el) => el.offsetParent !== null || el === document.activeElement);
            if (focusables.length === 0) {
                e.preventDefault();
                panel.focus();
                return;
            }
            const firstEl = focusables[0];
            const lastEl = focusables[focusables.length - 1];
            const activeEl = document.activeElement;
            if (e.shiftKey) {
                if (activeEl === firstEl || activeEl === panel || !panel.contains(activeEl)) {
                    e.preventDefault();
                    lastEl.focus();
                }
            }
            else if (activeEl === lastEl) {
                e.preventDefault();
                firstEl.focus();
            }
        }
        document.addEventListener('keydown', onKeyDown);
        return () => {
            window.clearTimeout(focusTimer);
            document.removeEventListener('keydown', onKeyDown);
            if (previouslyFocused && document.contains(previouslyFocused))
                previouslyFocused.focus();
        };
    }, [open, stacked]);
    if (typeof document === 'undefined')
        return null;
    const offscreen = side === 'left' ? '-100%' : '100%';
    const panelMotion = reduce
        ? {
            initial: { opacity: 0 },
            animate: { opacity: 1 },
            exit: { opacity: 0 },
            transition: { duration: 0.12 },
        }
        : {
            initial: { x: offscreen },
            animate: { x: 0 },
            exit: { x: offscreen },
            transition: { type: 'spring', damping: 32, stiffness: 320, mass: 0.8 },
        };
    return createPortal(_jsx(AnimatePresence, { onExitComplete: onExitComplete, children: mounted && open ? (_jsxs("div", { "data-drawer-layer": stacked ? 'nested' : 'base', className: cn('fixed inset-x-0 bottom-0 top-[var(--drawer-top,0px)]', stacked ? 'z-[55]' : 'z-50'), children: [_jsx(motion.div, { initial: { opacity: 0 }, animate: { opacity: 1 }, exit: { opacity: 0 }, transition: { duration: 0.15 }, className: "absolute inset-0 bg-overlay/40 backdrop-blur-[2px]", onClick: onClose, "aria-hidden": "true" }), _jsxs(motion.aside, { ref: panelRef, role: "dialog", "aria-modal": "true", tabIndex: -1, ...panelMotion, className: cn('absolute inset-y-0 flex flex-col overflow-hidden border-t border-border bg-surface shadow-lg transition-[max-width] duration-300 ease-in-out', side === 'left' ? 'left-0 border-r' : 'right-0 border-l', 
                    // Full replacement (not additive): two sm:max-w-* utilities on one
                    // element resolve by stylesheet order, so stacking them no-ops.
                    fullscreen ? 'w-full sm:max-w-[100vw]' : SIZE_CLASS[size], panelClassName), children: [title || description || headerActions ? (_jsxs("header", { className: "flex items-center justify-between gap-4 border-b border-border px-6 py-4", children: [_jsxs("div", { className: "min-w-0 space-y-0.5", children: [title ? (_jsx("h2", { className: "truncate text-base font-semibold text-fg", children: typeof title === 'string' ? tr(title) : title })) : null, description ? (_jsx("p", { className: "text-sm text-fg-muted", children: typeof description === 'string' ? tr(description) : description })) : null] }), _jsxs("div", { className: "flex shrink-0 items-center gap-2", children: [headerActions ? (_jsx("div", { className: "flex flex-wrap items-center justify-end gap-2", children: headerActions })) : null, !disableFullscreen ? (_jsx("button", { type: "button", onClick: () => setFullscreen((f) => !f), className: "hidden rounded-md p-1.5 text-fg-muted transition-colors hover:bg-surface-hover hover:text-fg sm:block", "aria-label": fullscreen ? text.exitFullscreen : text.fullscreen, title: fullscreen ? text.exitFullscreen : text.fullscreen, children: fullscreen ? (_jsxs("svg", { width: "18", height: "18", viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", strokeWidth: "2", strokeLinecap: "round", strokeLinejoin: "round", children: [_jsx("polyline", { points: "4 14 10 14 10 20" }), _jsx("polyline", { points: "20 10 14 10 14 4" }), _jsx("line", { x1: "14", y1: "10", x2: "21", y2: "3" }), _jsx("line", { x1: "3", y1: "21", x2: "10", y2: "14" })] })) : (_jsxs("svg", { width: "18", height: "18", viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", strokeWidth: "2", strokeLinecap: "round", strokeLinejoin: "round", children: [_jsx("polyline", { points: "15 3 21 3 21 9" }), _jsx("polyline", { points: "9 21 3 21 3 15" }), _jsx("line", { x1: "21", y1: "3", x2: "14", y2: "10" }), _jsx("line", { x1: "3", y1: "21", x2: "10", y2: "14" })] })) })) : null, _jsx("button", { type: "button", onClick: onClose, className: "rounded-md p-1.5 text-fg-muted transition-colors hover:bg-surface-hover hover:text-fg", "aria-label": text.close, children: _jsxs("svg", { width: "18", height: "18", viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", strokeWidth: "2", strokeLinecap: "round", strokeLinejoin: "round", children: [_jsx("line", { x1: "18", y1: "6", x2: "6", y2: "18" }), _jsx("line", { x1: "6", y1: "6", x2: "18", y2: "18" })] }) })] })] })) : null, subtabs ? (_jsx("div", { className: "shrink-0 border-b border-border bg-surface px-6", children: subtabs })) : null, _jsx("div", { className: cn('app-scroll min-h-0 flex-1 text-fg', bodyClassName ?? 'overflow-y-auto px-6 py-5'), children: children }), footer ? (_jsx("footer", { className: "flex items-center justify-end gap-2 border-t border-border bg-bg-subtle px-6 py-3", children: footer })) : null] })] }, "drawer")) : null }), document.body);
}
/**
 * Client-side navigate fn supplied by the host app (e.g. Next's `router.push`)
 * so `UrlDrawer` can close by changing the URL — which re-runs the server
 * component that owns the drawer's `open` state. Falls back to a hard nav.
 */
export const DrawerNavigateContext = React.createContext(null);
/**
 * URL-state drawer for server-rendered pages: `open` derives from a search
 * param, so closing needs a real navigation (deferred until the slide-out
 * finishes, so the exit animation always plays).
 */
export function UrlDrawer({ open, closeHref, children, ...rest }) {
    const navigate = React.useContext(DrawerNavigateContext);
    const [show, setShow] = React.useState(open);
    React.useEffect(() => setShow(open), [open]);
    function afterExit() {
        if (typeof window === 'undefined')
            return;
        if (navigate)
            navigate(closeHref);
        else
            window.location.assign(closeHref);
    }
    return (_jsx(Drawer, { open: show, onClose: () => setShow(false), onExitComplete: afterExit, ...rest, children: children }));
}
//# sourceMappingURL=drawer.js.map