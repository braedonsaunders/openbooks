import * as React from 'react';
import { type BadgeProps } from './badge.js';
export type RecordCellKind = 'text' | 'amount' | 'status' | 'reference' | 'actions' | 'custom';
export type RecordColumn<Row> = {
    key: string;
    label: string;
    kind?: RecordCellKind;
    align?: 'left' | 'right';
    sortable?: boolean;
    width?: number | string;
    /** Custom / override renderer. */
    render?: (row: Row) => React.ReactNode;
    /** For `reference` cells — the destination href. */
    href?: (row: Row) => string;
    /** For `amount`/`text` cells — format the raw value. */
    format?: (value: unknown, row: Row) => React.ReactNode;
    /** For `status` cells — map a value to a Badge variant. */
    statusVariant?: (value: string) => BadgeProps['variant'];
};
export type RecordListLink = (props: {
    href: string;
    children: React.ReactNode;
    className: string;
}) => React.ReactNode;
export type RecordListProps<Row> = {
    columns: RecordColumn<Row>[];
    rows: Row[];
    getRowId: (row: Row) => string;
    search?: {
        value: string;
        onChange: (v: string) => void;
        placeholder?: string;
    };
    /** Filter chips or other toolbar-left content. */
    filters?: React.ReactNode;
    /** Toolbar-right content (e.g. a saved-views switcher). */
    toolbarActions?: React.ReactNode;
    sort?: {
        key: string;
        dir: 'asc' | 'desc';
    };
    onSortChange?: (key: string) => void;
    pagination?: {
        page: number;
        perPage: number;
        total: number;
        onPageChange: (page: number) => void;
    };
    empty?: {
        title: string;
        description?: string;
        action?: React.ReactNode;
        icon?: React.ReactNode;
    };
    /** Supply an app router Link for reference cells (falls back to <a>). */
    linkRender?: RecordListLink;
    onRowClick?: (row: Row) => void;
};
export declare function RecordList<Row>({ columns, rows, getRowId, search, filters, toolbarActions, sort, onSortChange, pagination, empty, linkRender, onRowClick, }: RecordListProps<Row>): React.JSX.Element;
//# sourceMappingURL=record-list.d.ts.map