import * as React from 'react';
import { type ListSearchParams } from './list-params.js';
export type FilterOption = {
    value: string;
    label: string;
    count?: number;
};
/**
 * Single-select filter rendered as a compact dropdown button. Collapses a whole
 * row of chips into one pill showing the active selection inline, so several
 * filters + the search box fit one toolbar row. Selecting an option navigates —
 * the param lives in the URL. Tokenized,
 * next Link → soft-nav anchors, i18n → props.)
 */
export declare function FilterChips({ basePath, currentParams, paramKey, label, options, allLabel, defaultValue, pageParamKey, hideAll, }: {
    basePath: string;
    currentParams: ListSearchParams;
    paramKey: string;
    label: string;
    options: FilterOption[];
    allLabel?: string;
    /** Treated as the active selection while the URL carries no param; picking
     *  "All" then navigates to an explicit `all` sentinel. */
    defaultValue?: string;
    /** Pagination parameter reset when this filter changes. */
    pageParamKey?: string;
    /** Hide the generic All option (e.g. sort selectors). */
    hideAll?: boolean;
}): React.JSX.Element;
/**
 * Searchable URL-backed filter for long option lists. This preserves the
 * production reference call surface while replacing framework router hooks
 * with AppKit's injectable list-navigation bridge.
 */
export declare function SearchSelectFilter({ paramKey, label, options, allLabel, pageParamKey, className, }: {
    paramKey: string;
    label: string;
    options: {
        value: string;
        label: string;
        hint?: string;
    }[];
    allLabel?: string;
    pageParamKey?: string;
    className?: string;
}): React.JSX.Element;
//# sourceMappingURL=filter-chips.d.ts.map