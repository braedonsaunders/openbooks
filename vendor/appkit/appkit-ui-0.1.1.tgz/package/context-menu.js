'use client';
import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import * as React from 'react';
import { createPortal } from 'react-dom';
import { AnimatePresence, motion } from 'framer-motion';
import { cn } from './utils.js';
export function useContextMenu() {
    const [position, setPosition] = React.useState(null);
    const openAt = React.useCallback((x, y) => setPosition({ x, y }), []);
    const onContextMenu = React.useCallback((e) => {
        e.preventDefault();
        e.stopPropagation();
        setPosition({ x: e.clientX, y: e.clientY });
    }, []);
    const openBelow = React.useCallback((el) => {
        const r = el.getBoundingClientRect();
        setPosition({ x: r.right, y: r.bottom + 4 });
    }, []);
    const close = React.useCallback(() => setPosition(null), []);
    return { open: position != null, position, openAt, onContextMenu, openBelow, close };
}
export function ContextMenu({ open, position, items, onClose, className, }) {
    const panelRef = React.useRef(null);
    const [mounted, setMounted] = React.useState(false);
    const [coords, setCoords] = React.useState(null);
    React.useEffect(() => setMounted(true), []);
    // Clamp inside the viewport before paint so the menu never flashes off-screen.
    React.useLayoutEffect(() => {
        if (!open || !position) {
            setCoords(null);
            return;
        }
        const panel = panelRef.current;
        const pw = panel?.offsetWidth ?? 176;
        const ph = panel?.offsetHeight ?? 0;
        const pad = 8;
        let x = position.x;
        let y = position.y;
        if (x + pw + pad > window.innerWidth)
            x = window.innerWidth - pw - pad;
        if (y + ph + pad > window.innerHeight)
            y = window.innerHeight - ph - pad;
        setCoords({ x: Math.max(pad, x), y: Math.max(pad, y) });
    }, [open, position]);
    React.useEffect(() => {
        if (!open)
            return;
        function onDown(e) {
            if (panelRef.current?.contains(e.target))
                return;
            onClose();
        }
        function onKey(e) {
            if (e.key === 'Escape')
                onClose();
        }
        function onScroll() {
            onClose();
        }
        const t = setTimeout(() => {
            document.addEventListener('mousedown', onDown);
            document.addEventListener('contextmenu', onDown);
            document.addEventListener('keydown', onKey);
            window.addEventListener('scroll', onScroll, true);
            window.addEventListener('resize', onScroll);
        }, 0);
        return () => {
            clearTimeout(t);
            document.removeEventListener('mousedown', onDown);
            document.removeEventListener('contextmenu', onDown);
            document.removeEventListener('keydown', onKey);
            window.removeEventListener('scroll', onScroll, true);
            window.removeEventListener('resize', onScroll);
        };
    }, [open, onClose]);
    if (!mounted || typeof document === 'undefined')
        return null;
    const at = coords ?? position;
    return createPortal(_jsx(AnimatePresence, { children: open && at ? (_jsx(motion.div, { ref: panelRef, "data-ui-overlay": true, initial: { opacity: 0, scale: 0.96 }, animate: { opacity: 1, scale: 1 }, exit: { opacity: 0, scale: 0.96 }, transition: { duration: 0.12, ease: [0.16, 1, 0.3, 1] }, className: cn('fixed z-[70] min-w-[11rem] max-w-[16rem] overflow-hidden rounded-md border border-border bg-elevated p-1 shadow-lg', className), style: { left: at.x, top: at.y, transformOrigin: 'top left' }, role: "menu", children: items.map((item) => 'separator' in item ? (_jsx("div", { className: "my-1 h-px bg-border" }, item.key)) : (_jsxs("button", { type: "button", role: "menuitem", disabled: item.disabled, onClick: () => {
                    if (item.disabled)
                        return;
                    onClose();
                    item.onSelect();
                }, className: cn('flex w-full items-center gap-2.5 rounded px-2.5 py-1.5 text-left text-sm transition-colors', item.disabled
                    ? 'cursor-not-allowed text-fg-subtle'
                    : item.danger
                        ? 'text-danger hover:bg-danger-subtle'
                        : 'text-fg hover:bg-surface-hover'), children: [item.icon ? _jsx(item.icon, { className: "size-4 shrink-0 opacity-80" }) : null, _jsx("span", { className: "flex-1 truncate", children: item.label })] }, item.key))) })) : null }), document.body);
}
//# sourceMappingURL=context-menu.js.map