import * as React from 'react';
/**
 * Universal context menu — a floating list of actions opened at a point.
 * Trigger it via {@link useContextMenu}, either from a right-click
 * (`onContextMenu={menu.onContextMenu}`) or a kebab button
 * (`onClick={(e) => menu.openBelow(e.currentTarget)}`). The panel portals to
 * <body>, clamps inside the viewport, and closes on outside-click / Esc /
 * scroll. Items carry an icon, label, and handler; `danger` tints destructive
 * actions and `{ separator: true }` draws a divider.
 */
export interface ContextMenuItem {
    key: string;
    label: string;
    icon?: React.ComponentType<{
        className?: string;
    }>;
    onSelect: () => void;
    disabled?: boolean;
    danger?: boolean;
}
export type ContextMenuEntry = ContextMenuItem | {
    key: string;
    separator: true;
};
export interface ContextMenuController {
    open: boolean;
    position: {
        x: number;
        y: number;
    } | null;
    openAt: (x: number, y: number) => void;
    onContextMenu: (e: React.MouseEvent) => void;
    openBelow: (el: HTMLElement) => void;
    close: () => void;
}
export declare function useContextMenu(): ContextMenuController;
export declare function ContextMenu({ open, position, items, onClose, className, }: {
    open: boolean;
    position: {
        x: number;
        y: number;
    } | null;
    items: ContextMenuEntry[];
    onClose: () => void;
    className?: string;
}): React.ReactPortal | null;
//# sourceMappingURL=context-menu.d.ts.map