import { type ReactNode } from 'react';
export type UiTextTranslator = (value: string, values?: Readonly<Record<string, unknown>>) => string;
/** Injects the host application's exact-copy translator into framework-agnostic UI primitives. */
export declare function UiTextProvider({ translate, children, }: {
    translate: UiTextTranslator;
    children: ReactNode;
}): import("react").JSX.Element;
export declare function useUiText(): UiTextTranslator;
//# sourceMappingURL=text-context.d.ts.map