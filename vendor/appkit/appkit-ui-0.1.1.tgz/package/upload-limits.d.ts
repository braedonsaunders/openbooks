export type AttachmentKind = 'image' | 'document' | 'video' | 'audio' | 'signature' | 'other';
export declare function defaultMaxUploadBytes(kind: AttachmentKind): number;
export declare function formatUploadSizeLimit(sizeBytes: number): string;
//# sourceMappingURL=upload-limits.d.ts.map