import * as React from 'react';
export type UiLinkComponent = React.ComponentType<React.AnchorHTMLAttributes<HTMLAnchorElement> & {
    href: string;
}>;
/** Inject an app router link once so appkit primitives never force full reloads. */
export declare function UiLinkProvider({ link, children, }: {
    link: UiLinkComponent;
    children: React.ReactNode;
}): React.JSX.Element;
export declare function UiLink({ href, ...rest }: React.AnchorHTMLAttributes<HTMLAnchorElement> & {
    href: string;
}): React.JSX.Element;
export type BackLinkProps = {
    href: string;
    label: string;
    className?: string;
};
export type BackLinkLike = React.ComponentType<BackLinkProps>;
export type BackLinkComponent = BackLinkLike;
/** Inject an app-aware history resolver for every PageHeader back link. */
export declare function UiBackLinkProvider({ backLink, children, }: {
    backLink: BackLinkLike;
    children: React.ReactNode;
}): React.JSX.Element;
export declare function UiBackLink({ href, label, className }: BackLinkProps): React.JSX.Element;
//# sourceMappingURL=link-context.d.ts.map