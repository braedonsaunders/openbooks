import * as React from 'react';
/** Content-driven pages (dashboards, forms): the whole body scrolls. */
export declare function PageContainer({ className, children }: {
    className?: string;
    children: React.ReactNode;
}): React.JSX.Element;
/** List pages: a sticky header (title/actions/search/filters); only the body scrolls. */
export declare function ListPageLayout({ header, children, className, }: {
    header: React.ReactNode;
    children: React.ReactNode;
    className?: string;
}): React.JSX.Element;
/** Detail pages: fixed header + optional alerts + subtab strip; content scrolls. */
export declare function DetailPageLayout({ header, alerts, subtabs, children, className, }: {
    header: React.ReactNode;
    alerts?: React.ReactNode;
    subtabs?: React.ReactNode;
    children: React.ReactNode;
    className?: string;
}): React.JSX.Element;
/** Wizard/form pages: sticky header, scrolling body, optional sticky footer. */
export declare function WizardLayout({ header, footer, children, className, wide, }: {
    header: React.ReactNode;
    footer?: React.ReactNode;
    children: React.ReactNode;
    className?: string;
    wide?: boolean;
}): React.JSX.Element;
//# sourceMappingURL=page-layout.d.ts.map