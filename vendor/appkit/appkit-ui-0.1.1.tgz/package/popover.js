'use client';
import { jsx as _jsx, Fragment as _Fragment, jsxs as _jsxs } from "react/jsx-runtime";
import * as React from 'react';
import { createPortal } from 'react-dom';
import { AnimatePresence, motion } from 'framer-motion';
import { cn } from './utils.js';
/**
 * Portal-based popover that escapes any overflow-hidden ancestor. The trigger
 * stays in place; the floating panel renders into <body> at a fixed position
 * computed from the trigger's rect and re-measured on scroll/resize.
 */
export function Popover({ trigger, open, onOpenChange, align = 'end', side = 'bottom', className, children, }) {
    const triggerRef = React.useRef(null);
    const panelRef = React.useRef(null);
    const [rect, setRect] = React.useState(null);
    const [mounted, setMounted] = React.useState(false);
    React.useEffect(() => setMounted(true), []);
    React.useEffect(() => {
        if (!open)
            return;
        const t = triggerRef.current?.firstElementChild;
        if (!t)
            return;
        function measure() {
            const r = t.getBoundingClientRect();
            setRect({ top: r.top, left: r.left, width: r.width, height: r.height });
        }
        measure();
        window.addEventListener('resize', measure);
        window.addEventListener('scroll', measure, true);
        return () => {
            window.removeEventListener('resize', measure);
            window.removeEventListener('scroll', measure, true);
        };
    }, [open]);
    React.useEffect(() => {
        if (!open)
            return;
        function onClick(e) {
            const target = e.target;
            if (panelRef.current?.contains(target))
                return;
            if (triggerRef.current?.contains(target))
                return;
            // Nested overlays are portaled siblings, not descendants — treat as inside.
            if (target instanceof Element && target.closest('[data-ui-overlay]'))
                return;
            onOpenChange(false);
        }
        function onKey(e) {
            if (e.key === 'Escape')
                onOpenChange(false);
        }
        const t = setTimeout(() => {
            document.addEventListener('mousedown', onClick);
            document.addEventListener('keydown', onKey);
        }, 0);
        return () => {
            clearTimeout(t);
            document.removeEventListener('mousedown', onClick);
            document.removeEventListener('keydown', onKey);
        };
    }, [open, onOpenChange]);
    return (_jsxs(_Fragment, { children: [_jsx("div", { ref: triggerRef, className: "contents", children: trigger }), mounted && rect && typeof document !== 'undefined'
                ? createPortal(_jsx(AnimatePresence, { children: open ? (_jsx(motion.div, { ref: panelRef, "data-ui-overlay": true, initial: {
                            opacity: 0,
                            x: side === 'right' ? -4 : side === 'left' ? 4 : 0,
                            y: side === 'bottom' ? -4 : side === 'top' ? 4 : 0,
                            scale: 0.97,
                        }, animate: { opacity: 1, x: 0, y: 0, scale: 1 }, exit: {
                            opacity: 0,
                            x: side === 'right' ? -4 : side === 'left' ? 4 : 0,
                            y: side === 'bottom' ? -4 : side === 'top' ? 4 : 0,
                            scale: 0.97,
                        }, transition: { duration: 0.14, ease: [0.16, 1, 0.3, 1] }, className: cn('fixed z-[60] min-w-[12rem] origin-top rounded-md border border-border bg-elevated shadow-lg', className), style: {
                            top: side === 'bottom'
                                ? rect.top + rect.height + 4
                                : (side === 'left' || side === 'right') && align === 'start'
                                    ? rect.top
                                    : undefined,
                            bottom: side === 'top'
                                ? window.innerHeight - rect.top + 4
                                : (side === 'left' || side === 'right') && align === 'end'
                                    ? window.innerHeight - (rect.top + rect.height)
                                    : undefined,
                            left: side === 'right'
                                ? rect.left + rect.width + 4
                                : (side === 'top' || side === 'bottom') && align === 'start'
                                    ? rect.left
                                    : undefined,
                            right: side === 'left'
                                ? window.innerWidth - rect.left + 4
                                : (side === 'top' || side === 'bottom') && align === 'end'
                                    ? window.innerWidth - (rect.left + rect.width)
                                    : undefined,
                        }, role: "dialog", children: children })) : null }), document.body)
                : null] }));
}
//# sourceMappingURL=popover.js.map