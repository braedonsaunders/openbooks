import * as React from 'react';
import { type SidebarNavGroup } from './sidebar-nav.js';
import type { LinkRender } from './settings-layout.js';
/**
 * The desktop nav rail: brand + collapse toggle (persisted to a cookie so the
 * server can render the right width next load), the grouped nav, and a footer
 * slot (theme toggle, version, etc.). Hidden below `lg` — pair with AppShell's
 * built-in mobile nav.
 */
export declare function AppSidebar({ groups, pathname, brand, footer, collapsedFooter, defaultCollapsed, collapsible, linkRender, expandLabel, collapseLabel, }: {
    groups: SidebarNavGroup[];
    pathname: string;
    brand?: React.ReactNode;
    footer?: React.ReactNode;
    collapsedFooter?: React.ReactNode;
    defaultCollapsed?: boolean;
    collapsible?: boolean;
    linkRender?: LinkRender;
    expandLabel?: string;
    collapseLabel?: string;
}): React.JSX.Element;
//# sourceMappingURL=app-sidebar.d.ts.map