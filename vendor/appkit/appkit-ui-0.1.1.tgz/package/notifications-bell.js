'use client';
import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import * as React from 'react';
import { Bell } from 'lucide-react';
import { Popover } from './popover.js';
import { cn } from './utils.js';
const DEFAULT_LABELS = {
    ariaLabel: 'Notifications',
    title: 'Notifications',
    markAllRead: 'Mark all read',
    empty: 'You’re all caught up.',
};
function timeLabel(value) {
    const date = new Date(value);
    if (Number.isNaN(date.getTime()))
        return '';
    return date.toLocaleString(undefined, { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' });
}
export function NotificationsBell({ items, onOpenItem, onMarkRead, labels = DEFAULT_LABELS, }) {
    const [open, setOpen] = React.useState(false);
    const unread = items.filter((item) => !item.readAt).length;
    function openItem(item) {
        setOpen(false);
        if (!item.readAt)
            void onMarkRead?.([item.id]);
        onOpenItem?.(item);
    }
    return (_jsxs(Popover, { open: open, onOpenChange: setOpen, align: "end", className: "w-80", trigger: _jsxs("button", { type: "button", onClick: () => setOpen((value) => !value), "aria-label": labels.ariaLabel, "aria-expanded": open, "aria-haspopup": "menu", className: "relative grid size-8 shrink-0 place-items-center rounded-md text-fg-muted transition-colors hover:bg-surface-hover hover:text-fg", children: [_jsx(Bell, { size: 17 }), unread > 0 ? _jsx("span", { className: "absolute -right-0.5 -top-0.5 grid h-4 min-w-4 place-items-center rounded-full bg-danger px-1 text-[10px] font-semibold leading-none text-danger-fg", children: unread > 99 ? '99+' : unread }) : null] }), children: [_jsxs("div", { className: "flex items-center justify-between border-b border-border-subtle px-3 py-2.5", children: [_jsx("span", { className: "text-sm font-medium text-fg", children: labels.title }), unread > 0 && onMarkRead ? _jsx("button", { type: "button", onClick: () => void onMarkRead('all'), className: "text-xs font-medium text-fg-muted hover:text-fg", children: labels.markAllRead }) : null] }), _jsx("div", { className: "max-h-96 overflow-y-auto", children: items.length === 0 ? _jsx("p", { className: "px-3 py-6 text-center text-sm text-fg-muted", children: labels.empty }) : items.map((item) => _jsx("button", { type: "button", onClick: () => openItem(item), className: cn('flex w-full flex-col gap-0.5 border-b border-border-subtle px-3 py-2.5 text-left last:border-b-0 hover:bg-surface-hover', !item.readAt && 'bg-bg-subtle'), children: _jsxs("span", { className: "flex items-start gap-2", children: [_jsx("span", { className: cn('mt-1.5 size-1.5 shrink-0 rounded-full', item.readAt ? 'bg-transparent' : 'bg-info') }), _jsxs("span", { className: "min-w-0 flex-1", children: [_jsx("span", { className: cn('block truncate text-sm text-fg', !item.readAt && 'font-medium'), children: item.title }), item.body ? _jsx("span", { className: "block truncate text-xs text-fg-muted", children: item.body }) : null, _jsx("span", { className: "block text-[11px] text-fg-subtle", children: timeLabel(item.createdAt) })] })] }) }, item.id)) })] }));
}
//# sourceMappingURL=notifications-bell.js.map