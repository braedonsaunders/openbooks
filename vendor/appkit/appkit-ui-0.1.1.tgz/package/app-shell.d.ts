import * as React from 'react';
import { type SidebarNavGroup } from './sidebar-nav.js';
import type { LinkRender } from './settings-layout.js';
export type AppShellNavigationMode = 'topbar' | 'sidebar';
/**
 * Generalized application shell. One serialized navigation registry drives the
 * dropdown topbar, shared collapsible rail,
 * the mobile drawer, and the native-style mobile tab bar.
 */
export declare function AppShell({ groups, pathname, brand, sidebarFooter, sidebarCollapsedFooter, mobileFooter, headerMiddle, header, banner, defaultCollapsed, navigationMode, linkRender, moreLabel, openNavigationLabel, menuLabel, primaryNavigationLabel, mobileTabCount, showMobileTabs, children, }: {
    groups: SidebarNavGroup[];
    pathname: string;
    brand?: React.ReactNode;
    sidebarFooter?: React.ReactNode;
    sidebarCollapsedFooter?: React.ReactNode;
    mobileFooter?: React.ReactNode;
    /** Search, tenant, role, or other application-owned middle controls. */
    headerMiddle?: React.ReactNode;
    /** Right-side utility actions and account menu. */
    header?: React.ReactNode;
    banner?: React.ReactNode;
    defaultCollapsed?: boolean;
    navigationMode?: AppShellNavigationMode;
    linkRender?: LinkRender;
    moreLabel?: string;
    openNavigationLabel?: string;
    menuLabel?: string;
    primaryNavigationLabel?: string;
    mobileTabCount?: number;
    showMobileTabs?: boolean;
    children: React.ReactNode;
}): React.JSX.Element;
//# sourceMappingURL=app-shell.d.ts.map