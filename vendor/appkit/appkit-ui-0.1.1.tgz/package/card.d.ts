import * as React from 'react';
export type CardProps = React.HTMLAttributes<HTMLDivElement> & {
    /** Adds a hover lift + shadow. Auto-enabled when an onClick is present. */
    interactive?: boolean;
};
/**
 * Card — the default surface. No 'use client': stays server-renderable, and
 * only attaches keyboard handling when the caller actually made it clickable
 * (an unconditional handler would make every server-rendered Card
 * unserializable).
 */
export declare const Card: React.ForwardRefExoticComponent<React.HTMLAttributes<HTMLDivElement> & {
    /** Adds a hover lift + shadow. Auto-enabled when an onClick is present. */
    interactive?: boolean;
} & React.RefAttributes<HTMLDivElement>>;
export declare const CardHeader: React.ForwardRefExoticComponent<React.HTMLAttributes<HTMLDivElement> & React.RefAttributes<HTMLDivElement>>;
export declare const CardTitle: React.ForwardRefExoticComponent<React.HTMLAttributes<HTMLHeadingElement> & React.RefAttributes<HTMLHeadingElement>>;
export declare const CardDescription: React.ForwardRefExoticComponent<React.HTMLAttributes<HTMLParagraphElement> & React.RefAttributes<HTMLParagraphElement>>;
export declare const CardContent: React.ForwardRefExoticComponent<React.HTMLAttributes<HTMLDivElement> & React.RefAttributes<HTMLDivElement>>;
export declare const CardFooter: React.ForwardRefExoticComponent<React.HTMLAttributes<HTMLDivElement> & React.RefAttributes<HTMLDivElement>>;
//# sourceMappingURL=card.d.ts.map