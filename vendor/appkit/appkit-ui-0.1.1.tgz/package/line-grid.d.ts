/**
 * LineGrid — a spreadsheet-grade line-item editor for documents (invoices,
 * bills, journals, estimates). Controlled: rows in, rows out; the parent owns
 * persistence and any computed columns.
 *
 *  - Enter commits + moves down (appending a row at the bottom)
 *  - Alt+↑/↓ moves the row, ⌘/Ctrl+D duplicates, ⌘/Ctrl+⌫ deletes
 *  - per-row grip menu: insert above/below, duplicate, remove
 *  - amount cells edit raw, normalize to 2dp on blur, flag non-numeric
 *  - columns are data: text / amount / select / readonly (+ custom render)
 */
import * as React from 'react';
import { type SelectOption } from './search-select.js';
export type LineGridColumn<Row extends Record<string, unknown>> = {
    key: string;
    label: string;
    /** CSS grid track, e.g. 'minmax(180px,2fr)' or '110px'. */
    width: string;
    type: 'text' | 'amount' | 'select' | 'readonly';
    align?: 'left' | 'right';
    options?: SelectOption[];
    placeholder?: string;
    required?: boolean;
    /** Renderer for readonly columns (computed cells). */
    render?: (row: Row, index: number) => React.ReactNode;
};
export type LineGridLabels = {
    addLine: string;
    keyboardHint: string;
    insertAbove: string;
    insertBelow: string;
    duplicate: string;
    removeLine: string;
    clearLine: string;
    lineActions: (n: number) => string;
};
export type LineGridProps<Row extends Record<string, unknown>> = {
    columns: LineGridColumn<Row>[];
    rows: Row[];
    onRowsChange: (rows: Row[]) => void;
    emptyRow: () => Row;
    readOnly?: boolean;
    minRows?: number;
    footer?: React.ReactNode;
    labels?: Partial<LineGridLabels>;
};
export declare function LineGrid<Row extends Record<string, unknown>>({ columns, rows, onRowsChange, emptyRow, readOnly, minRows, footer, labels: labelOverrides, }: LineGridProps<Row>): React.JSX.Element;
//# sourceMappingURL=line-grid.d.ts.map