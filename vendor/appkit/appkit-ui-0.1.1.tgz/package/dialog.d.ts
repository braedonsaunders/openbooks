import * as React from 'react';
export type DialogSize = 'sm' | 'md' | 'lg';
export type DialogProps = {
    open: boolean;
    onClose: () => void;
    title?: React.ReactNode;
    description?: React.ReactNode;
    children?: React.ReactNode;
    footer?: React.ReactNode;
    size?: DialogSize;
    /** Hide the corner close button. */
    hideClose?: boolean;
    closeLabel?: string;
};
/** Centered modal dialog: backdrop, spring scale-in, focus trap, Esc/click-out. */
export declare function Dialog({ open, onClose, title, description, children, footer, size, hideClose, closeLabel, }: DialogProps): React.ReactPortal | null;
//# sourceMappingURL=dialog.d.ts.map