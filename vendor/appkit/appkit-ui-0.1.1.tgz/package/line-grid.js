'use client';
import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
/**
 * LineGrid — a spreadsheet-grade line-item editor for documents (invoices,
 * bills, journals, estimates). Controlled: rows in, rows out; the parent owns
 * persistence and any computed columns.
 *
 *  - Enter commits + moves down (appending a row at the bottom)
 *  - Alt+↑/↓ moves the row, ⌘/Ctrl+D duplicates, ⌘/Ctrl+⌫ deletes
 *  - per-row grip menu: insert above/below, duplicate, remove
 *  - amount cells edit raw, normalize to 2dp on blur, flag non-numeric
 *  - columns are data: text / amount / select / readonly (+ custom render)
 */
import * as React from 'react';
import { ArrowDown, ArrowUp, Copy, GripVertical, Plus, Trash2 } from 'lucide-react';
import { Button } from './button.js';
import { ContextMenu, useContextMenu } from './context-menu.js';
import { SearchSelect } from './search-select.js';
import { cn } from './utils.js';
const DEFAULT_LABELS = {
    addLine: 'Add line',
    keyboardHint: 'Enter to add a row · Alt+↑/↓ to move · ⌘D to duplicate · ⌘⌫ to remove',
    insertAbove: 'Insert above',
    insertBelow: 'Insert below',
    duplicate: 'Duplicate',
    removeLine: 'Remove line',
    clearLine: 'Clear line',
    lineActions: (n) => `Line ${n} actions`,
};
function normalizeAmount(v) {
    const n = Number(v);
    if (v.trim() === '' || Number.isNaN(n))
        return v;
    return n.toFixed(2);
}
export function LineGrid({ columns, rows, onRowsChange, emptyRow, readOnly = false, minRows = 1, footer, labels: labelOverrides, }) {
    const labels = { ...DEFAULT_LABELS, ...labelOverrides };
    const containerRef = React.useRef(null);
    const focusedCol = React.useRef(0);
    const menu = useContextMenu();
    const [menuRow, setMenuRow] = React.useState(null);
    const template = readOnly
        ? columns.map((c) => c.width).join(' ')
        : `34px ${columns.map((c) => c.width).join(' ')}`;
    const setCell = React.useCallback((i, key, value) => {
        onRowsChange(rows.map((r, j) => (j === i ? { ...r, [key]: value } : r)));
    }, [rows, onRowsChange]);
    function focusCell(row, col) {
        requestAnimationFrame(() => {
            const el = containerRef.current?.querySelector(`[data-lg-row="${row}"][data-lg-col="${col}"] input, [data-lg-row="${row}"][data-lg-col="${col}"] button`);
            el?.focus();
        });
    }
    const insertRow = (at) => {
        const next = [...rows];
        next.splice(at, 0, emptyRow());
        onRowsChange(next);
        focusCell(at, 0);
    };
    const duplicateRow = (i) => {
        const next = [...rows];
        next.splice(i + 1, 0, { ...rows[i] });
        onRowsChange(next);
        focusCell(i + 1, 0);
    };
    const removeRow = (i) => {
        if (rows.length <= minRows) {
            onRowsChange(rows.map((r, j) => (j === i ? emptyRow() : r)));
            return;
        }
        onRowsChange(rows.filter((_, j) => j !== i));
    };
    const moveRow = (i, delta) => {
        const j = i + delta;
        if (j < 0 || j >= rows.length)
            return;
        const next = [...rows];
        const [row] = next.splice(i, 1);
        next.splice(j, 0, row);
        onRowsChange(next);
        focusCell(j, focusedCol.current);
    };
    function handleKeyDown(e, i, colIndex) {
        focusedCol.current = colIndex;
        const mod = e.metaKey || e.ctrlKey;
        if (e.key === 'Enter' && !e.shiftKey && !mod) {
            if (e.target.getAttribute('aria-expanded') === 'true')
                return;
            e.preventDefault();
            if (i === rows.length - 1) {
                onRowsChange([...rows, emptyRow()]);
                focusCell(i + 1, colIndex);
            }
            else {
                focusCell(i + 1, colIndex);
            }
            return;
        }
        if (e.altKey && e.key === 'ArrowUp') {
            e.preventDefault();
            moveRow(i, -1);
        }
        else if (e.altKey && e.key === 'ArrowDown') {
            e.preventDefault();
            moveRow(i, 1);
        }
        else if (mod && (e.key === 'd' || e.key === 'D')) {
            e.preventDefault();
            duplicateRow(i);
        }
        else if (mod && e.key === 'Backspace') {
            e.preventDefault();
            removeRow(i);
            focusCell(Math.max(0, i - 1), colIndex);
        }
    }
    const cellBase = 'flex min-h-[38px] items-center border-b border-border-subtle px-1';
    const inputBase = 'w-full rounded-sm border-0 bg-transparent px-1.5 py-1 text-sm text-fg outline-none focus:ring-2 focus:ring-ring/50';
    return (_jsxs("div", { children: [_jsx("div", { ref: containerRef, className: "overflow-x-auto rounded-lg border border-border bg-surface", children: _jsxs("div", { className: "grid min-w-fit", style: { gridTemplateColumns: template }, children: [!readOnly ? _jsx("div", { className: "border-b border-border" }) : null, columns.map((c) => (_jsxs("div", { className: cn('border-b border-border px-2.5 py-2 text-[11px] font-semibold tracking-wide text-fg-muted uppercase', c.align === 'right' && 'text-right'), children: [c.label, c.required && !readOnly ? _jsx("span", { className: "text-danger", children: " *" }) : null] }, c.key))), rows.map((row, i) => (_jsxs(React.Fragment, { children: [!readOnly ? (_jsx("div", { className: cn(cellBase, 'justify-center px-0'), children: _jsxs("button", { type: "button", "aria-label": labels.lineActions(i + 1), onClick: (e) => {
                                            setMenuRow(i);
                                            menu.openBelow(e.currentTarget);
                                        }, className: "group flex size-7 items-center justify-center rounded text-fg-subtle transition-colors hover:bg-surface-hover hover:text-fg-muted", children: [_jsx("span", { className: "text-[11px] tabular-nums group-hover:hidden", children: i + 1 }), _jsx(GripVertical, { size: 13, className: "hidden group-hover:block" })] }) })) : null, columns.map((c, colIndex) => {
                                    const value = row[c.key];
                                    if (readOnly || c.type === 'readonly') {
                                        let display;
                                        if (c.render)
                                            display = c.render(row, i);
                                        else if (c.type === 'select' && value)
                                            display = c.options?.find((o) => o.value === value)?.label ?? '';
                                        else
                                            display = value ?? '';
                                        return (_jsx("div", { className: cn(cellBase, 'px-2.5 text-sm', c.align === 'right' && 'justify-end tabular-nums'), children: display }, c.key));
                                    }
                                    return (_jsx("div", { "data-lg-row": i, "data-lg-col": colIndex, className: cellBase, onKeyDown: (e) => handleKeyDown(e, i, colIndex), children: c.type === 'select' ? (_jsx(SearchSelect, { value: value ?? '', onChange: (v) => setCell(i, c.key, v), options: c.options ?? [], placeholder: c.placeholder ?? '—', triggerClassName: "h-auto min-h-0 border-0 bg-transparent px-1.5 py-1 focus-visible:ring-1" })) : c.type === 'amount' ? (_jsx("input", { inputMode: "decimal", value: value ?? '', placeholder: c.placeholder ?? '0.00', "aria-invalid": value !== '' && value != null && Number.isNaN(Number(value)) ? true : undefined, onChange: (e) => setCell(i, c.key, e.target.value), onBlur: (e) => setCell(i, c.key, normalizeAmount(e.target.value)), className: cn(inputBase, 'text-right tabular-nums', value !== '' && value != null && Number.isNaN(Number(value)) &&
                                                'text-danger focus:ring-danger/50') })) : (_jsx("input", { value: value ?? '', placeholder: c.placeholder, onChange: (e) => setCell(i, c.key, e.target.value), className: inputBase })) }, c.key));
                                })] }, i)))] }) }), _jsxs("div", { className: "mt-2 flex items-center justify-between gap-3", children: [!readOnly ? (_jsxs(Button, { type: "button", variant: "outline", size: "sm", onClick: () => insertRow(rows.length), children: [_jsx(Plus, { size: 14 }), " ", labels.addLine] })) : (_jsx("span", {})), footer] }), !readOnly ? _jsx("p", { className: "mt-1.5 text-[11px] text-fg-subtle", children: labels.keyboardHint }) : null, _jsx(ContextMenu, { open: menu.open && menuRow != null, position: menu.position, onClose: () => {
                    menu.close();
                    setMenuRow(null);
                }, items: menuRow == null
                    ? []
                    : [
                        { key: 'above', label: labels.insertAbove, icon: ArrowUp, onSelect: () => insertRow(menuRow) },
                        { key: 'below', label: labels.insertBelow, icon: ArrowDown, onSelect: () => insertRow(menuRow + 1) },
                        { key: 'dup', label: labels.duplicate, icon: Copy, onSelect: () => duplicateRow(menuRow) },
                        { key: 'sep', separator: true },
                        {
                            key: 'rm',
                            label: rows.length > minRows ? labels.removeLine : labels.clearLine,
                            icon: Trash2,
                            danger: true,
                            onSelect: () => removeRow(menuRow),
                        },
                    ] })] }));
}
//# sourceMappingURL=line-grid.js.map