import * as React from 'react';
import { type LucideIcon } from 'lucide-react';
import type { LinkRender } from './settings-layout.js';
declare const ICONS: Record<string, LucideIcon>;
export type SidebarNavItem = {
    href: string;
    label: string;
    /** Built-in message key. Omitted for tenant-authored/custom labels. */
    labelKey?: string;
    iconKey?: keyof typeof ICONS | string;
    icon?: React.ReactNode;
    exact?: boolean;
    subgroup?: string;
    subgroupHref?: string;
    subgroupIconKey?: string;
    mobile?: boolean;
};
export type SidebarNavGroup = {
    /** Optional workspace id; omit it for a simple grouped-list contract. */
    id?: string;
    label: string;
    labelKey?: string;
    iconKey?: string;
    icon?: React.ReactNode;
    items: SidebarNavItem[];
};
export declare function findActiveNavHref(pathname: string | null | undefined, groups: SidebarNavGroup[]): string | null;
/**
 * The shared navigation registry rendered as a desktop sidebar. Workspace
 * metadata (`id` + group icon) enables collapsible treatment; simpler groups
 * retain labeled sections. Both use the same active-path, icon, and link contracts.
 */
export declare function SidebarNav({ groups, pathname, collapsed, linkRender, }: {
    groups: SidebarNavGroup[];
    pathname: string;
    collapsed?: boolean;
    linkRender?: LinkRender;
}): React.JSX.Element;
export declare function groupContainsActiveHref(group: SidebarNavGroup, activeHref: string | null): boolean;
export type NavBlock = {
    kind: 'item';
    item: SidebarNavItem;
} | {
    kind: 'subgroup';
    label: string;
    href?: string;
    iconKey?: string;
    items: SidebarNavItem[];
};
export declare function toBlocks(items: SidebarNavItem[]): NavBlock[];
export declare const ICON_KEYS: string[];
export declare function NavIcon({ iconKey, icon, size, className, }: {
    iconKey?: string;
    icon?: React.ReactNode;
    size?: number;
    className?: string;
}): React.JSX.Element;
/** Mobile shortcut selection: explicitly pinned entries, then registry order. */
export declare function selectMobileTabs(groups: SidebarNavGroup[], count?: number): SidebarNavItem[];
export {};
//# sourceMappingURL=sidebar-nav.d.ts.map