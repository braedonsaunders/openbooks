const GENERIC_FAILURE = {
    code: 'internal_error',
    message: 'The operation failed.',
};
/** "list_open_items" → "List Open Items" — the default tool title. */
export function toolTitle(name) {
    return name
        .split('_')
        .map((part) => (part ? part[0].toUpperCase() + part.slice(1) : part))
        .join(' ');
}
/**
 * A successful tool result: the structured payload plus a text rendering.
 * Pass a summary when one line serves the model better than the full JSON.
 */
export function mcpSuccess(structuredContent, summary) {
    return {
        structuredContent,
        content: [
            {
                type: 'text',
                text: summary ?? JSON.stringify(structuredContent, null, 2),
            },
        ],
    };
}
/**
 * A failed tool result. The mapper decides which errors are safe to surface;
 * everything else collapses to a generic failure with no leaked detail.
 */
export function mcpFailure(error, mapError) {
    const shape = mapError?.(error) ?? GENERIC_FAILURE;
    return {
        isError: true,
        structuredContent: {
            ok: false,
            error: {
                code: shape.code,
                message: shape.message,
                ...(shape.details !== undefined ? { details: shape.details } : {}),
            },
        },
        content: [{ type: 'text', text: `${shape.code}: ${shape.message}` }],
    };
}
//# sourceMappingURL=result.js.map