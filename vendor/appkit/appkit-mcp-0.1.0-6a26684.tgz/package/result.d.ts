import type { CallToolResult } from '@modelcontextprotocol/sdk/types.js';
/**
 * The one error shape a tool result may carry. Apps map their own error
 * classes onto it; anything the mapper declines becomes the generic
 * `internal_error`, so raw error text (stack frames, SQL, secrets) can never
 * reach the model by accident.
 */
export interface McpErrorShape {
    code: string;
    message: string;
    details?: unknown;
}
/** Maps a thrown value onto {@link McpErrorShape}, or returns null to decline. */
export type McpErrorMapper = (error: unknown) => McpErrorShape | null;
/** "list_open_items" → "List Open Items" — the default tool title. */
export declare function toolTitle(name: string): string;
/**
 * A successful tool result: the structured payload plus a text rendering.
 * Pass a summary when one line serves the model better than the full JSON.
 */
export declare function mcpSuccess(structuredContent: Record<string, unknown>, summary?: string): CallToolResult;
/**
 * A failed tool result. The mapper decides which errors are safe to surface;
 * everything else collapses to a generic failure with no leaked detail.
 */
export declare function mcpFailure(error: unknown, mapError?: McpErrorMapper): CallToolResult;
//# sourceMappingURL=result.d.ts.map