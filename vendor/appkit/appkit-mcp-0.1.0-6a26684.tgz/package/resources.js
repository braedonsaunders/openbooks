/** Register each resource; `text` may be a thunk resolved per read. */
export function registerStaticResources(server, resources) {
    for (const resource of resources) {
        const mimeType = resource.mimeType ?? 'text/markdown';
        server.registerResource(resource.name, resource.uri, {
            title: resource.title,
            ...(resource.description ? { description: resource.description } : {}),
            mimeType,
        }, async () => ({
            contents: [
                {
                    uri: resource.uri,
                    mimeType,
                    text: typeof resource.text === 'function' ? await resource.text() : resource.text,
                },
            ],
        }));
    }
}
//# sourceMappingURL=resources.js.map