import type { AuthInfo } from '@modelcontextprotocol/sdk/server/auth/types.js';
import type { McpServer } from '@modelcontextprotocol/sdk/server/mcp.js';
/**
 * The caller's `X-Request-ID` when it is well-formed, else a fresh UUID —
 * a hostile header can never inject log noise or collide with another request.
 */
export declare function resolveMcpRequestId(request: Request, header?: string): string;
export interface HandleStreamableHttpOptions {
    /** A per-request server instance; the handler closes it when the exchange ends. */
    server: McpServer;
    /** Forwarded to the transport so tool handlers can see the authenticated caller. */
    authInfo?: AuthInfo;
    /** Echoed back as `X-Request-ID` on the response. */
    requestId?: string;
    /** Observes transport failures; the caller still gets a clean JSON-RPC 500. */
    onError?: (error: unknown) => void;
}
/**
 * Serve one stateless MCP exchange over streamable HTTP: connect a fresh
 * transport, handle the request, stamp response headers, and always tear both
 * transport and server down — a request can never leak a session.
 */
export declare function handleStreamableHttpRequest(request: Request, options: HandleStreamableHttpOptions): Promise<Response>;
//# sourceMappingURL=handler.d.ts.map