/**
 * Request-boundary validation for an MCP HTTP endpoint.
 *
 * Two checks, both cheap and both fail-closed:
 *
 * - **Host** — the `Host` header must match the request URL (or an explicit
 *   allowlist). This is the DNS-rebinding defence: a hostile page resolving
 *   its own name to this server's address still sends its own Host.
 * - **Origin** — a cross-origin browser caller must be explicitly allowed.
 *   Non-browser clients send no Origin and pass untouched.
 */
export interface McpBoundaryOptions {
    /** Extra `host[:port]` values accepted beyond the request URL's own host. */
    allowedHosts?: Iterable<string>;
    /** Extra origins accepted beyond the request URL's own origin. */
    allowedOrigins?: Iterable<string>;
}
export interface McpBoundaryViolation {
    status: number;
    code: number;
    message: string;
}
/** A JSON-RPC error as a web-standard Response. */
export declare function jsonRpcErrorResponse(status: number, code: number, message: string): Response;
/** Null when the request passes the boundary; otherwise the violation to return. */
export declare function validateMcpBoundary(request: Request, options?: McpBoundaryOptions): McpBoundaryViolation | null;
/** {@link validateMcpBoundary} rendered as a Response, or null to proceed. */
export declare function mcpBoundaryResponse(request: Request, options?: McpBoundaryOptions): Response | null;
/** CORS preflight for the endpoint; echoes the caller's origin when present. */
export declare function mcpPreflightResponse(request: Request, options?: {
    allowedHeaders?: string;
    exposedHeaders?: string;
    maxAgeSeconds?: number;
}): Response;
/** 405 for the verbs a stateless MCP endpoint does not serve. */
export declare function mcpMethodNotAllowed(): Response;
//# sourceMappingURL=boundary.d.ts.map