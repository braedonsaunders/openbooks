import type { McpServer } from '@modelcontextprotocol/sdk/server/mcp.js';
import type { ZodType } from 'zod';
import { type McpErrorMapper } from './result.js';
/**
 * One entry in an app's tool catalogue. The catalogue is the app's canonical
 * external capability surface — MCP is an adapter over it, never a second
 * place capabilities are defined. `execute` must terminate in the app's own
 * governed services (validation, permissions, idempotency, audit), so the MCP
 * surface can never do something a normal API caller could not.
 */
export interface McpCatalogTool<Context> {
    name: string;
    /** Defaults to a title-cased rendering of `name`. */
    title?: string;
    description: string;
    /** The tool's input contract. `execute` re-validates; never trust transport parsing alone. */
    inputSchema: ZodType;
    readOnly: boolean;
    destructive?: boolean;
    openWorld?: boolean;
    /** Visibility gate — a hidden tool is never registered, so the model cannot see it. */
    visible?: (context: Context) => boolean;
    execute: (context: Context, input: Record<string, unknown>) => Promise<Record<string, unknown>>;
    /** Optional one-line rendering of a successful result for the text channel. */
    summarize?: (result: Record<string, unknown>) => string | undefined;
}
export interface McpToolAuditEvent {
    name: string;
    durationMs: number;
    status: 'ok' | 'error';
    /** Bounded, mapper-approved error text — never the raw thrown value. */
    errorSummary?: string;
    /** HTTP-ish status derived from the error, when the app supplied a deriver. */
    statusCode?: number;
}
export interface RegisterToolCatalogOptions<Context> {
    context: Context;
    /** Called after every execution, success or failure. */
    audit?: (event: McpToolAuditEvent) => void;
    /** Maps app error classes to safe result shapes; see {@link McpErrorMapper}. */
    mapError?: McpErrorMapper;
    /** Derives an audit status code from a thrown value (default 500). */
    errorStatusCode?: (error: unknown) => number;
}
/**
 * Register every visible catalogue tool on a server. Execution is wrapped in
 * the success/failure result contract, timed, and reported to the audit hook.
 * Returns how many tools were registered.
 */
export declare function registerToolCatalog<Context>(server: McpServer, tools: readonly McpCatalogTool<Context>[], options: RegisterToolCatalogOptions<Context>): number;
//# sourceMappingURL=catalog.d.ts.map