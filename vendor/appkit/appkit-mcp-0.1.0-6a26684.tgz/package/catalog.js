import { mcpFailure, mcpSuccess, toolTitle } from './result.js';
/**
 * Register every visible catalogue tool on a server. Execution is wrapped in
 * the success/failure result contract, timed, and reported to the audit hook.
 * Returns how many tools were registered.
 */
export function registerToolCatalog(server, tools, options) {
    let registered = 0;
    for (const tool of tools) {
        if (tool.visible && !tool.visible(options.context))
            continue;
        registered += 1;
        server.registerTool(tool.name, {
            title: tool.title ?? toolTitle(tool.name),
            description: tool.description,
            // The SDK accepts a zod object schema here; its own generic is narrower.
            inputSchema: tool.inputSchema,
            annotations: {
                readOnlyHint: tool.readOnly,
                destructiveHint: tool.destructive ?? false,
                openWorldHint: tool.openWorld ?? false,
            },
        }, (async (input) => {
            const startedAt = Date.now();
            try {
                const result = await tool.execute(options.context, (input ?? {}));
                const success = mcpSuccess(result, tool.summarize?.(result));
                options.audit?.({
                    name: tool.name,
                    durationMs: Date.now() - startedAt,
                    status: 'ok',
                });
                return success;
            }
            catch (error) {
                const failure = mcpFailure(error, options.mapError);
                const text = failure.content[0];
                options.audit?.({
                    name: tool.name,
                    durationMs: Date.now() - startedAt,
                    status: 'error',
                    errorSummary: text && text.type === 'text' ? text.text.slice(0, 500) : 'tool failed',
                    statusCode: options.errorStatusCode?.(error) ?? 500,
                });
                return failure;
            }
        }));
    }
    return registered;
}
//# sourceMappingURL=catalog.js.map