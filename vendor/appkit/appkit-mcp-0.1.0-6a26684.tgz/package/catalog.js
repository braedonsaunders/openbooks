import { mcpFailure, mcpSuccess, toolTitle } from './result.js';
/**
 * Register every visible catalogue tool on a server. Execution is wrapped in
 * the success/failure result contract, timed, and reported to the audit hook.
 * Returns how many tools were registered.
 */
export function registerToolCatalog(server, tools, options) {
    let registered = 0;
    for (const tool of tools) {
        if (tool.visible && !tool.visible(options.context))
            continue;
        registered += 1;
        server.registerTool(tool.name, {
            title: tool.title ?? toolTitle(tool.name),
            description: tool.description,
            // The SDK accepts a zod object schema here; its own generic is narrower.
            inputSchema: tool.inputSchema,
            annotations: {
                readOnlyHint: tool.readOnly,
                destructiveHint: tool.destructive ?? false,
                openWorldHint: tool.openWorld ?? false,
            },
        }, (async (input) => {
            const startedAt = Date.now();
            let success;
            try {
                const result = await tool.execute(options.context, (input ?? {}));
                success = mcpSuccess(result, tool.summarize?.(result));
            }
            catch (error) {
                const failure = mcpFailure(error, options.mapError);
                const text = failure.content[0];
                // Audit persistence is part of the tool response contract:
                // await it so a failure cannot return before its evidence is
                // durable. If the write fails, let it fail the request closed.
                await options.audit?.({
                    name: tool.name,
                    durationMs: Date.now() - startedAt,
                    status: 'error',
                    errorSummary: text && text.type === 'text' ? text.text.slice(0, 500) : 'tool failed',
                    statusCode: options.errorStatusCode?.(error) ?? 500,
                });
                return failure;
            }
            // Keep audit failures out of the execution catch above. A
            // successful tool must never be relabelled as a tool failure just
            // because its evidence write failed; the transport fails closed.
            await options.audit?.({
                name: tool.name,
                durationMs: Date.now() - startedAt,
                status: 'ok',
            });
            return success;
        }));
    }
    return registered;
}
//# sourceMappingURL=catalog.js.map
