import { randomUUID } from 'node:crypto';
import { WebStandardStreamableHTTPServerTransport } from '@modelcontextprotocol/sdk/server/webStandardStreamableHttp.js';
import { jsonRpcErrorResponse } from './boundary.js';
const REQUEST_ID_PATTERN = /^[A-Za-z0-9._:-]{8,200}$/;
/**
 * The caller's `X-Request-ID` when it is well-formed, else a fresh UUID —
 * a hostile header can never inject log noise or collide with another request.
 */
export function resolveMcpRequestId(request, header = 'x-request-id') {
    const value = request.headers.get(header);
    return value && REQUEST_ID_PATTERN.test(value) ? value : randomUUID();
}
/**
 * Serve one stateless MCP exchange over streamable HTTP: connect a fresh
 * transport, handle the request, stamp response headers, and always tear both
 * transport and server down — a request can never leak a session.
 */
export async function handleStreamableHttpRequest(request, options) {
    const transport = new WebStandardStreamableHTTPServerTransport({
        sessionIdGenerator: undefined,
        enableJsonResponse: true,
    });
    try {
        await options.server.connect(transport);
        const response = await transport.handleRequest(request, options.authInfo ? { authInfo: options.authInfo } : undefined);
        const headers = new Headers(response.headers);
        if (options.requestId)
            headers.set('x-request-id', options.requestId);
        headers.set('cache-control', 'no-store');
        return new Response(response.body, { status: response.status, headers });
    }
    catch (error) {
        options.onError?.(error);
        return jsonRpcErrorResponse(500, -32603, 'Internal server error');
    }
    finally {
        await Promise.allSettled([transport.close(), options.server.close()]);
    }
}
//# sourceMappingURL=handler.js.map